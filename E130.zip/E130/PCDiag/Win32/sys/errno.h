/*  This header file is machine generated. 
Modify EiC/config/genstdio.c, or the target independent source 
files it reads, in order to modify this file.  Any 
direct modifications to this file will be lost. 
*/

#ifndef SYSERRNOH_
#define SYSERRNOH_

/* ISO C STUFF */
#define EDOM		33	/* Math argument out of domain of func */
#define ERANGE		34	/* Math result not representable */

/* POSIX.1 STUFF */
#ifdef _POSIX_SOURCE
#define E2BIG		7	/* Arg list too long */
#define EACCES		13	/* Permission denied */
#define EAGAIN		11	/* Try again */
#define EBADF		9	/* Bad file number */
#define EBUSY		16	/* Device or resource busy */
#define ECHILD		10	/* No child processes */
#define EDEADLK		36	/* Resource deadlock would occur */
#define EEXIST		17	/* File exists */
#define EFAULT		14	/* Bad address */
#define EFBIG		27	/* File too large */
#define EINTR		4	/* Interrupted system call */
#define EINVAL		22	/* Invalid argument */
#define EIO		5	/* I/O error */
#define EISDIR		21	/* Is a directory */
#define EMFILE		24	/* Too many open files */
#define EMLINK		31	/* Too many links */
#define ENAMETOOLONG		38	/* File name too long */
#define ENFILE		23	/* File table overflow */
#define ENODEV		19	/* No such device */
#define ENOENT		2	/* No such file or directory */
#define ENOEXEC		8	/* Exec format error */
#define ENOLCK		39	/* No record locks available */
#define ENOMEM		12	/* Out of memory */
#define ENOSPC		28	/* No space left on device */
#define ENOSYS		40	/* Function not implemented */
#define ENOTDIR		20	/* Not a directory */
#define ENOTEMPTY		41	/* Directory not empty */
#define ENOTTY		25	/* Not a typewriter */
#define ENXIO		6	/* No such device or address */
#define EPERM		1	/* Operation not permitted */
#define EPIPE		32	/* Broken pipe */
#define EROFS		30	/* Read-only file system */
#define ESPIPE		29	/* Illegal seek */
#define ESRCH		3	/* No such process */
#define EXDEV		18	/* Cross-device link */
#endif /* end  _POSIX_SOURCE */

#endif
