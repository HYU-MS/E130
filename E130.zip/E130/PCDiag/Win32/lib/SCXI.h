
/****************************************************************************
/* Headerfile for implemented SCXI functions in PCDiagNT Interpreter.       *
/*                                                                          *
/* Author: Tautz Stefan, Siemens AT SE RS T36, Diplomand                    *
/*																			*
/* This functions are needed to control a National Instruments SCXI system	*
/* with SCXI 1160 relay modules.											*
/*																			*
/* further information: see Diplomarbeit									*
/* "automatisiertes Testsystem CrashSimPlus" von Stefan Tautz, AT SE RS T36"*
/*																			*
/* Datum: 01/2001															*
/****************************************************************************/

#ifndef __SCXI
#define __SCXI

//#include <ivi.h>
//#include <iviswtch.h>

#define NISWITCH_MAJOR_VERSION         1     /* Instrument driver major version */
#define NISWITCH_MINOR_VERSION         100     /* Instrument driver minor version */

        /* User Options */
#define NISWITCH_ATTR_RANGE_CHECK               IVI_ATTR_RANGE_CHECK              /* ViBoolean */
#define NISWITCH_ATTR_QUERY_INSTR_STATUS        IVI_ATTR_QUERY_INSTR_STATUS       /* ViBoolean */
#define NISWITCH_ATTR_CACHE                     IVI_ATTR_CACHE                    /* ViBoolean */
#define NISWITCH_ATTR_SIMULATE                  IVI_ATTR_SIMULATE                 /* ViBoolean */
#define NISWITCH_ATTR_RECORD_COERCIONS          IVI_ATTR_RECORD_COERCIONS         /* ViBoolean */

        /* Instrument Capabilities */
#define NISWITCH_ATTR_NUM_CHANNELS              IVI_ATTR_NUM_CHANNELS             /* ViInt32, Read-only */
#define NISWITCH_ATTR_SPECIFIC_PREFIX           IVI_ATTR_SPECIFIC_PREFIX          /* ViString, Read-only */

        /* Version Info */
#define NISWITCH_ATTR_DRIVER_MAJOR_VERSION      IVI_ATTR_DRIVER_MAJOR_VERSION     /* ViInt32, Read-only */
#define NISWITCH_ATTR_DRIVER_MINOR_VERSION      IVI_ATTR_DRIVER_MINOR_VERSION     /* ViInt32, Read-only */
#define NISWITCH_ATTR_DRIVER_REVISION           IVI_ATTR_DRIVER_REVISION          /* ViString, Read-only */
#define NISWITCH_ATTR_ENGINE_MAJOR_VERSION      IVI_ATTR_ENGINE_MAJOR_VERSION     /* ViInt32, Read-only */
#define NISWITCH_ATTR_ENGINE_MINOR_VERSION      IVI_ATTR_ENGINE_MINOR_VERSION     /* ViInt32, Read-only */
#define NISWITCH_ATTR_ENGINE_REVISION           IVI_ATTR_ENGINE_REVISION          		/* ViString, Read-only */
#define NISWITCH_ATTR_SERIAL_NUMBER         	(IVI_SPECIFIC_PUBLIC_ATTR_BASE + 1L) 	/* ViString, Read-only */

        /* Error Info */
#define NISWITCH_ATTR_PRIMARY_ERROR             IVI_ATTR_PRIMARY_ERROR            /* ViInt32   */
#define NISWITCH_ATTR_SECONDARY_ERROR           IVI_ATTR_SECONDARY_ERROR          /* ViInt32   */
#define NISWITCH_ATTR_ERROR_ELABORATION         IVI_ATTR_ERROR_ELABORATION        /* ViString  */

        /* Advanced Session I/O */
#define NISWITCH_ATTR_VISA_RM_SESSION           IVI_ATTR_VISA_RM_SESSION          /* ViSession, Read-only */
#define NISWITCH_ATTR_IO_SESSION                IVI_ATTR_IO_SESSION               /* ViSession, Read-only */
#define NISWITCH_ATTR_DEFER_UPDATE              IVI_ATTR_DEFER_UPDATE             /* ViBoolean */
#define NISWITCH_ATTR_RETURN_DEFERRED_VALUES    IVI_ATTR_RETURN_DEFERRED_VALUES   /* ViBoolean */
    
    /*- Configuration Attributes -------------------------------------------*/
#define NISWITCH_ATTR_IS_SOURCE_CHANNEL          IVISWTCH_ATTR_IS_SOURCE_CHANNEL           /* ViBoolean, Channel-based */
#define NISWITCH_ATTR_IS_CONFIGURATION_CHANNEL   IVISWTCH_ATTR_IS_CONFIGURATION_CHANNEL    /* ViBoolean, Channel-based */

    /*- Status Attributes --------------------------------------------------*/
#define NISWITCH_ATTR_IS_DEBOUNCED               IVISWTCH_ATTR_IS_DEBOUNCED             /* ViBoolean, Read-only */

    /*- Device Information Attributes --------------------------------------*/
#define NISWITCH_ATTR_SETTLING_TIME              IVISWTCH_ATTR_SETTLING_TIME            /* ViReal64, Channel-based */
#define NISWITCH_ATTR_BANDWIDTH                  IVISWTCH_ATTR_BANDWIDTH                /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_DC_VOLTAGE             IVISWTCH_ATTR_MAX_DC_VOLTAGE           /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_AC_VOLTAGE             IVISWTCH_ATTR_MAX_AC_VOLTAGE           /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_SWITCHING_AC_CURRENT   IVISWTCH_ATTR_MAX_SWITCHING_AC_CURRENT /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_SWITCHING_DC_CURRENT   IVISWTCH_ATTR_MAX_SWITCHING_DC_CURRENT /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_CARRY_AC_CURRENT       IVISWTCH_ATTR_MAX_CARRY_AC_CURRENT     /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_CARRY_DC_CURRENT       IVISWTCH_ATTR_MAX_CARRY_DC_CURRENT     /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_SWITCHING_AC_POWER     IVISWTCH_ATTR_MAX_SWITCHING_AC_POWER   /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_SWITCHING_DC_POWER     IVISWTCH_ATTR_MAX_SWITCHING_DC_POWER   /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_CARRY_AC_POWER         IVISWTCH_ATTR_MAX_CARRY_AC_POWER       /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_MAX_CARRY_DC_POWER         IVISWTCH_ATTR_MAX_CARRY_DC_POWER       /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_CHARACTERISTIC_IMPEDANCE   IVISWTCH_ATTR_CHARACTERISTIC_IMPEDANCE /* ViReal64, Channel-based, Read-only */
#define NISWITCH_ATTR_NUM_OF_ROWS                IVISWTCH_ATTR_NUM_OF_ROWS              /* ViInt32, Read-only */
#define NISWITCH_ATTR_NUM_OF_COLUMNS             IVISWTCH_ATTR_NUM_OF_COLUMNS           /* ViInt32, Read-only */
#define NISWITCH_ATTR_WIRE_MODE                  IVISWTCH_ATTR_WIRE_MODE                /* ViInt32, Channel-based, Read-only */


/**************************************************************************** 
 *------------------------ Attribute Value Defines -------------------------* 
 ****************************************************************************/


    /* Defined values for the niSwitch_SingleSwitchControl and */
    /* niSwitch_SingleSwitchQuery opertions */
#define NISWITCH_VAL_SWITCH_OPEN									0
#define NISWITCH_VAL_SWITCH_CLOSE									1
#define NISWITCH_VAL_SWITCH_CLOSED				 NISWITCH_VAL_SWITCH_CLOSE


/*- VISA Types --------------------------------------------------------------*/
typedef unsigned long       ViUInt32;
typedef ViUInt32    *ViPUInt32;
typedef ViUInt32    *ViAUInt32;

typedef signed long     ViInt32;
typedef ViInt32     *ViPInt32;
typedef ViInt32     *ViAInt32;

typedef unsigned short      ViUInt16;
typedef ViUInt16    *ViPUInt16;
typedef ViUInt16    *ViAUInt16;

typedef signed short    ViInt16;
typedef ViInt16     *ViPInt16;
typedef ViInt16     *ViAInt16;

typedef unsigned char       ViUInt8;
typedef ViUInt8     *ViPUInt8;
typedef ViUInt8     *ViAUInt8;

typedef signed char ViInt8;
typedef ViInt8      *ViPInt8;
typedef ViInt8      *ViAInt8;

typedef char        ViChar;
typedef ViChar      *ViPChar;
typedef ViChar      *ViAChar;

typedef unsigned char       ViByte;
typedef ViByte      *ViPByte;
typedef ViByte      *ViAByte;

typedef void        *ViAddr;
typedef ViAddr      *ViPAddr;
typedef ViAddr      *ViAAddr;

typedef float       ViReal32;
typedef ViReal32    *ViPReal32;
typedef ViReal32    *ViAReal32;

typedef double      ViReal64;
typedef ViReal64    *ViPReal64;
typedef ViReal64    *ViAReal64;

typedef ViPByte     ViBuf;
typedef ViPByte     ViPBuf;
typedef ViPByte     *ViABuf;

typedef ViPChar     ViString;
typedef ViPChar     ViPString;
typedef ViPChar     *ViAString;

typedef ViString    ViRsrc;
typedef ViString    ViPRsrc;
typedef ViString    *ViARsrc;

typedef ViUInt16    ViBoolean;
typedef ViBoolean   *ViPBoolean;
typedef ViBoolean   *ViABoolean;

typedef ViInt32     ViStatus;
typedef ViStatus    *ViPStatus;
typedef ViStatus    *ViAStatus;

typedef ViUInt32    ViVersion;
typedef ViVersion   *ViPVersion;
typedef ViVersion   *ViAVersion;

typedef ViUInt32    ViObject;
typedef ViObject    *ViPObject;
typedef ViObject    *ViAObject;

typedef ViObject    ViSession;
typedef ViSession   *ViPSession;
typedef ViSession   *ViASession;

typedef ViUInt32            ViAttr;

#ifndef _VI_CONST_STRING_DEFINED
typedef const ViChar * ViConstString;
#define _VI_CONST_STRING_DEFINED
#endif
/*- End VISA Types --------------------------------------------------------------*/

// SCXI DLL initialisation
int SCXILoadDLL (void);
// return value
// 0 -> loading SCXI DLL failed
// 1 -> ok

/**************************************************************************** 
 *---------------- Instrument Driver Function Declarations -----------------* 
 ****************************************************************************/
    /*- Init and Close Functions -------------------------------------------*/
ViStatus niSwitch_init (ViRsrc resourceName, ViBoolean IDQuery,
                                  ViBoolean resetDevice, ViSession *vi);
ViStatus niSwitch_close (ViSession vi);   

    /*- Low Level Control Functions ----------------------------------------*/
ViStatus niSwitch_SingleSwitchControl (ViSession vi, 
												ViConstString switchName,
												ViInt16 switchAction);
ViStatus niSwitch_SingleSwitchQuery (ViSession vi, 
											  ViConstString switchName,
											  ViInt16 *switchState);
    /*- Error Functions ----------------------------------------------------*/
ViStatus niSwitch_error_query (ViSession vi, ViInt32 *errorCode,
                                         ViChar errorMessage[]);
ViStatus niSwitch_GetErrorInfo (ViSession vi, ViStatus *primaryError, 
                                          ViStatus *secondaryError, 
                                          ViChar errorElaboration[256]);
ViStatus niSwitch_ClearErrorInfo (ViSession vi);
ViStatus niSwitch_error_message (ViSession vi, ViStatus errorCode,
                                           ViChar errorMessage[256]);
    
    /*- Utility Functions --------------------------------------------------*/
ViStatus niSwitch_reset (ViSession vi);
ViStatus niSwitch_self_test (ViSession vi, ViInt16 *selfTestResult,
                                       ViChar selfTestMessage[]);
ViStatus niSwitch_revision_query (ViSession vi, 
                                            ViChar instrumentDriverRevision[],
                                            ViChar firmwareRevision[]);

/****************************************************************************
 *------------------------ Error And Completion Codes ----------------------*
 ****************************************************************************/
#define NISWITCH_WARN_PATH_REMAINS                 IVISWTCH_WARN_PATH_REMAINS
#define NISWITCH_WARN_IMPLICIT_CONNECTION_EXISTS   IVISWTCH_WARN_IMPLICIT_CONNECTION_EXISTS
#define NISWITCH_WARN_ID_NSUP					   VI_WARN_NSUP_ID_QUERY
#define NISWITCH_WARN_RESET_NSUP				   VI_WARN_NSUP_RESET

#define NISWITCH_ERROR_INVALID_SWITCH_PATH         IVISWTCH_ERROR_INVALID_SWITCH_PATH
#define NISWITCH_ERROR_INVALID_SCAN_LIST           IVISWTCH_ERROR_INVALID_SCAN_LIST
#define NISWITCH_ERROR_RSRC_IN_USE                 IVISWTCH_ERROR_RSRC_IN_USE
#define NISWITCH_ERROR_EMPTY_SCAN_LIST             IVISWTCH_ERROR_EMPTY_SCAN_LIST
#define NISWITCH_ERROR_EMPTY_SWITCH_PATH           IVISWTCH_ERROR_EMPTY_SWITCH_PATH
#define NISWITCH_ERROR_SCAN_IN_PROGRESS            IVISWTCH_ERROR_SCAN_IN_PROGRESS
#define NISWITCH_ERROR_NO_SCAN_IN_PROGRESS         IVISWTCH_ERROR_NO_SCAN_IN_PROGRESS
#define NISWITCH_ERROR_NO_SUCH_PATH                IVISWTCH_ERROR_NO_SUCH_PATH
#define NISWITCH_ERROR_IS_CONFIGURATION_CHANNEL    IVISWTCH_ERROR_IS_CONFIGURATION_CHANNEL
#define NISWITCH_ERROR_NOT_A_CONFIGURATION_CHANNEL IVISWTCH_ERROR_NOT_A_CONFIGURATION_CHANNEL
#define NISWITCH_ERROR_ATTEMPT_TO_CONNECT_SOURCES  IVISWTCH_ERROR_ATTEMPT_TO_CONNECT_SOURCES
#define NISWITCH_ERROR_EXPLICIT_CONNECTION_EXISTS  IVISWTCH_ERROR_EXPLICIT_CONNECTION_EXISTS
#define NISWITCH_ERROR_LEG_MISSING_FIRST_CHANNEL   IVISWTCH_ERROR_LEG_MISSING_FIRST_CHANNEL
#define NISWITCH_ERROR_LEG_MISSING_SECOND_CHANNEL  IVISWTCH_ERROR_LEG_MISSING_SECOND_CHANNEL
#define NISWITCH_ERROR_CHANNEL_DUPLICATED_IN_LEG   IVISWTCH_ERROR_CHANNEL_DUPLICATED_IN_LEG
#define NISWITCH_ERROR_CHANNEL_DUPLICATED_IN_PATH  IVISWTCH_ERROR_CHANNEL_DUPLICATED_IN_PATH
#define NISWITCH_ERROR_PATH_NOT_FOUND              IVISWTCH_ERROR_PATH_NOT_FOUND
#define NISWITCH_ERROR_DISCONTINUOUS_PATH          IVISWTCH_ERROR_DISCONTINUOUS_PATH
#define NISWITCH_ERROR_CANNOT_CONNECT_DIRECTLY     IVISWTCH_ERROR_CANNOT_CONNECT_DIRECTLY
#define NISWITCH_ERROR_CHANNELS_ALREADY_CONNECTED  IVISWTCH_ERROR_CHANNELS_ALREADY_CONNECTED
#define NISWITCH_ERROR_CANNOT_CONNECT_TO_ITSELF    IVISWTCH_ERROR_CANNOT_CONNECT_TO_ITSELF
#define NISWITCH_ERROR_INVALID_ATTRIBUTE		   IVI_ERROR_INVALID_ATTRIBUTE
#define NISWITCH_ERROR_IVI_ATTR_NOT_WRITABLE	   IVI_ERROR_IVI_ATTR_NOT_WRITABLE
#define NISWITCH_ERROR_IVI_ATTR_NOT_READABLE	   IVI_ERROR_IVI_ATTR_NOT_READABLE
#define NISWITCH_ERROR_INVALID_PARAMETER		   IVI_ERROR_INVALID_PARAMETER
#define NISWITCH_ERROR_INVALID_VALUE			   IVI_ERROR_INVALID_VALUE
#define NISWITCH_ERROR_ATTRIBUTE_NOT_SUPPORTED	   IVI_ERROR_ATTRIBUTE_NOT_SUPPORTED
#define NISWITCH_ERROR_INVALID_TYPE				   IVI_ERROR_INVALID_TYPE
#define NISWITCH_ERROR_TYPES_DO_NOT_MATCH		   IVI_ERROR_TYPES_DO_NOT_MATCH
#define NISWITCH_ERROR_INVALID_CONFIGURATION	   IVI_ERROR_INVALID_CONFIGURATION
#define NISWITCH_ERROR_VALUE_NOT_AVAILABLE		   IVI_ERROR_VALUE_NOT_AVAILABLE
#define NISWITCH_ERROR_ATTRIBUTE_VALUE_NOT_KNOWN   IVI_ERROR_ATTRIBUTE_VALUE_NOT_KNOWN
#define NISWITCH_ERROR_UNKNOWN_CHANNEL_NAME		   IVI_ERROR_UNKNOWN_CHANNEL_NAME
#define NISWITCH_ERROR_CHANNEL_NAME_REQUIRED	   IVI_ERROR_CHANNEL_NAME_REQUIRED
#define NISWITCH_ERROR_CHANNEL_NAME_NOT_ALLOWED	   IVI_ERROR_CHANNEL_NAME_NOT_ALLOWED
#define NISWITCH_ERROR_ATTR_NOT_VALID_FOR_CHANNEL  IVI_ERROR_ATTR_NOT_VALID_FOR_CHANNEL
#define NISWITCH_ERROR_ATTR_MUST_BE_CHANNEL_BASED  IVI_ERROR_ATTR_MUST_BE_CHANNEL_BASED
#define NISWITCH_ERROR_FUNCTION_NOT_SUPPORTED      IVI_ERROR_FUNCTION_NOT_SUPPORTED
#define NISWITCH_ERROR_SYSTEM_ERROR 			   VI_ERROR_SYSTEM_ERROR
#define NISWITCH_ERROR_FAIL_ID_QUERY			   VI_ERROR_FAIL_ID_QUERY
#define NISWITCH_ERROR_RSRC_NFOUND                 VI_ERROR_RSRC_NFOUND
#define NISWITCH_ERROR_INV_RSRC_NAME               VI_ERROR_INV_RSRC_NAME
#define NISWITCH_ERROR_INV_SESSION                 VI_ERROR_INV_OBJECT
#define NISWITCH_ERROR_TMO						   VI_ERROR_TMO

#define NISWITCH_ERROR_SESSION_ALREADY_OPEN        (IVI_SPECIFIC_ERROR_BASE + 1)
#define NISWITCH_ERROR_SCANLIST_AFTER_SCANTRIGGER  (IVI_SPECIFIC_ERROR_BASE + 2)

#endif /* __SCXI */




