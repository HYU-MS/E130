//***************************************************************************
//* Headerfile for implemented DIO functions in PCDiagNT Interpreter.       
//*                                                                          
//* Author: Tautz Stefan, Siemens AT SE RS T36, Diplomand                    
//*																			
//* These functions are needed to control a National Instruments 	
//* Data Aquisition plug-in board DIO-24.											
//*																			
//* further information: see Diplomarbeit									
//* "automatisiertes Testsystem CrashSimPlus V1.0" 
//* von Stefan Tautz, AT SE RS T36"*
//*																			
//* Datum: 02/2001															
//****************************************************************************
#ifndef _NIDAQ_Header_
#define _NIDAQ_Header_

/*************************************************************************
*
*    National Instruments NI-DAQ Windows - Function Prototypes
*    adapted to PCDiag Interpreter by Stefan Tautz, AT SE RS T36, 01/2001
*
*************************************************************************/


#include <stdio.h>
#include <math.h>


short   DIG_In_Line (short slot, short port, short linenum,short *state);
short   DIG_Out_Line (short slot, short port, short linenum, short state);
short   DIG_Prt_Config ( short slot, short port, short latch_mode, short direction);
short   DIG_Prt_Status ( short slot, short port, short *status);
short   Get_DAQ_Device_Info ( short deviceNumber,	unsigned long infoType,	unsigned long *infoVal);
// DIO DLL initialisation
int DIOLoadDLL(void);
// return value
// 0 => loading DIO DLL failed
// 1 => ok
//}

#endif //#define _NIDAQ_Header_



