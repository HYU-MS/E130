//***************************************************************************
//* Headerfile for implemented LPTPort IO-Access functions in PCDiagNT Interpreter.
//*                                                                          
//* Author: Thomas Funk                
//*																			
//* These functions are needed to control the LPTPort Driver files
//*
//* 																													
//*																			
//* 18.04.2012 Initial code
//****************************************************************************
#ifndef _LPTPort_Header_
#define _LPTPort_Header_


//****************************************************************************
//  Printer basis adresses

#define LPT1 "LPT1"
#define LPT2 "LPT2"



//****************************************************************************
//    Functions Prototypes

unsigned int LPTPortRead(char* PortName, int Offset, unsigned char* Value);
unsigned int LPTPortWrite(char* PortName, int Offset, unsigned char Value);


#endif //_LPTPort_