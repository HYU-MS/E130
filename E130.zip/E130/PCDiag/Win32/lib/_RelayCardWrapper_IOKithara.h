//***************************************************************************
//* This headerfile is a wrapper for the Continental RelayCard module in PCDiagNT Interpreter.
//*
//* Use for new projects the RelayCard.h file for direct access to the USB-Relay-Card
//*
//* Author: Thomas Funk                
//*
//*
//* 17.07.2012 Initial code
//****************************************************************************
#ifndef _IOKithara_Header_
#define _IOKithara_Header_

#include <RelayCard.h>


//****************************************************************************
//  Printer basis adresses

#define LPT1 "LPT1"
#define LPT2 "LPT2"

//****************************************************************************
//    Functions Prototypes

//****************************************************************************
// IOWritePort
unsigned int IOWritePort(char* ioPortName, int ioOffset, unsigned char value)
{
  return IOCardSetPort(0, value);
}

//****************************************************************************
// IOReadPort
unsigned int IOReadPort(char* ioPortName, int ioOffset, unsigned char* value)
{
  return IOCardGetPort(0, value);
}



#endif //_IOKithara_Header_