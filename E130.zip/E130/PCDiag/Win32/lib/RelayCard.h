//***************************************************************************
//* Headerfile for implemented USB-Relay-Card functions in PCDiagNT Interpreter.
//*                                                                          
//* Author: Thomas Funk                
//*																			
//* These functions are needed to control the USB Relay Card
//*
//* 																													
//*																			
//* 16.07.2012 Initial code
//* 17.04.2013 Change DLL-Version 2.0.0.0 IOCardSetPort() & IOCardGetPort() 8Bit --> 16Bit
//* 11.06.2013 Change DLL-Version 2.0.0.1 Add new functions IOSetSinglePort() & IOGetSinglePort() & IOGetTrigger() &
//*                                       IOGetTriggerLatched() & IOGetADRawData() & IOGet_HS_LS_Current() & IOGetVoltage()
//****************************************************************************
#ifndef _RelayCard_Header_
#define _RelayCard_Header_

//****************************************************************************
//  Constants for USB-Relay-Card

// PortIndex for IOSetSinglePort() and IOGetSinglePort()
#define LS_SWITCH_1 0x01
#define LS_SWITCH_2 0x02
#define LS_SWITCH_3 0x03
#define HS_SWITCH_1 0x04
#define HS_SWITCH_2 0x05
#define HS_SWITCH_3 0x06
#define RELAIS_1    0x07
#define RELAIS_2    0x08
#define RELAIS_3    0x09
#define RELAIS_4    0x0A
#define RELAIS_5    0x0B
#define RELAIS_6    0x0C

// Bit-Mask for IOCardSetPort() and IOCardGetPort()
#define LS_SWITCH_1_BIT 0x0001
#define LS_SWITCH_2_BIT 0x0002
#define LS_SWITCH_3_BIT 0x0004
#define HS_SWITCH_1_BIT 0x0008
#define HS_SWITCH_2_BIT 0x0010
#define HS_SWITCH_3_BIT 0x0020
#define RELAIS_1_BIT    0x0040
#define RELAIS_2_BIT    0x0080
#define RELAIS_3_BIT    0x0100
#define RELAIS_4_BIT    0x0200
#define RELAIS_5_BIT    0x0400
#define RELAIS_6_BIT    0x0800

// PortIndex for GetADRawData()
#define EVZ_VOLTAGE_RAWDATA_CHANNEL   1
#define VZ_C_VOLTAGE_RAWDATA_CHANNEL  2
#define VD_VOLTAGE_RAWDATA_CHANNEL    3
#define VCC5_VOLTAGE_RAWDATA_CHANNEL  4
#define VPERI_VOLTAGE_RAWDATA_CHANNEL 5
#define Res1_VOLTAGE_RAWDATA_CHANNEL  6
#define Res2_VOLTAGE_RAWDATA_CHANNEL  7
#define LS1_CURRENT_RAWDATA_CHANNEL   9
#define LS2_CURRENT_RAWDATA_CHANNEL   11
#define LS3_CURRENT_RAWDATA_CHANNEL   0
#define HS1_CURRENT_RAWDATA_CHANNEL   12
#define HS2_CURRENT_RAWDATA_CHANNEL   10
#define HS3_CURRENT_RAWDATA_CHANNEL   8

// PortIndex for Get_HS_LS_Current()
#define LS1_CURRENT_CHANNEL   1
#define LS2_CURRENT_CHANNEL   2
#define LS3_CURRENT_CHANNEL   3
#define HS1_CURRENT_CHANNEL   4
#define HS2_CURRENT_CHANNEL   5
#define HS3_CURRENT_CHANNEL   6

// PortIndex for GetVoltage()
#define EVZ_VOLTAGE_CHANNEL   1
#define VZ_C_VOLTAGE_CHANNEL  2
#define VD_VOLTAGE_CHANNEL    3
#define VCC5_VOLTAGE_CHANNEL  4
#define VPERI_VOLTAGE_CHANNEL 5
#define Res1_VOLTAGE_CHANNEL  6
#define Res2_VOLTAGE_CHANNEL  7




//****************************************************************************
//  Functions Prototypes for USB-Relay-Card - main functions
int IOCardGetCardsCount(void);
char* IOCardGetSerialNoByIndex(int DeviceIndex);
char* IOCardGetCardIDByIndex(int DeviceIndex);
int IOCardGetIndexBySerialNo(char* SerialNo);

//****************************************************************************
//  Functions Prototypes for USB-Relay-Card - Output functions
int IOCardSetPort(int DeviceIndex, unsigned short Value);
int IOCardGetPort(int DeviceIndex, unsigned short* Value);

int IOCardSetSinglePort(int DeviceIndex, unsigned char Value, unsigned char PortIndex);
int IOCardGetSinglePort(int DeviceIndex, unsigned char* Value, unsigned char PortIndex);

//****************************************************************************
//  Functions Prototypes for USB-Relay-Card - Input functions
int IOCardGetTrigger(int DeviceIndex, unsigned char* Value);
int IOCardGetTriggerLatched(int DeviceIndex, unsigned char* Value);

int IOCardGetADRawData(int DeviceIndex, unsigned short* Value, unsigned char PortIndex);
int IOCardGet_HS_LS_Current(int DeviceIndex, unsigned short* Value, unsigned char PortIndex);
int IOCardGetVoltage(int DeviceIndex, unsigned short* Value, unsigned char PortIndex);


#endif //_RelayCard_Header_




