//***************************************************************************
//* Headerfile for implemented Top16 IO-Board functions in PCDiagNT Interpreter.
//*                                                                          
//* Author: Thomas Funk                
//*																			
//* These functions are needed to control the Top16 io module
//*
//* 																													
//*																			
//* 12.01.2012 Initial code
//* 27.04.2012 New function SetPWM()
//****************************************************************************
#ifndef _IOBoard_Header_
#define _IOBoard_Header_




//****************************************************************************
//    Functions Prototypes for TOP16 IO-Board
int IOSetOutputs(int Reserved, unsigned char Value);
int IOGetInputs(int Reserved, unsigned char* Value);
int IOSetPWM(int Reserved, unsigned char PWM, unsigned char Output);

char* IOGetErrorText(int Error);



#endif //_IOBoard_Header_
