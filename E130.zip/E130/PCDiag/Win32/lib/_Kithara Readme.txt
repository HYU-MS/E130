There are 4 ways to switch external devices e.g. relays:

============================================================================

1. Via Continental RelayCard USB 
--------------------------   
  - this is the new way  
  - works with Windows XP, Windows 7 (32Bit & 64Bit)
  - Rename the file "_RelayCardWrapper_IOKithara.h" into "IOKithara.h"

============================================================================

2. Via Top16 IO module USB (Output connect to a relay direct)
--------------------------   
  - this is the new way  
  - works with Windows XP, Windows 7 (32Bit & 64Bit)
  - Rename the file "_Top16Wrapper_IOKithara.h" into "IOKithara.h"

============================================================================

3. Via Top16 IO module USB (Output use as LPT like with a pullup resistor to vcc --> the logic is inverted)
--------------------------   
  - this is the new way  
  - works with Windows XP, Windows 7 (32Bit & 64Bit)
  - Rename the file "_Top16Wrapper_Invert_IOKithara.h" into "IOKithara.h"

============================================================================

4. Via LPT Port and the WinRing0 driver
--------------------------------------
  - this is the old way 
  - works with Windows XP, Windows 7 (32Bit & 64Bit)
  - Rename the file "_LPTPortWrapper_IOKithara.h" into "IOKithara.h"




