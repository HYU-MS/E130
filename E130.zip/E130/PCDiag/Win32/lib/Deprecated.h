#include PModeD.h

// Wrapper functions, don't use in new scripts
unsigned int PModeParamGet32BitAddress(char *Topic, char *Context)  
{ 
  return PModeParamGetAddress(Topic, Context);  
}

unsigned int PModeParamGet32BitAddress2(char *Topic, char *Context) 
{ 
  return PModeParamGetAddress2(Topic, Context); 
}