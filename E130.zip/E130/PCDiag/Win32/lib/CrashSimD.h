//******************************************************************************
// CrashSim Header
//******************************************************************************
#ifndef _CrashSimD_
#define _CrashSimD_


// --- Analog Outputs ----------------------------------------------------------
void ChannelSetFilename(int Channel, char *FileName);
void ChannelGetFilename(int Channel, char *FileName);

void ChannelSetScale(int Channel, double Scale);
void ChannelIncScale(int Channel, double Inc);
void ChannelGetScale(int Channel, double *Scale);

void ChannelSetOffset(int Channel, double Offset);
void ChannelIncOffset(int Channel, double Inc);
void ChannelGetOffset(int Channel, double *Offset);

void ChannelSetDelay(int Channel, int Delay);
void ChannelIncDelay(int Channel, int Inc);
void ChannelGetDelay(int Channel, int *Delay);

void ChannelSetLink(int Channel, int Link);
void ChannelGetLink(int Channel, int *Link);

// ------- Selftest Inputs ST --------------------------------------------------
void ChannelSetZero(int Channel, double Zero);
void ChannelIncZero(int Channel, double Inc);
void ChannelGetZero(int Channel, double *Zero);

void ChannelSetSelfTest(int Channel, double SelfTest);
void ChannelIncSelfTest(int Channel, double Inc);
void ChannelGetSelfTest(int Channel, double *SelfTest);

void ChannelSetSense(int Channel, double Sense);
void ChannelIncSense(int Channel, double Inc);
void ChannelGetSense(int Channel, double *Sense);

void ChannelSetPWM(int Channel, int PWM);
void ChannelGetPWM(int Channel, int *PWM);

void ChannelSetGain(int Channel, double Gain);
void ChannelIncGain(int Channel, double Inc);
void ChannelGetGain(int Channel, double *Gain);

void ChannelSetCenter(int Channel, double Center);
void ChannelIncCenter(int Channel, double Inc);
void ChannelGetCenter(int Channel, double *Center);

// --- Comparator Inputs -------------------------------------------------------
void InputSetZPThresholds(int Box, int Group, double Threshold);
void InputGetZPThresholds(int Box, int Group, double *Value);
void InputGetTTF(int Box, int Channel, double *Value);
void InputGetDUR(int Box, int Channel, double *Value); 

// --- Digital Outputs TTL and Relays ------------------------------------------
void SetDigitalOutput(int Box, int Channel, int ValueHigh, int ValueLow);
void GetDigitalOutput(int Box, int Channel, int *ValueHigh, int *ValueLow);

// --- Hardware Property -------------------------------------------------------
int  Booted(void);
int  ZPBoxesFound(void);
int  RelayBoxesFound(void);

// --- CrashSim Property -------------------------------------------------------
void CrashSimSetStopTime(int StopTime);
int  CrashSimGetStopTime(void);

void CrashSimSetSTDelay(int DelayHigh, int DelayLow);
void CrashSimGetSTDelay(int *DelayHigh, int *DelayLow);

void CrashSimSetSampleRate(int SampelRate);
int  CrashSimGetSampleRate(void);

void CrashSimSetCrashSimTrigger(int Trigger);
int  CrashSimGetCrashSimTrigger(void);

// --- CrashSim Functions ------------------------------------------------------
char *CrashSimGetVersion(void);
void CrashSimInit(void);
int  CrashSimBoot(void);
void CrashSimExecute(void);
void CrashSimResetDefaultValues(void);

// --- Delay -------------------------------------------------------------------
void PAUSE(int Time);

// --- Logfile -----------------------------------------------------------------
void CrashSimSetLogging(int Flag);
void CrashSimSetLogFileName(char *FileName);
void CrashSimSetLogTypes(int Call, int CallResult, int Details, int AdWin, int Error);

// --- DataFiles ---------------------------------------------------------------
int OpenFileList(char *FileName);
char *GetFileName(int index);




// --- Load the Dll before use any other function in your C-Interpreter program -------------------
int CrashSimLoadDLL(void);
// return value
// 0 => loading CrashSimD Library failed
// 1 => ok



#endif // _CrashSimD_






