#ifndef _CrashSim_
#define _CrashSim_

//******************************************************************************
#include <stdio.h>
#include "CrashSimD.h"
#include "string.h"

int    ValueInt;
char   ValueChar[255];
double ValueDouble;

//******************************************************************************
double getTTF(int Channel)
    { InputGetTTF(0, Channel, &ValueDouble); return ValueDouble; }


char *getFILENAME(int Channel)
    { ChannelGetFilename(Channel, ValueChar); return ValueChar; }


int FILENAME(int Channel, char *value)
{
 int iResult;
 ChannelSetFilename(Channel, value);
 ChannelGetFilename(Channel, ValueChar); 
 iResult = strcmp(value, ValueChar); // iResult == 0 contents equal
 return iResult;
}


void SCALE(int Channel, double value)
    { ChannelSetScale(Channel, value); }
void incSCALE(int Channel, double value)
    { ChannelIncScale(Channel, value); }
double getSCALE(int Channel)
    { ChannelGetScale(Channel, &ValueDouble); return ValueDouble; }


void OFFSET(int Channel, double value)
    { ChannelSetOffset(Channel, value); }
void incOFFSET(int Channel, double value)
    { ChannelIncOffset(Channel, value); }
double getOFFSET(int Channel)
    { ChannelGetOffset(Channel, &ValueDouble); return ValueDouble; }


void DELAY(int Channel, int value)
    { ChannelSetDelay(Channel, value); }
void incDELAY(int Channel, int value)
    { ChannelIncDelay(Channel, value); }
int getDELAY(int Channel)
    { ChannelGetDelay(Channel, &ValueInt); return ValueInt; }


void LINK(int Channel, int value)
    { ChannelSetLink(Channel, value); }
int getLINK(int Channel)
    { ChannelGetLink(Channel, &ValueInt); return ValueInt; }


void ZERO(int Channel, double value)
    { ChannelSetZero(Channel, value); }
void incZERO(int Channel, double value)
    { ChannelIncZero(Channel, value); }
double getZERO(int Channel)
    { ChannelGetZero(Channel, &ValueDouble); return ValueDouble; }


void SELFTEST(int Channel, double value)
    { ChannelSetSelfTest(Channel, value); }
void incSELFTEST(int Channel, double value)
    { ChannelIncSelfTest(Channel, value); }
double getSELFTEST(int Channel)
    { ChannelGetSelfTest(Channel, &ValueDouble); return ValueDouble; }


void SENSE(int Channel, double value)
    { ChannelSetSense(Channel, value); }
void incSENSE(int Channel, double value)
    { ChannelIncSense(Channel, value); }
double getSENSE(int Channel)
    { ChannelGetSense(Channel, &ValueDouble); return ValueDouble; }


void PWM(int Channel, int value)
    { ChannelSetPWM(Channel, value); }
int getPWM(int Channel)
    { ChannelGetPWM(Channel, &ValueInt); return ValueInt; }


void GAIN(int Channel, double value)
    { ChannelSetGain(Channel, value); }
void incGAIN(int Channel, double value)
    { ChannelIncGain(Channel, value); }
double getGAIN(int Channel)
    { ChannelGetGain(Channel, &ValueDouble); return ValueDouble; }


void CENTER(int Channel, double value)
    { ChannelSetCenter(Channel, value); }
void incCENTER(int Channel, double value)
    { ChannelIncCenter(Channel, value); }
double getCENTER(int Channel)
    { ChannelGetCenter(Channel, &ValueDouble); return ValueDouble; }




//******************************************************************************
void DIO(int Channel, int valuehigh, int valuelow)
   { SetDigitalOutput(0, Channel, valuehigh, valuelow); }



//******************************************************************************

void FREQUENCY(double value)
   { CrashSimSetSampleRate(value); }

double getFREQUENCY(void)
   { return CrashSimGetSampleRate(); }

void STOP_TIME(int value)
   { CrashSimSetStopTime(value); }

void ST_DELAY(int valuehigh, int valuelow)
   { CrashSimSetSTDelay(valuehigh, valuelow); }

void ZP_THRESHOLD(int value)
   {
     ValueDouble = value;
     InputSetZPThresholds(0, 1, ValueDouble);
   }

void TRIGGER(int value)
   { CrashSimSetCrashSimTrigger(value); }

void EXECUTE(void)
   { CrashSimExecute(); }


void RECORDRESULTS(void)
{ int i = 1;
  printf( "CHAN  \tTTF    \t\tSCALE  \t\tOFFSET[units]  \tDELAY[ms]  \tLINK  \tFILENAME \n");
  for (i=1; i<8; i++)
  {
    printf(" %i: \t%f \t%f \t%f \t%i \t\t%i %s \n", i, getTTF(i), getSCALE(i), getOFFSET(i), getDELAY(i), getLINK(i), getFILENAME(i) );
  }
}

#endif // _CrashSim_