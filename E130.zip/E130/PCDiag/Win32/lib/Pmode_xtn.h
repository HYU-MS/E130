#ifndef _INC_Pmode_xtn
#define _INC_Pmode_xtn

void  Pmode_login(void);



#endif

//Pmode Login with Error-Handling
void Pmode_login()
  {  int iretvalue;
     Login();
     iretvalue = CheckError();
     if (iretvalue == 1)
     {   printf("Pmode Login not successful\n");
         return 0;
     }
     printf("Pmode-Login successful\n");
  }
