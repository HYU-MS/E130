#ifndef _PModeD
#define _PModeD

//******************************************************************************
// PMode Header   PModeD.Dll Version 1.2.3.2
//******************************************************************************

// --- CAN type used from CANListenerOpen()
#define cCANTypeCAN   1
#define cCANTypeCANFD 2

// --- This protocols are implemented, use it at the function SetProtocolTyp()
// PMode
#define cPMODE            "PMODE"

// EOL ETS-Toolbox
#define cEOL              "EOL"

// Diagnostic
#define cAUDIUDS          "AUDIUDS"
#define cBMW              "BMW"
#define cDC               "DC"
#define cDAIMLERUDS       "DAIMLERUDS"
#define cFIAT             "FIAT"
#define cFORD             "FORD"
#define cGMDAT            "V250"
#define cHMCCAN           "HMCCAN"
#define cHKMCUDS          "HKMCUDS"
#define cHONDA            "HONDA"
#define cHONDAUDS         "HONDAUDS"
#define cHyundaiKia       "HYUNDAIKIA"
#define cMCLARENUDS       "MCLARENUDS"
#define cOCSSUZUKI        "OCSSUZUKI"
#define cOCSNISSAN        "OCSNISSAN"
#define cRENAULTUDS       "RENAULTUDS"
#define cSMARTL20         "SMARTL20"
#define cSRESMART         "SRESMART"
#define cSRENCS           "SRENCS"
#define cSUZUKIUDS        "SUZUKIUDS"
#define cSUZUKICAN        "SUZUKICAN"
#define cSUZUKIKLINE      "SUZUKIKLINE"
#define cSYMC             "SYMC"
#define cSYMCCAN          "SYMCCAN"
#define cSYMCUDS          "SYMCUDS"
#define cVWDTS            "VWDTS"
#define cVWUDS            "VWUDS"
#define cV250             "V250"

// Scrapping
#define cScrapping        "SCRAPPING"

// --- These constants are used by ETS-Toollbox functions ----------------------
#define cETSToolboxTypeUnicom_rh850_f1l	           1  // Renasas: two Unicom files rh850_f1l_os_speed30_conti_xxx.tbx & rh850_f1l_flash_xxx.tbx
#define cETSToolboxTypeUnicom_Infineon_TriCore	   2  // Aurix: one Unicom file vw40_rpg_conti_V140_500.tbx

#define cETSTargetDataFlash    1                      // flash into the data flash memory
#define cETSTargetCodeFlash    2               	      // flash into the code flash memory

#define cETSWriteModeComplete  0x00000001             // flash complete page(s), all data of a page must be available
#define cETSWriteModeMerge     0x00000002             // flash only the data are in the file available: read out page, merge data and flash

#define cETSStepEraseBit       0x00010000             // Bit for execute erase data
#define cETSStepFlashBit       0x00020000             // Bit for execute flash data
#define cETSStepCRCVerifyBit   0x00040000             // Bit for execute CRC verify data
#define cETSStepReadVerifyBit  0x00080000             // Bit for execute Read verify data

#define HEXOPT_NO_RUN 0                               // No run HexOpt before flash data
#define HEXOPT_RUN    1                               // Run HexOpt before flash data

// --- These constants are used by the SetCANParameters() for set ChannelNo to select the correct CAN device. ----
#define cCANVectorDeviceOffset     0x00      // 01h..20h --> Vector CAN devices
#define cCANPeakDeviceOffset       0x20      // 21h..40h --> PEAK CAN devices
#define cCANNeoIVDeviceOffset      0x40      // 41h..60h --> NeoIV CAN devices via AIDA-API access
#define cCANNeoIVFire2DeviceOffset 0x60      // 61h..80h --> NeoIV FIRE2 CAN devices direct access


// --- These constants are used by the function CopyData() --------------------
#define PCtoECU 0
#define ECUtoPC 1


// --- These constants are used by the function VWDTSSecurityAccess() ---------
#define cModeDiagnostic   0x89
#define cModeEOL          0x83
#define cModeDeveloper    0x86



// --- Struct for the functions *.pcd file functions GetSingleParameter() ------
// Available by PCDiagNT version 2.9.x.x

// Masks used by tParameter.ProtocolMask
#define cProtGeneralMask      0x01
#define cProtDiagnosticMask   0x02
#define cProtPModeMask        0x04
#define cProtSatelliteMask    0x08
#define cProtToolsMask        0x10
#define cProtAllMask          0x1F

// DataTypes used by tParameter.DataTypes
#define csInt8Type            0x81  // used by tParameter.AsSInt8
#define cuInt8Type            0x01  // used by tParameter.AsUInt8
#define csInt16Type           0x82  // used by tParameter.AsSInt16
#define cuInt16Type           0x02  // used by tParameter.AsUInt16
#define csInt32Type           0x84  // used by tParameter.AsSInt32
#define cuInt32Type           0x04  // used by tParameter.AsUInt32
#define cDoubleType           0x09  // used by tParameter.AsDouble
#define cBooleanType          0x0A  // used by tParameter.AsBool
#define cStringType           0x0B  // used by tParameter.AsString[256]
#define cByteARType           0x0C  // used by tParameter.AsString[256]
#define cByteARDontCareType   0x0D  // used by tParameter.AsString[256]
#define cEnumType             0x0E  // used by tParameter.AsUInt8

//------------------------------------------------------------------------------
// Available by PCDiagNT version 2.9.x.x
/*typedef
  struct tParameter {
                    int             DataType;
                    unsigned char   ProtocolMask;
                    char            THFInt8;
                    unsigned char   THFUInt8;
                    short           THFSInt16;
                    unsigned short  THFUInt16;
                    int             THFSInt32;
                    unsigned int    THFUInt32;
                    double          THFDouble;
                    int             THFBool;
                    char            THFString[256];
};

typedef
  struct tListNode {
                   int            ItemCount;
                   int            ColumnCount;
                   char           Description[256];
                   int            EnumID;
                   int            NodePtr;
        };
*/

// --- Struct for the functions PModeParamFirstTopic() & PModeParamNextTopic() -
// Available by PCDiagNT version 2.7.x.x, PModeD.dll version 1.1.7.0
typedef
  struct sIniParameter {
                       char           Typ[256];
                       char           SW[256];
                       char           Text[256];
                       char           Variable[256];
                       int            Wert;
                       unsigned int   Adresse;
                       unsigned int   Adresse2;
                       unsigned short Anzahl;
                       unsigned char  Verknuepfung;
                       unsigned char  Verarbeitung;
                       double         Faktor1;
                       double         Faktor2;
                       double         Faktor3;
                       char           Kurztext1[256];
                       char           Kurztext2[256];
                       char           MaskenNr[256];
                       };


// --- Structs for the Virtual Car VCxx functions ------------------------------
typedef
  struct tVCarTxdData    {
                         int            Active;                 // 0 = false; 1 = true
                         int            ExtendedIDFlag;         // 0 = false; 1 = true
                         unsigned int   ID;                     // CAN ID
                         int            DataCount;              // Count of used Data[]
                         unsigned char  Data[64];                // Data to send 0x00 ..0xFF
                         };

  struct tVCarRxdData    {
                         int            Active;                 // 0 = false; 1 = true
                         int            Action;                 // 0 = None; 1 = Stop; 2 = Start; 3 = Incrase; 4 = Decrase; 5 = IncraseSigned; 6 = DecraseSigned
                         int            ExtendedIDFlag;         // 0 = false; 1 = true
                         unsigned int   ID;                     // CAN ID
                         int            DataCount;              // Count of used Data[] and DatMask[]
                         unsigned char  Data[64];               // Data to receive 0x00 ..0xFF
                         unsigned char  DataMask[64];           // Data mask to mask out the Data[64] value receive 0x00 ..0xFF
                         unsigned int   StepValue;              // Step value, only used by Action = 3(Incrase) or 4(Decrase) or 5(IncraseSigend) or 6(DecraseSigned)
                         int            StepCycleTime;          // Step cycle value, only used by Action = 3(Incrase) or 4(Decrase) or 5(IncraseSigend) or 6(DecraseSigned)
                         };


  struct tVCar           {                            
                         int                  Type;                  // 0 = Unknown; 1 = Request; 2 = RequestResponse
                         int                  StartDelayTime;        // Start delay time in [ms]
                         int                  CycleTime;             // Cycle time in [ms]
                         struct               tVCarTxdData TxtData;  // TXD data set
                         int                  RxdDataListCount;      // Count of used RxdDataList[]
                         struct tVCarRxdData  RxdDataList[10];       // RXD data set list
                         };


// --- Structs for the CAN Listener functions ----------------------------------
typedef
  struct tCANFilter      {
                         int            ExtendedIDFlag;         // 0 = false; 1 = true
                         unsigned int   ID;                     // CAN ID
                         };

  struct tCANRxdData     {
                         int            ExtendedIDFlag;         // 0 = false; 1 = true
                         unsigned int   ID;                     // CAN ID
                         unsigned int   TimeStamp;              // TimeStamp [ms]. Relative time starts by call CANListenerOpen() or CANListenerClearMessages()
                         int            DataCount;              // Count of used Data[]
                         unsigned char  Data[64];               // Data to send 0x00 ..0xFF
                         };





// --- Protocol select function ------------------------------------------------
void SetProtocolTyp(char *ProtocolName);

// --- Standard protocol functions ---------------------------------------------
void Login(void);
void Logout(void);
void Reset(void);
void SwitchToPMode(void);
void ChangeAccessLevel(int Level);
void Identification(void);
void CopyData(int Direction, unsigned char* PCAddress, int ECUAddress, int Size);
void ReadMemory(unsigned char* PCAddress, int ECUAddress, int Size);
void WriteMemory(unsigned char* PCAddress, int ECUAddress, int Size);
int GetReceivedTelegram(unsigned char *Data, int Size);
int GetReceivedData(unsigned char *Data, int Size);
int GetReceivedDataFormated(void *Data, int ArraySize, int BlockSize);
void SendTelegram(unsigned char *Data, int Size, int AddLBCS);
void ArchiveMemory(unsigned int *AdrList, unsigned int *AdrSizeList, unsigned short *NvmList, int AdrCount, int NvmCount, char *FileName, char *aHeader);

// --- PMode only functions ----------------------------------------------------
void FastLogin(void);

void ReadMemory24Bit(unsigned char* PCAddress, int ECUAddress, int Size);
void WriteMemory24Bit(unsigned char* PCAddress, int ECUAddress, int Size);

void ReadMemory32Bit(unsigned char* PCAddress, unsigned int ECUAddress, unsigned int Size);
void WriteMemory32Bit(unsigned char* PCAddress, unsigned int ECUAddress, unsigned int Size);

unsigned int ReadMemoryAutosar(unsigned char* PCAddress, unsigned int AutosarID, unsigned int Size);
void WriteMemoryAutosar(unsigned char* PCAddress, unsigned int AutosarID, unsigned int Size);
unsigned int ReadAutosarSize(unsigned int AutosarID, unsigned int* BlockSize, unsigned int* BlockCount);

void LEDTest(int LED1, int LED2);

void SingleFaultTest(int TimeOut);
void StartSingleFaultTest(int TimeOut, char *FileName);
void StopSingleFaultTest(void);

void SingleFaultTest2Byte(int TimeOut);
void StartSingleFaultTest2Byte(int TimeOut, char *FileName);
void StopSingleFaultTest2Byte(void);

void BlockWiseFaultTest(int BlockCode, int TimeOut);
void StartBlockWiseFaultTest(int BlockCode, int TimeOut, char *FileName);
void StopBlockWiseFaultTest(void);

void DemandMeasureValues(int Code, int Count, int TimeOut);
void StartDemandMeasureValues(int Code, int RecordCount, int TimeOut, int RecordSize, char *FileName);
void StopDemandMeasureValues(void);

void DemandMeasureValues16Bit(int Code, int Count, int TimeOut, int RecordSize);
void StartDemandMeasureValues16Bit(int Code, int RecordCount, int TimeOut, int RecordSize, char *FileName);
void StopDemandMeasureValues16Bit(void);

void BlockWiseMeasureValues(int BlockCode, int Code, int Count, int TimeOut);
void StartBlockWiseMeasureValues(int BlockCode, int Code, int RecordCount, int TimeOut, int RecordSize, char *FileName);
void StopBlockWiseMeasureValues(void);

void SendUserProgram(char *Data);
void StartSendUserProgramReturn(char *Data, int Timeout, char *FileName);
void StopSendUserProgramReturn(void);

void WriteFileToMemory(char *Filename, int FileType, int AddressType);

void LoadMappingIDFile(char *FileName, int MappingIDCheck);
void WriteUnitCalibration(char *FileName);
void WriteUnitCalibration16Bit(char *FileName);
void WriteUnitCalibration24Bit(char *FileName);
void WriteUnitCalibration32Bit(char *FileName);
void WriteUnitCalibrationAutosar(char *FileName);


void FSRMeasurement(int FSRByteOne, int FSRByteTwo);
void ClearMemory(char *Topic);
void ClearFaultMemory(void);
void ClearEDRMemory79(void);

// --- EOL ETS-Toolbox functions ----------------------------------------------
void ActivateETSToolbox(int ToolboxType, char *LogFileName);
void DeactivateETSToolbox(void);

void EraseETSPage(int StartPage, int Count, char *HexOptFileName, int FlashTarget);
void FlashETSFile(char *FlashFileName, char *HexOptFileName, int FlashTarget, int RunHexOpt, int WriteMode, int HexOptOutputIndex);

int GetHexOptOutputCount(char *HexOptFileName);
char *GetHexOptOutputByIndex(char *HexOptFileName, int Index);

// --- GMDAT-Diagnostic functions ----------------------------------------------
void GMDATStartRoutineByLocalID(unsigned char LID);
void GMDATStopRoutineByLocalID(unsigned char LID);
void GMDATReadCrashRecording(unsigned char LID);
void GMDATReadLocalID(unsigned char LID);
void GMDATReadDTC(void);
void GMDATClearFaultMemory(void);

// --- HONDA-Diagnostic functions ----------------------------------------------
void HondaAllECUInitialization(int TZ1, int TZ2, int TZ3);
void HondaSRSECUInitialization(unsigned char *Commands, int Count, int SRSFirst, int TZ1, int TZ2, int TZ3, int TZ10);
int HondaClear(int Command);
int HondaFaultRecordClear(void);
int HondaOpRecordClear(void);
int HondaAllClear(void);
void HondaSleepDeactivate(void);
void HondaSleepProhibit(void);
void HondaStartODU(void);
void HondaStopODU(void);
void HondaSingleFunctionTest(int Command);
int HondaSensorCompensation(int ODUCode, int Command);
void HondaReadMemoryODU(unsigned char *PCAddress, int ECUAddress, int Size, int ODUCode);
void HondaReadMemoryExpanded(unsigned char *PCAddress, int ECUAddress, int Size, int Bank);
void HondaSendHexFile(char *HexFileName, char SendMethod, unsigned char *EncodeKey);

// --- FIAT-Diagnostic functions -----------------------------------------------
void FiatSnapShot(int No);
void FiatReadEventMemory(void);
void FiatReadParameter(int RequestCode);
void FiatWriteParameter(int RequestCode, unsigned char *Data, int Size);
void FiatActiveDiagnosis(int ComponentCode);
void FiatClearErrorMemory(void);

// --- FORD-Diagnostic functions -----------------------------------------------
void FordOpStateEntry(void);
void FordDiagStateEntry(void);
void FordDiagnosticCommand(unsigned short Command, unsigned char Data);
void FordRequestStoredCodes(void);
void FordParameterByPID(unsigned short PID);
void FordClearStoredCodes(void);
void FordSecurityAccess(unsigned char SubMode, unsigned short Key);
void FordReadMemoryBlock(unsigned char BlockNo);
void FordWriteMemoryBlock(unsigned char BlockNo, unsigned char *Data);
void FordWriteUnitCalibration(char *FileName);

void FordDiagnosticRoutineEntry(unsigned char TestNo);
void FordDiagnosticRoutineExit(unsigned char TestNo, int ExitIfComplete);
void FordDiagnosticRoutineResults(unsigned char TestNo);

// --- SRE-SMART-Diagnostic functions ------------------------------------------
void SRESMARTTestMode(unsigned char Count, unsigned char *Data);

// --- SRE-NCS-Diagnostic functions --------------------------------------------
void SRENCSSnapShot(void);
void SRENCSReadStatus(void);
void SRENCSReadOperationTime(void);
void SRENCSClearFaultMemory(void);

// --- VW DTS Keyword2000-Diagnostic functions ---------------------------------
void VWDTSSecurityAccess(int UserMode);
void VWDTSReadChannel(int Channel, int *DeviceNr, int *ImportNr, int *GarageNr, int *State, int *aabb);
void VWDTSWriteChannel(int Channel, int DeviceNr, int ImportNr, int GarageNr, int StateFlag);
void VWDTSReadNormedValues(int Block);

// --- OCS-Suzuki and OCS-Nissan functions -------------------------------------
void OCSRequest(unsigned char* TXD, int TXDSize, unsigned char* RXD, int* RXDSize, int AutoCS);

// --- KWP2000 / UDS CAN functions (HMCCAN & SuzukiCAN & SuzukiKLine & DC & VW/AUDI & McLaren & Scrapping) ----
void AutoTesterPresent(int Flag);
void TesterPresent(int IntervalTime);
void ECUReset(unsigned char Mode);
void SecurityAccess(int SendKey);
void StartDiagnosticSession(int SessionID, int ExecuteSecurityAccess);
void StopDiagnosticSession(void);
void ECUIdentification(unsigned char Option);
void ReadDataByIdentifier(unsigned int Identifier);
void WriteDataByIdentifier(unsigned int Identifier, unsigned char *Data, int Size);
void ReadDataByLocalIdentifier(unsigned char LocalID);
void WriteDataByLocalIdentifier(unsigned char LocalID, unsigned char *Data, int Size);
void ReadDTCByStatus(unsigned char Status, unsigned int Group);
void ReadStatusOfDTC(unsigned int Group);
void ReadFreezeFrameData(unsigned char FrameNo, unsigned char AccessID, unsigned char LID);
void InputOutputControlByLocalIdentifier(unsigned char LocalID, unsigned char *Data, int Size);
void DisableNormalMessageTransmission(unsigned char ResponseRequired);
void EnableNormalMessageTransmission(unsigned char ResponseRequired);
void ControlDTCSettingMode(unsigned char ResponseRequired, unsigned short Group, unsigned char Mode);
void ClearDiagnosticInformation(unsigned int Group);
void FunctRoutineRun(unsigned char ID, unsigned char *Data, int Size);
void StartRoutineByLocalIdentifier(unsigned char ID, unsigned char *Data, int Size);
void StopRoutineByLocalIdentifier(unsigned char ID);
void RequestRoutineResultByLocalIdentifier(unsigned char ID);
void RoutineControl(unsigned char ControlType, unsigned char *Data, int Size);
void ReadDTC(unsigned char Type, unsigned char *Parameter, int Size);
void ReadDTCByStatusMask(unsigned char StatusMask);
void ReadDTCExtendedDataRecordingByDTCNumber(unsigned int GroupOfDTC, unsigned char ExtDataRecNo);
void InputOutputControlByIdentifier(unsigned short Identifier, unsigned char *Data, int Size);
void ControlDTCSettings(unsigned char Type, unsigned char *Parameter, int Size);
void ControlDTCSetting(unsigned char Type, unsigned int Option);
void CommunicationControl(unsigned char ControlType, unsigned char ComType);

// --- Virtual Car functions ---------------------------------------------------
void VCarOpen(int LoadIniSettings);
void VCarClose(void);
void VCarStart(void);
void VCarStop(void);

int VCarElementCount(void);
int VCarGetElement(int Index, struct tVCar *Element);
int VCarSetElement(int Index, struct tVCar *Element);
int VCarNewElement(void);
void VCarDeleteElement(int Index);

// --- CAN Listener functions ---------------------------------------------------
void CANListenerOpen(struct tCANFilter *FilterList, int FilterCount, int CANType);
void CANListenerClose(void);
void CANListenerClearMessages(void);
void CANListenerGetMessages(struct tCANFilter *Filter, struct tCANRxdData *MessagesList, int *MessagesCount);

// --- Error handling ----------------------------------------------------------
int GetErrorCode(void);
char *GetErrorText(int ErrorCode);

// --- Non-PMode functions -----------------------------------------------------
void SleepDelay(int Time);
char *PModeGetVersion(void);
char *GetProtocolName(void);

void LoadHexFile(char *HexFileName, int *BlockCount);
void GetHexFileData(int Index, unsigned int *Address, unsigned int *Size, unsigned char *Data);

// --- Protocol-Parameter set functions ----------------------------------------
void SetBreakChar(char BreakChar);
void SetLoginChar(char EntryChar, char EntryAckChar);
void SetLoginOption(char *CtrlSequence);
void SetTimes(int InterByteTime, int InterBlockTime, int ResetTime, int DelayTime, int TimeOut);
void SetReadWriteSize(int maxReadSize, int maxWriteSize);
void SetSerialPort(int Port, int Baudrate, int DataBits, int Parity, int StopBits);
void SetBaudRates(int Normal, int Fast);

void SetCANParameters(int Channel, int Bitrate, int UseBitrateStack);

// --- Project-File *.prj functions --------------------------------------------
int SetIniFile(char *iName, char *iType, int CommPort);
int PModeParamGetFirstTopic(char *Topic, struct sIniParameter *IniParameter);
int PModeParamGetNextTopic(struct sIniParameter *IniParameter);
unsigned int PModeParamGetAddress(char *Topic, char *Context);
unsigned int PModeParamGetAddress2(char *Topic, char *Context);
int PModeParamGetBoolean(char *Topic, char *Context);
int PModeParamGetParameter(char *Topic, char *Context);
int PModeParamGetValue(char *Topic, char *Context);
char *PModeParamGetText(char *Topic, char *Context);
char *PModeParamGetVersion(void);



// --- PCD-File functions ------------------------------------------------------
// Available by PCDiagNT version 2.9.x.x
/*
int SetProjectFile(char *FileName, char *Project, char *Type, int COMPortNo);

int GetSingleParameter(char *NodeName, char *Name, struct tParameter *Parameter);
int GetMultiParameterItem(char *NodeName, char *Name, char *ItemName, struct tParameter *Parameter);

int GetList(char *NodeName, struct tListNode *ListNode);
int GetListItem(struct tListNode *ListNode, int Index, char *ColumnName, struct tParameter *Parameter);

int GetEnumListCount(char *NodeName, int *aCount);
int GetEnumList(char *NodeName, int aEnumIndex, struct tListNode *ListNode);
*/

#endif // _PModeD
