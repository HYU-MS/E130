//****************************************************************************
//* Author: Thomas Funk
//*
//* These are functions to control the IDE
//*
//*
//*
//* 08.07.2002 Initial code
//*
//****************************************************************************
#ifndef _EicIDE_Header_
#define _EicIDE_Header_



//****************************************************************************

void SetLogFileName(char* FileName);
void SetLogParameter(int Append, int TimeStamp);
void SetLogging(int Flag);




#endif _EicIDE_Header_