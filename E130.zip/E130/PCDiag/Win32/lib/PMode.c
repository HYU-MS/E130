#ifndef _Pmode
#define _Pmode

//*********************************************************************************************
#include <stdio.h>
#include "PModeD.h"

//*********************************************************************************************
int CheckError()
{
  int i;
  char *s;

  i = GetErrorCode();
  if (i != 0) {
    s = GetErrorText(i);
    printf("Protocol Error: %s", s);
  }
  return i;
}

//*********************************************************************************************
int CheckErrorCR()
{
  int i;
  char *s;

  i = GetErrorCode();
  if (i != 0) {
    s = GetErrorText(i);
    printf("Protocol Error: %s\n", s);
  }
  return i;
}

//*********************************************************************************************
void ClearCrash(void)
{
  ClearMemory("CClear");
}

//*********************************************************************************************
void ClearSideCrash(void)
{
  ClearMemory("SCClear");
}

//*********************************************************************************************
void ClearFaults(void)
{
  ClearMemory("IFClear");
}

//*********************************************************************************************
void PrintBuffer(unsigned char *aMem, int aSize, int aLineCount)
{
 int i;

 for (i = 0; i < aSize ; i++)
   {
     if( (i % aLineCount) == 0) printf("\n");
     printf("%.2X ", *(aMem+i));
   }
   printf("\n");
}




#endif // _Pmode