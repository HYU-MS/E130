//***************************************************************************
//* This headerfile is a wrapper for the Top16 IO-Board module in PCDiagNT Interpreter.
//*
//* Use for new projects the IOBoard.h file for direct access to the Top16 IO-Board
//*
//* Author: Thomas Funk                
//*
//*
//* 19.04.2012 Initial code
//****************************************************************************
#ifndef _IOKithara_Header_
#define _IOKithara_Header_

#include <IOBoard.h>

//****************************************************************************
//  Printer basis adresses

#define LPT1 "LPT1"
#define LPT2 "LPT2"



//****************************************************************************
//    Functions Prototypes


//****************************************************************************
// IOWritePort
unsigned int IOWritePort(char* ioPortName, int ioOffset, unsigned char value)
{
  return IOSetOutputs(0, value);  // when the open collector output is used to switch a relay direct then the logic is not inverted
}

//****************************************************************************
// IOReadPort
unsigned int IOReadPort(char* ioPortName, int ioOffset, unsigned char* value)
{
  return IOGetInputs(0, value);
}



#endif //_IOKithara_Header_