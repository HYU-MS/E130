//***************************************************************************
//* This headerfile is a wrapper for the LPT-Port in PCDiagNT Interpreter.
//* The LPT Port access with the WinRing0 driver
//*
//*
//* Author: Thomas Funk                
//*
//*
//* 19.04.2021 Initial code
//****************************************************************************
#ifndef _IOKithara_Header_
#define _IOKithara_Header_

#include <LPTPort.h>

//****************************************************************************
//  Printer basis adresses

#define LPT1 "LPT1"
#define LPT2 "LPT2"



//****************************************************************************
//    Functions Prototypes

//****************************************************************************
//  IOWritePort
unsigned int IOWritePort(char* ioPortName, int ioOffset, unsigned char value)
{
  return LPTPortWrite(ioPortName, ioOffset, value);   
}

//****************************************************************************
//  IOReadPort
unsigned int IOReadPort(char* ioPortName, int ioOffset, unsigned char* value)
{
  return LPTPortRead(ioPortName, ioOffset, value);
}


#endif //_IOKithara_Header_