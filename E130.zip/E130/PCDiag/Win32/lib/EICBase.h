//****************************************************************************
//* Author: Thomas Funk
//*
//* These are base functions
//*
//*
//*
//* 29.04.2002 THF Initial code
//* 27.04.2018 THF Version 1.0.2.1: add to MessageBox() new types MsgPass & MsgFail
//*
//****************************************************************************
#ifndef _EICBase_Header_
#define _EICBase_Header_

// Constants to set the type of MessageBox
#define MsgWarning       0
#define MsgError         1
#define MsgInformation   2
#define MsgConfirmation  3
#define MsgCustom        4
#define MsgPass          5
#define MsgFail          6

// Constants to set the buttons in MessageBox() 
#define ButtonOK         0x0001
#define ButtonCancel     0x0002
#define ButtonAbort      0x0004
#define ButtonRetry      0x0008
#define ButtonIgnore     0x0010
#define ButtonYes        0x0020
#define ButtonNo         0x0040

// Results which button is was pushed in  MessageBox()
#define IDOK            1
#define IDCANCEL        2
#define IDABORT         3
#define IDRETRY         4
#define IDIGNORE        5
#define IDYES           6
#define IDNO            7

// CRC16 constants
#define cMSBLSB         0
#define cLSBMSB         1

                           
//****************************************************************************
int MessageBox(char* MsgText, int BoxType, int Buttons);
int InputBox(char* Caption, char* Prompt, char* Value);
int InputBoxInt(char* Caption, char* Prompt, int *Value, int Typ);

//****************************************************************************
char *GetComputerName(void);
char *GetComputerUserName(void);

//****************************************************************************
int CRC16(unsigned char *Buffer, int Count, int LSBMSB);
int CalculateSeedFromKey(int AlgoType, unsigned char *Seed, int SeedSize, unsigned char *Key, int KeySize);
int SetSecuritySpecialParam(unsigned char *Parameter, int ParameterSize);

//****************************************************************************
char* IOGetErrorText(int Error);

#endif _EICBase_Header_