#ifndef _biADWin
#define _biADWin

unsigned short ADC(short nr);
short Auslast(void);
long  DigIn(void); 
long  DigOut(void);
long  Freemem(void);
long  Freemem_T9(short typ);
long  GetActivate(short nr);
short SetDigOut(short iw);
short SetDAC(short ndac, unsigned short iw);
short SetDACListe(short ndac, long il, short iw[]);
short SetPar(short npar, long iw);
short SetOpt(short npar, long iw);
short SetFPar(short npar, float fw);
short ADBStart(short nprz);
short ADBStop(short nprz);
short ZykStart(short nprz);
short ZykStop(short nprz);
long  GetPar(short nr);
long  GetOpt(short nr);
float GetFPar (short nr);
short ReadADListe (short nadc, long il, short iw[]);
short GetData (short ndata, long nstart, long il, short id[]);
short GetlData (short ndata, long start, long il, long id[]);
short GetfData (short ndata, long nstart, long il, float id[]);
short SetData (short ndata, long start, long il, short id[]);
short SetlData (short ndata, long start, long il, long id[]);
short SetfData (short ndata, long start, long il, float id[]);
long  GetFifoCount (short nfifo);
long  GetFifoEmpty (short nfifo);
short ClearFifo (short nfifo);
short GetFifo (short nfifo, long il, short ifi[]);
short GetlFifo (short nfifo, long il, long ifi[]);
short GetfFifo (short nfifo, long il, float ifi[]);
short SetFifo (short nfifo, long il, short ifi[]);
short SetlFifo (short nfifo, long il, long ifi[]);
short SetfFifo (short nfifo, long il, float ifi[]);
short Test(void);
long  Iserv(char *dateiname, long iboardsize);
long  Boot(char *dateiname, long iboardsize);
short ADBPrLoad(char *dateiname);
void  ErrMessage(short state);
short AD_Net_Connect(char *prot, char *addr, char *EPoint, char *PWord, short msg);
short AD_Net_Disconnect(void);


// --- Load the Dll before use any other function in your C-Interpreter program -------------------
int ADWinLoadDLL(void);
// return value
// 0 => loading AdWin32 Library failed
// 1 => ok
//}


#endif