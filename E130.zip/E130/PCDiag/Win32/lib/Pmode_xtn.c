#ifndef _Pmode_xtn
#define _Pmode_xtn


#include "PMode.c"
#include "biADWin.h"
#include "Pmode_xtn.h"

//Pmode Login with Error-Handling
void Pmode_login()
  {  int iretvalue;
     Login();
     iretvalue = CheckError();
     if (iretvalue == 1)
     {   printf("Pmode Login not successful\n");
         return 0;
     }
     printf("Pmode-Login successful\n");
  }

#endif