/***************************************************************************
/* MFSatCard.h
/***************************************************************************
/*
/* Include file for MFSatCard.dll 
/* Defines all methods provided by the MFSatCard.dll for the C-Interpreter
/*  
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 02.02.2009 THF MFSatCard.dll Version 0.9.0.0
/* 13.02.2009 THF MFSatCard.dll Version 0.9.0.1   int PortHandle --> void* PortHandle
/* 15.06.2009 THF MFSatCard.dll Version 0.9.1.0   Add event-concept for dataport-functions & new functions (programming PSI5 satellite)
/* 22.06.2009 THF MFSatCard.dll Version 0.9.2.0   New functions Adjust functiond & EvalManchesterData & ReadInternalModeData
/* 12.11.2009 THF MFSatCard.dll Version 1.0.0.0   New functions SetControl() & SetSoftwareTrigger() & SetDelayCountErrorEmualtion() & SetRepetitionCountErrorEmualtion() & SetScanPatternTriggeringErrorEmualtion() & SetReplacementPatternErrorEmualtion()
/* 11.03.2010 THF MFSatCard.dll Version 1.0.0.1   New function ClearFPGA(), CHG ReadSPISequenceRegister() & WriteSPISequenceRegister() Index unsigend char --> unsigend short
/* 11.03.2010 THF MFSatCard.dll Version 1.0.0.1   New function ClearFPGA(), CHG ReadSPISequenceRegister() & WriteSPISequenceRegister() Index unsigend char --> unsigend short
/* 18.04.2011 THF MFSatCard.dll Version 1.0.0.2   New function SleepDelay(), ProgRead() & ProgWrite(). Removed ReadShadowMemory() & WriteShadowMemory()
/* 04.04.2012 THF MFSatCard.dll Version 1.0.0.6   New function DownloadSdfFile()
/* 27.08.2013 THF MFSatCard.dll Version 1.0.0.9   New function PurgeCOMPort()
/* 04.09.2013 THF MFSatCard.dll Version 1.0.1.0   New function ProgSelfTest()
// 04.12.2013 THF MFSatCard.dll Version 1.0.2.0   New function GlobalReset()
// 21.02.2014 THF MFSatCard.dll Version 1.0.3.0   New function for Bosch gSat6.1 (SMA685) OTPCalculateCRC() & OTPSetAddressRange() & OTPMarginTest()
// 12.03.2014 THF MFSatCard.dll Version 1.0.4.0   New function SetRetrys() & SetInvalidMemoryAddress(). Remove ReadShadowMemory() & WriteShadowMemory()
// 01.08.2014 THF MFSatCard.dll Version 1.0.5.0   New function SetControlBuffer()
// 08.09.2014 THF MFSatCard.dll Version 1.0.6.0   New sensor type: AD gSat6.2 ADXL151/ADXL152-Sensor Sparrow 2
// 06.03.2015 THF MFSatCard.dll Version 1.0.7.0   New sensor type: Infineon pSat6.2 & new functions ConnectDataPortEx() & SetProgrammingPulseParameter() & ProgramLock()
// 16.03.2015 THF MFSatCard.dll Version 1.0.8.0   New function GetToolParamFromSdfFile() & ReadRegister()
// 13.05.2015 THF MFSatCard.dll Version 1.0.9.0   Change parameter by GetToolParamFromSdfFile(), replace ConnectDataPortEx() by LinkConfigToDataPort()
// 15.05.2015 THF MFSatCard.dll Version 1.0.9.1   Optimize pSat6.2 programming retry if programming is fail
// 20.10.2015 THF MFSatCard.dll Version 1.1.0.0   New function BITE_Test() for Bosch gSat6.1(SMA685)
// 14.01.2016 THF MFSatCard.dll Version 1.1.1.0   New function SetCOMPortBufferSize()
// 25.01.2016 THF MFSatCard.dll Version 1.1.2.0   New function GetEmulationState() & TraceFileControl()
// 09.09.2016 THF MFSatCard.dll Version 1.1.3.0   New function SetCrashSignal(), add FPGA-Size defines
// 25.07.2017 THF MFSatCard.dll Version 1.1.4.0   New function Generic(), FlashFirmware(), FlashFirmwareFile(), ReadFPGARegister(), WriteFPGARegister(), ReadInterfaceEEPROM(), WriteInterfaceEEPROM()
// 28.08.2017 THF MFSatCard.dll Version 1.1.4.1   New parameter by function Generic()
// 31.08.2017 THF MFSatCard.dll Version 1.1.5.0   New function GetConfigurationSize()
// 10.01.2018 THF MFSatCard.dll Version 1.1.6.0   New SatType = 8 --> NXP gSat7.1 in ConnectProgramming()
// 20.03.2018 THF MFSatCard.dll Version 1.1.7.0   New functions ReceiveTelegramData(), ClearTelegramData(), EvalManchesterTelegramData() 
// 23.04.2018 THF MFSatCard.dll Version 1.1.7.1   Add ManipulateMode and ManipulateData parameter in function EvalManchesterTelegramData()
// 07.05.2018 THF MFSatCard.dll Version 1.1.8.0   New SatType = 9 --> ADXL716 gSat6.2 in ConnectProgramming() & new function SetBitcountBitrateOfManchesterData()
// 09.05.2018 THF MFSatCard.dll Version 1.1.8.1   New function SetProgrammingParameter()
// 17.08.2018 THF MFSatCard.dll Version 1.1.9.0   New function PreprocessTelegramData(), change parameter of function ReceiveTelegramData() and EvalManchesterTelegramData()
// 11.10.2018 THF MFSatCard.dll Version 1.2.0.0   New USB-Recording functions RecordingSetParameter(), RecordingControl(), RecordingSetState(), RecordingReceiveTelegramData(), RecordingClearTelegramData(), EvalTelegramData(), change parameter of function PreprocessTelegramData()
// 04.01.2019 THF MFSatCard.dll Version 1.2.1.0   New SatType = 10 --> Bosch SMP475 pSat7.2, SatType = 11 --> Bosch SMA752 gSat7.2, & new function SetGlobalParameter(), ProgramOTP(), CalculateCRC()
// 23.05.2019 THF MFSatCard.dll Version 1.2.2.0   New function GetSensorParameter() & ReadCapturedData()
// 05.06.2019 THF MFSatCard.dll Version 1.2.2.1   Rename ReadCapturedData() -> ReadCapturedUIData()
/*                
/**************************************************************************/

#ifndef _MFSatCard
#define _MFSatCard

//******************************************************************************
//  DEFINES
//******************************************************************************
// Available parameter set by SetGlobalParameter()
#define MONITOR_FIFO_COUNT       "Monitor_FiFo_Count"
#define USERDATA_FIFO_COUNT      "UserData_FiFo_Count"
#define TELEGRAMDATA_FIFO_COUNT  "TelegramData_FiFo_Count"

//******************************************************************************
// Index of the Tool-Parameter read form the sdf file via GetToolParamFromSdfFile()
#define TOOLPARAM_SIZE         8   // Size of the tool param array
#define TOOLPARAM_TYPE         0   // Tool parameter type

// Type = 1 --> programming pulse parameter
#define TOOLPARAM_1_DELAYTIME  1   // Programming pulse delay time between last sync pulse and programming pulse
#define TOOLPARAM_1_DURATION   2   // Programming pulse duration
#define TOOLPARAM_1_VOLTAGE    3   // Programming pulse voltage
#define TOOLPARAM_1_RESERVED4  4   // reserved
#define TOOLPARAM_1_RESERVED5  5   // reserved
#define TOOLPARAM_1_RESERVED6  6   // reserved
#define TOOLPARAM_1_RESERVED7  7   // reserved

//******************************************************************************
// Size
#define EMULATORSTATE_SIZE     4       // Size of the emulator state array
#define CHANNEL_COUNT          8       // Count of the channel array
#define SLOT_COUNT             8       // Count of the SLOT array
#define AD_CHANNEL_COUNT       2       // Count of the AD array
#define MFSAT_FPGA_SIZE        166980  // FPGA size of the MFSatCard
#define MFSAT_NEO_FPGA_SIZE    801462  // FPGA size of the MFSatCard-Neo

//******************************************************************************
//  FUNCTION PROTOTYPES
//******************************************************************************
int MFS_OpenMonitor(void* PortHandle, char* Title, int Top, int Left, int Height, int Width);
int MFS_CloseMonitor(void* PortHandle);

int MFS_TraceFileOpen(void* PortHandle, char* FileName, int Append);
int MFS_TraceFileClose(void* PortHandle);
int MFS_TraceFileControl(void* PortHandle, int LogOn, int LogDetailsOn);

int MFS_AddMessage(void* PortHandle, char* Message);

//******************************************************************************
int MFS_OpenCOMPort(int aCOMPort, int Baudrate, void** PortHandle);
int MFS_CloseCOMPort(void* PortHandle);
int MFS_SetCOMPortBufferSize(void* PortHandle, int TxBufferSize, int RxBufferSize);
int MFS_PurgeCOMPort(void* PortHandle, int TxAbort, int TxClear, int RxAbort, int RxClear);
char* MFS_GetErrorText(int ErrorCode);

//******************************************************************************
int MFS_GlobalReset(void);
int MFS_WaitForResponse(int EventID);
int MFS_Cancel(void* PortHandle, unsigned char CardID);
int MFS_SleepDelay(void* PortHandle, int* EventID, int DelayTime);

//******************************************************************************
int MFS_SetGlobalParameter(void* PortHandle, char* Name, int Value);

//******************************************************************************
int MFS_ConnectConfigPort(void* PortHandle, int Timeout);
int MFS_DisconnectConfigPort(void* PortHandle);

int MFS_FlashFirmware(void* PortHandle, unsigned char CardID, int* EventID, unsigned int Address, int Size, unsigned char Data[]);
int MFS_FlashFirmwareFile(void* PortHandle, unsigned char CardID, int* EventID, char* FileName);

int MFS_Generic(void* PortHandle, unsigned char CardID, int* EventID, unsigned char FunctionCode, int TxdSize, unsigned char TxdData[], int* RxdSize, unsigned char RxdData[], char* Name);

int MFS_GetVersions(void* PortHandle, unsigned char CardID, int* EventID, int* Size, unsigned char Data[]);
int MFS_GetStatus(void* PortHandle, unsigned char CardID, int* EventID, int* Size, unsigned char Data[]);
int MFS_GetCardType(void* PortHandle, unsigned char CardID, int* EventID, int* Size, unsigned char Data[]);
int MFS_SetBaudrate(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Type, unsigned short* Baudrate);
int MFS_SetOutputVoltage (void* PortHandle, unsigned char CardID, int* EventID, unsigned char Type, unsigned short* Voltage);
int MFS_SelectMode(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Mode, unsigned char SubMode);
int MFS_RestartMode(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Interface);

int MFS_ReadEEPROM(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Address, int* Size, unsigned char Data[]);
int MFS_WriteEEPROM(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Address, int Size, unsigned char Data[]);

int MFS_ReadRAM(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Address, int* Size, unsigned char Data[]);
int MFS_WriteRAM(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Address, int Size, unsigned char Data[]);

int MFS_DownloadConfiguration(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Page, int Size, unsigned char Data[]);
int MFS_ActivateConfiguration(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Page);
int MFS_UploadConfiguration(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Page, int* Size, unsigned char Data[]);
int MFS_GetConfigurationSize(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Page, unsigned short* DataSize);

int MFS_DownloadFPGA(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, int Size, unsigned char Data[]);
int MFS_ActivateFPGA(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index);
int MFS_UploadFPGA(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, int* Size, unsigned char Data[]);
int MFS_ClearFPGA(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index);

int MFS_DownloadCrashSignal(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, int Size, unsigned char Data[]);
int MFS_ClearCrashSignal(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index);
int MFS_SetCrashSignal(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, unsigned short Rate, unsigned short Scale, short StaticValue);

int MFS_ReadExtIDBlock(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, unsigned short Address, int* Size, unsigned char Data[]);
int MFS_WriteExtIDBlock(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, unsigned short Address, int Size, unsigned char Data[]);

int MFS_ReadInterfaceEEPROM(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, unsigned char Address, int* Size, unsigned char Data[]);
int MFS_WriteInterfaceEEPROM(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Index, unsigned char Address, int Size, unsigned char Data[]);

int MFS_ReadSPISequenceRegister(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Index, unsigned short* Value);
int MFS_WriteSPISequenceRegister(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Index, unsigned short Value);

int MFS_ReadFPGARegister(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Index, unsigned short* Value);
int MFS_WriteFPGARegister(void* PortHandle, unsigned char CardID, int* EventID, unsigned short Index, unsigned short Value);

int MFS_GetSpecialEEPROMAddress(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Par, unsigned short* Address, int* Count);
int MFS_GetEmulationState(void* PortHandle, unsigned char CardID, int* EventID, unsigned char EmulationStates[EMULATORSTATE_SIZE]);

int MFS_ReadEventCounter(void* PortHandle, unsigned char CardID, int* EventID, unsigned short* Count);
int MFS_ReadEvent(void* PortHandle, unsigned char CardID, int* EventID, unsigned char EventNo, unsigned char SatNo, unsigned short* Count);
int MFS_EraseEvent(void* PortHandle, unsigned char CardID, int* EventID, unsigned char EventNo);

int MFS_StartRecording(void* PortHandle, unsigned char CardID, int* EventID);
int MFS_StopRecording(void* PortHandle, unsigned char CardID, int* EventID);

int MFS_GetAdjustDate(void* PortHandle, unsigned char CardID, int* EventID, unsigned char* Day, unsigned char* Month, unsigned short* Year);
int MFS_SetAdjustDate(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Day, unsigned char Month, unsigned short Year);

int MFS_GetAdjustVoltage(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short* Voltage);
int MFS_SetAdjustVoltage(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Voltage);

int MFS_GetAdjustCurrent(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short* Current);
int MFS_SetAdjustCurrent(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Current);

int MFS_CollectAdjustValues(void* PortHandle, unsigned char CardID, int* EventID, unsigned short VoltageData[], unsigned short CurrentData[]);
int MFS_GetSensorParameter(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned char* Error, unsigned short* VoltageIdle, unsigned short* CurrentIdle, unsigned short* VoltageSync, unsigned short* CurrentValue, int* SlotCount, unsigned short StartTimeData[], unsigned char BitCountData[], unsigned char BitRateData[]);
int MFS_ReadCapturedUIData(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, int* Count, unsigned short VoltageData[], unsigned short CurrentData[]);

int MFS_SetSyncPattern(void* PortHandle, unsigned char CardID, int* EventID, int PatternType, int PatternSize, unsigned int HighPattern[], unsigned int LowPattern[], unsigned short Delay[]);
int MFS_SetBitcountBitrateOfManchesterData(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Mask, unsigned char Bitcount, unsigned char Bitrate);

int MFS_DownloadSdfFile(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Page, char* FileName);

int MFS_SetControl(void* PortHandle, unsigned char CardID, int* EventID, unsigned char ControlID, unsigned short Data);
int MFS_SetControlBuffer(void* PortHandle, unsigned char CardID, int* EventID, unsigned char ControlID, int Size, unsigned char Data[]);
int MFS_SetSoftwareTrigger(void* PortHandle, unsigned char CardID, int* EventID, unsigned short SatPattern);
int MFS_SetDelayCountErrorEmualtion(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Count);
int MFS_SetRepetitionCountErrorEmualtion(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Count);
int MFS_SetScanPatternTriggeringErrorEmualtion(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Pattern);
int MFS_SetReplacementPatternErrorEmualtion(void* PortHandle, unsigned char CardID, int* EventID, unsigned char SatNo, unsigned short Pattern);

int MFS_RecordingSetParameter(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Option, unsigned char Mask, unsigned short ADRates[AD_CHANNEL_COUNT]);
int MFS_RecordingControl(void* PortHandle, unsigned char CardID, int* EventID, unsigned char Control);
int MFS_RecordingSetState(void* PortHandle, unsigned char CardID, int* EventID, unsigned char State);
int MFS_RecordingReceiveTelegramData(void* PortHandle, unsigned char CardID, int* EventID, int* Size, unsigned int Marker[], unsigned int Data[], int Timeout);
int MFS_RecordingClearTelegramData(void* PortHandle, unsigned char CardID, int* EventID);

//******************************************************************************
int MFS_ConnectDataPort(void* PortHandle, int Timeout);
int MFS_DisconnectDataPort(void* PortHandle);
int MFS_SetDataPortMode(void* PortHandle, int Mode);
int MFS_LinkConfigToDataPort(void* DataPortHandle, void* ConfigPortHandle, unsigned char CardID);

int MFS_SetProgrammingPulseParameter(void* PortHandle, int* EventID, unsigned short StartTime, unsigned short Duration, unsigned short Voltage);

int MFS_SetRetry(void* PortHandle, int* EventID, int TimeOutRetry, int WrongBitCountRetry);
int MFS_SetInvalidMemoryAddress(void* PortHandle, int* EventID, unsigned short AddressList[], int Size);

int MFS_TransmitData(void* PortHandle, int* EventID, int Size, unsigned char Data[]);
int MFS_ReceiveData(void* PortHandle, int* EventID, int* Size, unsigned char Data[], int Timeout);
int MFS_ReceiveUserData(void* PortHandle, int* EventID, int* Size, unsigned short Data[], int Timeout);

int MFS_ClearUserDataItems(void* PortHandle, int* EventID);
int MFS_PopUserDataItem(void* PortHandle, int* EventID, unsigned short* Item);
int MFS_GetUserDataItems(void* PortHandle, int* EventID, int* Size, unsigned short Items[]);

int MFS_ReceiveTelegramData(void* PortHandle, int* EventID, int* Size, unsigned int Marker[], unsigned int Data[], int Timeout);
int MFS_ClearTelegramData(void* PortHandle, int* EventID);

int MFS_SetProgrammingParameter(void* PortHandle, int* EventID, int CheckType, int ManipulateMode, int DataBitCount);
int MFS_ConnectProgramming(void* PortHandle, int* EventID, int SatType);
int MFS_PROM2ShadowMemory(void* PortHandle, int* EventID);
int MFS_ProgRead(void* PortHandle, int* EventID, unsigned short Address, int* Size, unsigned char Data[]);
int MFS_ProgWrite(void* PortHandle, int* EventID, unsigned short Address, int Size, unsigned char Data[]);
int MFS_ProgramLock(void* PortHandle, int* EventID);
int MFS_ProgramOTP(void* PortHandle, int* EventID, unsigned short Address, int Size, unsigned int Flags);

int MFS_ReadRegister(void* PortHandle, int* EventID, unsigned short Address, unsigned short* Data);

int MFS_ProgramShadowMemory2PROM(void* PortHandle, int* EventID);
int MFS_VT_Test(void* PortHandle, int* EventID, int State);
int MFS_BITE_Test(void* PortHandle, int* EventID, int Size, unsigned short PosChannel1[], unsigned short PosChannel2[], unsigned short NegChannel1[], unsigned short NegChannel2[]);
int MFS_ProgSelfTest(void* PortHandle, int* EventID);

int MFS_OTPCalculateCRC(void* PortHandle, int* EventID);
int MFS_OTPSetAddressRange(void* PortHandle, int* EventID, unsigned short StartAddress, unsigned short EndAddress);
int MFS_OTPMarginTest(void* PortHandle, int* EventID, int ThresholdType);

int MFS_ReadInternalModeData(void* PortHandle, int* EventID, int* Size, double VoltageData[], double CurrentData[]);

//******************************************************************************
int MFS_CalculateCRC(int CRCType, int Size, unsigned char Data[], unsigned int* CRCResult);

int MFS_PreprocessTelegramData(int ProcessorTypes[CHANNEL_COUNT][SLOT_COUNT], unsigned int BitCount, int CheckType,
                           int InSize, unsigned int InMarker[], unsigned int InData[],
                           int* OutSize, unsigned int OutMarker[], unsigned int OutData[], int ErrorData[], int* ErrorCounter);

int MFS_EvalManchesterData(unsigned char FrameMask, unsigned char BitCount, int SignedFlag, int* Size, unsigned short UserData[], unsigned short RawData[], short SignedData[], unsigned char ErrorData[], int* ErrorCounter);

int MFS_EvalManchesterTelegramData(unsigned int FrameMask, unsigned int BitCount, int CheckType, int SignedFlag, int ManipulateMode,
                               int* Size, unsigned int Marker[], unsigned int Data[],
                               unsigned int RawData[], unsigned int ManipulatedData[], int SignedData[], int ErrorData[], int* ErrorCounter);

int MFS_EvalTelegramData(unsigned int FrameMask, unsigned int BitCount, int ManipulateMode,
                               int* Size, unsigned int Marker[], unsigned int Data[],
                               unsigned int RawData[], unsigned int ManipulatedData[], int ErrorData[], int* ErrorCounter);


int MFS_GetToolParamFromSdfFile(char* FileName, int Size, unsigned short Param[]);

/******************************************************************************/
/*           added functionality for interpreter                              */
/******************************************************************************/

//------ MFSatCard.dll initialisation -----------------------------------------------

int MFSatCardLoadDLL(void);

// return value
// 0 -> loading MFSatCard.dll failed
// 1 -> ok

#endif // _MFSatCard




