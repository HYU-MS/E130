//***************************************************************************
//  Headerfile for implemented CrashSimPro functions in PCDiagNT Interpreter.
//
//  CS_pro_dll.h interface for CS_pro_dll.dll
//
//  Date: 20.04.2007
//****************************************************************************
#ifndef _CS_PRO_Header_
#define _CS_PRO_Header_

#include <stdio.h> //for FILE data type

#define DLL_VER 27 //05.05.06



#define LMAXCRD1 100000          
#define CHANNUMBER 8
#define MAXCHANGE 1000           
#define LMAX 100000             
#define CARDNUMBER 4
#define RS232_BUFFER_MAX 10000  


//ADwin Pro HW / SW--------------------------------------------------------------------------------
#define DIO 0x0000
#define ADC 0x0040
#define DAC 0x0080
#define EXT 0x00C0
#define CPU 0x00A0



//-------------------------------------------------------------------------------------------------
typedef struct _ADWIN_MODUL
{
   int  m_slot;
   long m_type;
   long m_code;
   long m_adr;
   char m_text[256];

} ADWIN_MODUL, *LPADWIN_MODUL;

//-------------------------------------------------------------------------------------------------
typedef struct _ADWIN
{
   long        connection;
   int         device;
   long        dev_mac;
   long        dev_ip;
   long        memory_pm;
   long        memory_dm;
   long        memory_dx;
   short       busy;
   ADWIN_MODUL mod[16];

} ADWIN, *LPADWIN;

//-------------------------------------------------------------------------------------------------
typedef struct _ADWIN_SW
{
   long cs_dll;
   long adbasic_sw;
   long adbasic_hw;
   char adbasic_dll[256];

} ADWIN_SW, *LPADWIN_SW;


//-------------------------------------------------------------------------------------------------
typedef struct _PC_DATA
{
   char user_name[256];
   char PC_name[256];
   char op_system[1024];

} PC_DATA, *LPPC_DATA;


//-------------------------------------------------------------------------------------------------
typedef struct _DATACHAN_NEW
{
   int    card;              // Crard number 1-2...
   int    ch;                // Chanal 1-8...
   int    ch_aktiv;          // 1->aktiv, 0->deaktiviert
   char   file_name[1000];   // Datei mit den Beschleunigungswerten
   char   file_format[8];    // DB1, EXC, ...
   float  sensor_rate_f;     // mV/g
   float  scale_f;           // 0-100%
   float  offset_f;          // in [mV]z.B. 2,5[V]=2500[mV]
   int    data_number;       // for ADwin_PRO command z.B. DATA_xx
   float  selbs_test;        // in [mV] DIO2 01-16
   float  selbs_test_2;      // in [mV] DIO2 17-32
   float  dac_0V;            // in hex 0V -> 0x08000
   float  dac_5V;            // in hex 5V -> 0x0C000
   float  f_data[LMAX];      // gelesene Daten (aus der Datei) -> Beschleunigung in g
   char   file_header[1025]; // header aus der db-Datei
   long   lg_data[LMAX];     // umgerechnete Daten g auf Digits
   long   data_count;        // Data counter Anzahl der Daten aus der Datei
   float  f_delay;           // Verzoegerung bei der Ausgabe in [ms]
   float  f_offset_g;        // Offset in g
   long   lg_offset_g;       // Offset umgerechnet auf Digit
   float  f_sensor_vmin;     // minimale spannung g - sensor
   float  f_sensor_vmax;     // maximale spannung g - sensor

} DATACHAN_NEW, *LPDATACHAN_NEW;

//-------------------------------------------------------------------------------------------------
typedef struct _SETTINGS
{
   long  P_timer_ns;
   short device_no;
   float freq_process1;
   float freq_process2;
   float freq_process3;
   long  global_delay1;
   long  global_delay2;
   long  global_delay3;
   float stop_time;
   long  l_stop_time;
   int   init_mem;

   char  boot_name[1024];
   char  process_name1[1024];
   char  process_name2[1024];
   char  process_name3[1024];
   int   trigger;
   int   prot_dat_on;
   int   prot_dat_neu;
   int   zk_anzahl;
   char  zk_namen[32][16];
   float zk_r[32];                //ZK - angeschlossene R (2R)
   float zk_i_korrektur[32][2];   //[a]x+[b] - Korrektur fuer die 32 Strommessmodule
   int   adc_anzahl;
   int   crash_data_format_anzahl;
   char  crash_data_format[10][8];

   int   dac_number;    //DAC - all channel in adwin pro
   int   dac_card;      //DAC - Card
   int   dac_channel;   //DAC - channel in one card

   long  data_200[101];

   int   rel[16];

   long  dll_version;
   long  sw_adwin_version;
   long  hw_adwin_version;
   long  csini_version;

} SETTINGS, *LPSETTINGS;

//-------------------------------------------------------------------------------------------------
typedef struct _ZK_new
{
   int   zk_nr;           //1....??
   char  zk_name[16];     //ZK Name (wie z. B. ABD1, ABP1 oder BPL)
   long  zb[MAXCHANGE];   //Zuendungbegin
   long  ze[MAXCHANGE];   //und Zuendungende f�r einen Zuendkreis (mehrmals moeglich)
   float f_zb[MAXCHANGE]; //Zuendungbegin
   float f_ze[MAXCHANGE]; //und Zuendungende f�r einen Zuendkreis (mehrmals moeglich)
   float f_zd[MAXCHANGE]; //...und wie lange war der Puls
   char  text[200];       //Ausgabetext
   long  zk_neu;          //temp - Variable 1
   long  zk_alt;          //temp - Variable 2
   int   count;           //Zaehler fuer die Zuendungen

} ZK_new, *LPZK_new;

//-------------------------------------------------------------------------------------------------
typedef struct _CAN
{
   int  ch;
   long Baudrate;
   long ObjektID[15];
   long Buffer[15][16];
   long sende_per_in_ticks[15];  //0-> Objekt ist Empf.
                                 //!=0-> Objekt ist Sender mit der Periode

} CAN_DATA, *LPCAN_DATA;

//-------------------------------------------------------------------------------------------------
typedef struct _ADC_ZK
{
   int   zk_nr;              //zk - Nummer
   char  zk_name[16];        //zk - Name
   long  l_I_werte[LMAX];    //Werte aus dem ADC
   float f_I_werte[LMAX];    //Werte in Amper umgerechnet
   float f_I_max[MAXCHANGE]; //max Strom in jeder Z
   float f_I_min[MAXCHANGE]; //min Strom in der Z
   float f_I_av[MAXCHANGE];  //Mittelwert
   float f_Q[MAXCHANGE];     //Q = I*t                  [mAs] = [mC]
   float f_W[MAXCHANGE];     //W = U*I*t = I*I*R*t      [mWs] = [mJ]
   float f_zb[MAXCHANGE];    //Zuendung - Begin
   float f_ze[MAXCHANGE];    //Zuendung - Ende
   float f_z[MAXCHANGE];     //Zuendzeiten (Laenge)
   int   i_z_count;          //Zaehler fuer die Zuendungen
   int   i_I_count;          //Zaehler fuer die Messwerte
   char  text[200];          //Ausgabetext
   float f_R;                //Zuendwiderstand (R - Squib)
   float f_I_korrektur_a;    //Stromkorrektur f�r die Strommessung ax
   float f_I_korrektur_b;    //Stromkorrektur f�r die Strommessung b

} ADC_ZK, *LPADC_ZK;

//-------------------------------------------------------------------------------------------------
typedef struct _CRASHCONTROL
{
   int start; //0 NC, 1 first scale loop, 2  first offset loop, ???

   float min_scale;
   float max_scale;
   float step_scale;

   float min_offset;
   float max_offset;
   float step_offset;

   int cresh_repeat;
} CRASHCONTROL, *LPCRASHCONTROL;



//-------------------------------------------------------------------------------------------------
long Get_Ver_CS_Pro_dll   ( void );
long Get_Ver_ADwin_Pro_SW ( void );
long Get_Ver_ADwin_Pro_HW ( void );
//ADwin functions----------------------------------------------------------------------------------
int Get_PC_Data( PC_DATA *pc_d );
int Set_ADwin_Device_No( short DevNo ); //0x150, 0x110,...
int Get_ADwin_Modul( ADWIN_MODUL *mod );
int Get_ADwin_HW( ADWIN *adwin_hw );
int Get_ADwin_SW( ADWIN_SW *adw_sw );
long lCheck_Adwin_Error( char *te );
int ADwin_debud_mode( char *da, int fl );
int Set_Px_f( long Px, float f );
int Get_Px_f( long Px, float *f );
int Start_Px( short Px );
int Stop_Px( short Px );
int Load_Px( char *Pn );
int Clear_Px( short Px );
int Get_Status_Px( short Px, long *rest_time_tick );
//-------------------------------------------------------------------------------------------------
long ReadDataFromFile  ( DATACHAN_NEW *truc_ptr );
long ReadFDataFromFile ( DATACHAN_NEW *truc_ptr );
long WriteData2ADwin   ( DATACHAN_NEW *truc_ptr );
long ConvertData4ADwin ( DATACHAN_NEW *truc_ptr );
long SetADwinData      ( short ch, long wert, long co );
long WriteOffset2ADwin ( DATACHAN_NEW *truc_ptr );
long ActivateDACChannel( DATACHAN_NEW *truc_ptr, int act );

//-------------------------------------------------------------------------------------------------
int ConvertSettings4ADwin( LPSETTINGS settings_ptr );
int WriteSettings2ADwin  ( LPSETTINGS settings_ptr );
//-------------------------------------------------------------------------------------------------
int Process_Delay( int karte, LPDATACHAN_NEW ch_ptr, LPSETTINGS settings_ptr, int nb_of_delay_to_send, long *delay_array );
//-------------------------------------------------------------------------------------------------
int CheckData4ADwin( LPSETTINGS se, LPDATACHAN_NEW dac );
int InitADwin      ( LPSETTINGS ptr_on_settings, LPDATACHAN_NEW str_zeiger );
//-------------------------------------------------------------------------------------------------
//Read the time change and the diochange for the zundzeiten
short Read_zk_data  ( long *tf, long *dio );

int get_zk_result3  ( LPZK_new zk, long *tf, long *bmf, int bit2check );
int get_zk_result   ( LPZK_new zk, long *tf, long *bmf, int bit2check );
// return number of change
int calc_zk_result  ( LPZK_new zk );

short Process_Crash ( short background_process_nb, short crash_process_nb );
short Start_Crash   ( void );

//-------------------------------------------------------------------------------------------------
int Process_Start   ( short process_nb );
int Process_Stop    ( short process_nb );
long Boot_ADwin_PRO ( char *file_name, long memsize );

short Set_Data_Long ( short data_nb, long lg_data[], long start_index, long count );
short Get_Data_Long ( short data_nb, long lg_data[], long start_index, long count );
short Set_Par_Long  ( short par_nb, long par );
short Get_Par_Long  ( short par_nb, long *par );
short Set_FPar_Float( short par_nb, float par );
short Get_FPar_Float( short par_nb, float *par );

float get_time_ticks( long ticks, char *freq );
long  get_ticks_time( float ms_time, char *freq );
int   get_status( short data_nb, short param_nb, long *data );

//Function to write Cras results in a file---------------------------------------------------------
void Store_zk_structure_text( LPZK_new ptr_txt, int zk_nb_bit, char *freq );

void Formate_IDdata2string( char *string2format, int max_ID_nb_per_CAN, int CAN_nb, short adress_2begin );
int Write_in_prot_files( FILE *datei, LPSETTINGS ptr, LPZK_new ptr_txt, LPDATACHAN_NEW zeiger_ch, int zk_bit );
int Create_Proto_file( unsigned int prot_state, LPZK_new zeiger, LPSETTINGS zeiger_settings, LPDATACHAN_NEW zeiger_ch, int anzahl );

//Dealing with CAN communication-------------------------------------------------------------------
// int Set_CAN_obj_ID( int ch, int obj, float ID, long periode );
int InitCANCard( CAN_DATA *CAN_ptr );

int Set_CAN_ID( int ch, int obj, float ID, long periode );
int Set_CAN_Baudrate( int ch, long br );

int Get_CAN_Buffer( int chan_CAN, int object_nb, long *buffer2write, long *IDn, long *per );
int Set_CAN_Buffer( int chan_CAN, int object_nb, long *buffer2read, long IDn, long per );
int Set_CAN_Parameter( int chan_CAN, CAN_DATA *can_par );

int Get_CAN_P1Fifo( long *buffer2read, long *count );
int Get_CAN_P1Message( long *can_message, long nummer );
int Clear_CAN_P1Fifo( void );

int Get_CAN_Status( long *can1_status, long *can2_status );
int Get_CAN_Status_Text( char *can1_status_text, char *can2_status_text, int len );
//Rel. - Karte-------------------------------------------------------------------------------------
int set_rel( int karte, int relnr, int wert );
int get_rel( int karte, int relnr, int *wert );
int set_rel_all( int karte, long wert );
int get_rel_all( int karte, long *wert );
int set_rel_delayP1ms( int karte, long wert, float ms_zeit, LPSETTINGS lp_settings, int *count );
int clr_rel_delayP1( int karte );
//Rel. - Karte-ENDE--------------------------------------------------------------------------------

//Trigger - Funktionen-----------------------------------------------------------------------------
int set_trigger( long tr );
//Trigger - Funktionen-ENDE------------------------------------------------------------------------

//Read/Write in *.ini - Datei----------------------------------------------------------------------
int Read_Ini_DAC( char *datei, char *sec, DATACHAN_NEW *DAC_ptr, int count );
int Read_Ini_Set( char *datei, char *sec, SETTINGS *set_ptr );
int Read_Ini_CAN( char *datei, char *sec, CAN_DATA *CAN_ptr, int count );

int Write_Ini_DAC( char *datei, char *sec, DATACHAN_NEW *DAC_ptr, int count );
int Write_Ini_Set( char *datei, char *sec, SETTINGS *set_ptr );
int Write_Ini_CAN( char *datei, char *sec, CAN_DATA *CAN_ptr, int count );
//Read/Write in *.ini - Datei-ENDE-----------------------------------------------------------------
//mehrere Crash - Daten aus der Datei lesen--------------------------------------------------------
int ReadCrashIniDataFromFile    ( char *datei_name, DATACHAN_NEW *DAC_ptr );
int ReadCrashControlDataFromFile( char *datei_name, DATACHAN_NEW *DAC_ptr, CRASHCONTROL *cc );
//mehrere Crash - Daten aus der Datei lesen-ENDE---------------------------------------------------

//-------------------------------------------------------------------------------------------------
//Daten zwischen den Structuren copieren-----------------------------------------------------------
int make_data( DATACHAN_NEW *dch_s, SETTINGS *set_s, ZK_new *zk_s, CAN_DATA *can_s, ADC_ZK *adczk_s);
int check_data( DATACHAN_NEW *dch_s, SETTINGS *set_s, ZK_new *zk_s, CAN_DATA *can_s, ADC_ZK *adczk_s);
//-------------------------------------------------------------------------------------------------

//Zus�tzliche Funktionen mit komplexen Aufgaben----------------------------------------------------
int ReadIniDataFromFile( char *fi, DATACHAN_NEW *dch_s, SETTINGS *set_s, ZK_new *zk_s, CAN_DATA *can_s, ADC_ZK *adczk_s );

int PrepareCrash( DATACHAN_NEW *dch_s, int count );
//Zus�tzliche Funktionen mit komplexen Aufgaben-ENDE-----------------------------------------------


//Funktionen f�r die ADC - Karte-------------------------------------------------------------------
int get_ADC3214_ar_volt( ADC_ZK *zk_a, int ch );
int get_ADC3214_data_volt( ADC_ZK *zk_a, int ch );
int get_ADC3214_P2volt( float *wert, float *mi, float *ma );
int calc_zk_analog( ADC_ZK *zk_a, float trigger );
int clear_ADC3214_P2( void );
int save_ADC3214_data( char *prot_datei );
//Funktionen f�r die ADC - Karte-ENDE--------------------------------------------------------------

//RS232--------------------------------------------------------------------------------------------
int init_RS232( int nr, long ba, long pa, long bi, long st, long ha );
int status_RS232( int nr, long *bi, long *bo, long *er );
int write_RS232( int nr, long *bu, long *co, long ti );
int read_RS232( int nr, long *bu, long *co, long *ti );
//RS232-ENDE---------------------------------------------------------------------------------------

//Grafik - Funktionen------------------------------------------------------------------------------
int get_grafData( void );
//Grafik - Funktionen-ENDE-------------------------------------------------------------------------

//Test - Funktionen--------------------------------------------------------------------------------
int make_job( int co, char *ch1, ... );
int make_something( int art );
//Test - Funktionen-ENDE---------------------------------------------------------------------------




//*************************************************************************************************
// --- Load the Dll before use any other function in your C-Interpreter program -------------------
// only needed for PCDiag's Interpreter
int CSProLoadDLL(void);
// return value
// 0 => loading CS_PRO_DLL Library failed
// 1 => ok

#endif //#define _CS_PRO_Header_

