//***************************************************************************
//* Headerfile for implemented GPIB functions in PCDiagNT Interpreter.       
//*                                                                                           
//*																			
//* These functions are needed to control a National Instruments 	
//* Data Aquisition plug-in board DIO-24.											
//*																			
//* further information: see Diplomarbeit									
//* "automatisiertes Testsystem CrashSimPlus V1.0" 
//* von Stefan Tautz, AT SE RS T36, Diplomand  
//*		
//* --- History --------------------------------------------------------------																	
//* 01.02.2001 ICO Gerhard Schmid  , Achat Solutions
//* 01.03.2001 ECH Stefan Tautz    , AT SE RS T36
//* 24.07.2002 ECH Michael Krieger , SV C RS T36	
//*														
//****************************************************************************

#ifndef _GPIB_H   // protection against multiple inclusion
#define _GPIB_H

/*****************************************************************************/
/* modified GPIB Header from original National Instruments "decl-32.h"       */
/*****************************************************************************/

//------ GPIB status bit vector:  global variable ibsta and wait mask ---------               

#define ERR     (1<<15) // Error detected                  
#define TIMO    (1<<14) // Timeout                         
#define END     (1<<13) // EOI or EOS detected             
#define SRQI    (1<<12) // SRQ detected by CIC             
#define RQS     (1<<11) // Device needs service            
#define CMPL    (1<<8)  // I/O completed                   
#define LOK     (1<<7)  // Local lockout state             
#define REM     (1<<6)  // Remote state                    
#define CIC     (1<<5)  // Controller-in-Charge            
#define ATN     (1<<4)  // Attention asserted              
#define TACS    (1<<3)  // Talker active                   
#define LACS    (1<<2)  // Listener active                 
#define DTAS    (1<<1)  // Device trigger state            
#define DCAS    (1<<0)  // Device clear state              


//----- Error messages returned in global variable iberr ------------------------        

#define EDVR  0  // System error                           
#define ECIC  1  // Function requires GPIB board to be CIC 
#define ENOL  2  // Write function detected no Listeners   
#define EADR  3  // Interface board not addressed correctly
#define EARG  4  // Invalid argument to function call      
#define ESAC  5  // Function requires GPIB board to be SAC 
#define EABO  6  // I/O operation aborted                  
#define ENEB  7  // Non-existent interface board           
#define EDMA  8  // Error performing DMA                   
#define EOIP 10  // I/O operation started before previous  
                 // operation completed                    
#define ECAP 11  // No capability for intended operation   
#define EFSO 12  // File system operation error            
#define EBUS 14  // Command error during device call       
#define ESTB 15  // Serial poll status byte lost           
#define ESRQ 16  // SRQ remains asserted                   
#define ETAB 20  // The return buffer is full.             
#define ELCK 21  // Address or board is locked.  
      
    
//------ EOS mode bits ---------------------------------------------------------  
                                        
#define BIN  (1<<12) // Eight bit compare                  
#define XEOS (1<<11) // Send END with EOS byte             
#define REOS (1<<10) // Terminate read on EOS              


//------ Timeout values and meanings -------------------------------------------

#define TNONE    0   // Infinite timeout (disabled)        
#define T10us    1   // Timeout of 10 us (ideal)          
#define T30us    2   // Timeout of 30 us (ideal)          
#define T100us   3   // Timeout of 100 us (ideal)         
#define T300us   4   // Timeout of 300 us (ideal)         
#define T1ms     5   // Timeout of 1 ms (ideal)           
#define T3ms     6   // Timeout of 3 ms (ideal)           
#define T10ms    7   // Timeout of 10 ms (ideal)           
#define T30ms    8   // Timeout of 30 ms (ideal)          
#define T100ms   9   // Timeout of 100 ms (ideal)         
#define T300ms  10   // Timeout of 300 ms (ideal)          
#define T1s     11   // Timeout of 1 s (ideal)            
#define T3s     12   // Timeout of 3 s (ideal)            
#define T10s    13   // Timeout of 10 s (ideal)           
#define T30s    14   // Timeout of 30 s (ideal)            
#define T100s   15   // Timeout of 100 s (ideal)         
#define T300s   16   // Timeout of 300 s (ideal)          
#define T1000s  17   // Timeout of 1000 s (ideal)          


//------ GPIB status functions -------------------------------------------------

int ibsta (void);
int iberr (void);


//----- GPIB NI-488 Function Prototypes ----------------------------------------

int ibdev (int boardID, int pad, int sad, int tmo, int eot, int eos);
int ibwrt (int ud, char *buf, long cnt);
int ibclr (int ud);
int ibloc (int ud);
int ibrd  (int ud, char *buf, long cnt);
int ibonl (int ud, int v);
int ibrdf  (int ud, char *flname);  // will be mapped to ibrdfA  (int ud, char *flname) , MiKr, SV C RS T36, 24.07.2002
int ibwrtf (int ud, char *flname);  // will be mapped to ibwrtfA (int ud, char *flname) , MiKr, SV C RS T36, 24.07.2002



/******************************************************************************/
/*           added functionality for interpreter                              */
/******************************************************************************/

//------ GPIB DLL initialisation -----------------------------------------------

int GPIBLoadDLL (void);

// return value
// 0 -> loading GPIB DLL failed
// 1 -> ok


#endif //  end of #ifndef __GPIB__H protection against multiple inclusion





