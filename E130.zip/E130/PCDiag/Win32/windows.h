#ifndef _Windows_h
#define _Windows_h

//******************************************************************************
// Windows Header
//******************************************************************************



void *LoadLibrary(char* DllName);
int FreeLibrary(void* DllHandle);
void *GetProcAddress(void* DllHandle, char* FunctionName);

char* GetProgramFileName(void);

int Beep(unsigned int Freq, unsigned int Duration);



#endif // _Windows_h
