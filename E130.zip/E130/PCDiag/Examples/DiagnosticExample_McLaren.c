/***************************************************************************
/* DiagnosticExample_McLaren.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 14.08.2009 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;


  printf("Load INI-File\n");
  if (SetIniFile("McLaren", "P11", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("MCLARENUDS");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession Default\n");
  StartDiagnosticSession(0x01, 0);      //Start EOL Session with Security Access
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x03, 1);    // Start Extended Session with Security Access
  if (CheckError()) return 0;  
 /* 
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x02, 1);    // Start Programming Session with Security Access
  if (CheckError()) return 0;  
 */

  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
 

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatusMask\n");
  ReadDTCByStatusMask(0xF9);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}