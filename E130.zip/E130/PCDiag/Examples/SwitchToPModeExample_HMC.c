/***************************************************************************
/* SwitchToPModeExample_HMC.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;
  

  printf("Load INI-File\n");
  if (SetIniFile("HMC", "PB", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set HMC Protocoltype\n");
  SetProtocolTyp("HMCCAN");


  //-----------------------------------------------------------------------------------------
  // Login HMC Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;

  
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession Extended\n");
  StartDiagnosticSession(0x90, 1);      //Satrt Extended Session with Security Access
  if (CheckError()) return 0;
  

  //-----------------------------------------------------------------------------------------
  printf("ECUIdentification\n");
  ECUIdentification(0x80);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
   
  //-----------------------------------------------------------------------------------------
  printf("\nSwitchToPMode\n");
  SwitchToPMode();
  if (CheckError()) return 0;
  
  //-----------------------------------------------------------------------------------------
  printf("\nPMode --> ReadMemory32Bit \n");  
  ReadMemory32Bit(mem, 0x80000, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]); 
  

  //-----------------------------------------------------------------------------------------
  printf("Logout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}