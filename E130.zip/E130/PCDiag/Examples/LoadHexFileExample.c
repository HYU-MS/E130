/***************************************************************************
/* LoadHexFileExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 21.01.2014 THF
/* 28.01.2014 THF change the GetHexFileData() interface
/*
/**************************************************************************/

#include <PMode.c>
#include <stdlib.h>


//******************************************************************************
int main()
{  
  int i, ErrorCode, BlockCount, BlockCounter;                          
  unsigned int DownloadAddress, DownloadSize; 
  unsigned char *DownloadData;   
 
  
  printf("\nLoadHexFile\n");       
  LoadHexFile(".\\Data\\Flash Container\\SYMC Flash Container\\Example Dummy.s37", &BlockCount);  // relative root folder of PCDiagNT: e.g. \XXX\Bin\PCDiagNT.exe --> \XXX  
  ErrorCode = GetErrorCode();    
  if (ErrorCode == 0) 
  {         
    for (BlockCounter = 0; BlockCounter < BlockCount; BlockCounter++)
    {          
      GetHexFileData(BlockCounter, &DownloadAddress, &DownloadSize, NULL);             // Get the address and size for allokate the data buffer   
                                                                       
      DownloadData = (unsigned char*) malloc(sizeof(unsigned char) * DownloadSize);                    // Allocate the data buffer
      GetHexFileData(BlockCounter, &DownloadAddress, &DownloadSize, DownloadData);    // Get the data --> in DownloadSize = Buffersize      

      ErrorCode = GetErrorCode();
      if (ErrorCode == 0)
      {
        printf("Address %.8Xh\n", DownloadAddress);  
        printf("Size %.8Xh\n", DownloadSize);   
        printf("Data\n", DownloadSize);        
        for (i = 0; i < 100; i++) 
        {                      ;
          printf("%.2X ", DownloadData[i]);     // display only the first 100 bytes
        }
       //for (i = 0; i < DownloadSize; i++) { printf("%.2X ", DownloadData[i]); }  // needs a lot of time!
        printf("\n");     
      } 
      else
      {
        printf("\nError: %s\n", GetErrorText(ErrorCode));
      } 
      free(DownloadData); // free data buffer   
    } 
  } 
    else 
  {
    printf("\nError: %s\n", GetErrorText(ErrorCode));
  }  
  

  printf("\nFinished\n");
  return 0;
}