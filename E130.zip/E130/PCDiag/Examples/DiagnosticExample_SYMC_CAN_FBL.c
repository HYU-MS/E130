/***************************************************************************
/* DiagnosticExample_SYMC_CAN_FBL.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 20.01.2014 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>
#include <stdlib.h>

//******************************************************************************
int Test_ExtendedSession()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024];  
  
/*
  //-----------------------------------------------------------------------------------------
  StartDiagnosticSession(0x03, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;     
*/               
  //-----------------------------------------------------------------------------------------
  size = 2;
  SendBuffer[0] = 0x10;     
  SendBuffer[1] = 0x03;  
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);   
   
  return 0;
}

//******************************************************************************
int Test_ProgrammingSession()
{
  unsigned char Seed[2];
  unsigned char Key[4];
  int i, size, count, KeySize;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024];  
  
/*
  //-----------------------------------------------------------------------------------------
  StartDiagnosticSession(0x92, 1);    // Start Programming Session with Security Access
  if (CheckError()) return 0;     
*/             
/*            
  //----------------------------------------------------------------------------------------
  StartDiagnosticSession(0x92, 0);    // Start Programming Session without Security Access
  if (CheckError()) return 0;       
  //-----------------------------------------------------------------------------------------
  SecurityAccess(0x01);             // Programming Session: Security Access Key 0x01 
  if (CheckError()) return 0;  
*/  
  //-----------------------------------------------------------------------------------------
  size = 2;
  SendBuffer[0] = 0x10;     
  SendBuffer[1] = 0x92;  
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);   
  
  //-----------------------------------------------------------------------------------------
  size = 2;
  SendBuffer[0] = 0x27;  
  SendBuffer[1] = 0x01;
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);   
  
  Seed[0] = mem[2];
  Seed[1] = mem[3];
  KeySize = CalculateSeedFromKey(0x56, Seed, 2, Key, 2);
  if( CheckError() ) { return 0; }   
  
  size = 4;
  SendBuffer[0] = 0x27;  
  SendBuffer[1] = 0x02;   
  SendBuffer[2] = Key[0];
  SendBuffer[3] = Key[1];
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);   
 
  return 0;
}

//******************************************************************************
int Test_ControlDTCSetting()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 

  //----------------------------------------------------------------------------
  size = 3;
  SendBuffer[0] = 0xFF;  
  SendBuffer[1] = 0x00;  
  SendBuffer[2] = 0x02; 
  ControlDTCSettings(0x01, SendBuffer, size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
       
  //----------------------------------------------------------------------------
  size = 5;
  SendBuffer[0] = 0x28;  
  SendBuffer[1] = 0x01;
  SendBuffer[2] = 0xFF; 
  SendBuffer[3] = 0x00;
  SendBuffer[4] = 0x02;
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
    
  return 0;
}  

//******************************************************************************
int Test_CommunicationControl()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
/*
  //----------------------------------------------------------------------------
  CommunicationControl(0x01, 0x00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
*/       
  //----------------------------------------------------------------------------
  size = 2;
  SendBuffer[0] = 0x28;  
  SendBuffer[1] = 0x01;
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
    
  return 0;
}  

//******************************************************************************
int Test_EraseMemory()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
/*       
  //----------------------------------------------------------------------------
  size = 3;
  SendBuffer[0] = 0xFF;  
  SendBuffer[1] = 0x00;  
  SendBuffer[2] = 0x00;
  RoutineControl(0x01, SendBuffer, size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
*/    
  return 0;
}

//******************************************************************************
int Test_CheckProgDependencies()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
/*       
  //----------------------------------------------------------------------------
  size = 2;
  SendBuffer[0] = 0xFF;  
  SendBuffer[1] = 0x01;
  RoutineControl(0x01, SendBuffer, size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
*/    
  return 0;
}

//******************************************************************************
int Test_RequestDownload(unsigned int Address, unsigned int DataSize)
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
    
  //----------------------------------------------------------------------------
  size = 11;
  SendBuffer[0] = 0x34;  
  SendBuffer[1] = 0x00; 
  SendBuffer[2] = 0x44; 
  
  SendBuffer[3] = (Address >> 24) & 0xFF;  
  SendBuffer[4] = (Address >> 16) & 0xFF;  
  SendBuffer[5] = (Address >>  8) & 0xFF;  
  SendBuffer[6] =  Address        & 0xFF;  
  
  SendBuffer[7] = (DataSize >> 24) & 0xFF;  
  SendBuffer[8] = (DataSize >> 16) & 0xFF;  
  SendBuffer[9] = (DataSize >>  8) & 0xFF;  
  SendBuffer[10] =  DataSize        & 0xFF;  
  
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
    
  return 0;
}  

//******************************************************************************
int Test_Download(unsigned char *Data, int DataSize, int BlockCounter)
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
    
  //----------------------------------------------------------------------------
  size = 2 + DataSize;
  SendBuffer[0] = 0x36;  
  SendBuffer[1] = BlockCounter & 0xFF;   
  
  for (i = 0; i < DataSize; i++) SendBuffer[i+2] = Data[i];
   
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
    
  return 0;
} 

//******************************************************************************
int Test_ExitDownload()
{
  int i, size, count;  
  unsigned char SendBuffer[1024];   
  unsigned char mem[1024]; 
    
  //----------------------------------------------------------------------------
  size = 1;
  SendBuffer[0] = 0x37;  
  
  SendTelegram(SendBuffer, size, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
    
  return 0;
} 

//******************************************************************************
int Test_FBLDownload(unsigned int Address, int Size, unsigned char *Data)
{
  int i, DownloadCounter, DownloadBlockSize;  
  int WriteBlockSize, Rest;
 
  DownloadCounter = 0; 
  DownloadBlockSize = 200;
  
  Test_RequestDownload(Address, Size);    
               
  i = 0;
  while (i < Size)
  {
   Rest = Size - i;
   if (Rest > DownloadBlockSize)
     { 
         WriteBlockSize = DownloadBlockSize;
     }
     else
    {       
       WriteBlockSize =  Rest;
    }

     Test_Download(&Data[i], WriteBlockSize , DownloadCounter);    
    DownloadCounter = ++DownloadCounter & 0xFF;
    i += WriteBlockSize ;
  } 
  
  Test_ExitDownload();

  return 0;
}



//******************************************************************************
int main()
{
  unsigned char mem[1024];   
  unsigned char SendBuffer[1024];
  int i, count, size, ErrorCode, BlockCount, BlockCounter;                          
  unsigned int DownloadAddress, DownloadSize; 
  unsigned char *DownloadData;   
                
  
  
  printf("Load INI-File\n");
  if (SetIniFile("SYMC", "C210_CAN", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("SYMCCAN");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Extended Diagnostic Session
  if (CheckError()) return 0;
                                   
//  printf("\nExtendedSession\n");
//  Test_ExtendedSession();
    
//  printf("\nControlDTCSetting\n");
//  Test_ControlDTCSetting();  
//                          
//  printf("\nCommunicationControl\n");
//  Test_CommunicationControl(); 
//  
//  printf("\nProgrammingSession\n");
//  Test_ProgrammingSession();   
//                  
//  printf("\nEraseMemory\n");
//  Test_EraseMemory();
  
  printf("\nLoadHexFile\n"); 
  LoadHexFile(".\\Data\\Flash Container\\SYMC Flash Container\\Example Dummy.s37", &BlockCount);  // relative root folder of PCDiagNT: e.g. \XXX\Bin\PCDiagNT.exe --> \XXX  
  ErrorCode = GetErrorCode();    
  if (ErrorCode == 0) 
  {         
    for (BlockCounter = 0; BlockCounter < BlockCount; BlockCounter++)
    {        
      GetHexFileData(BlockCounter, &DownloadAddress, &DownloadSize, NULL);             // Get the address and size for allokate the data buffer   
                                                                       
      DownloadData = (unsigned char*) malloc(sizeof(unsigned char) * DownloadSize);                    // Allocate the data buffer
      GetHexFileData(BlockCounter, &DownloadAddress, &DownloadSize, DownloadData);    // Get the data --> in DownloadSize = Buffersize              
    
      ErrorCode = GetErrorCode();
      if (ErrorCode == 0)
      {
        printf("Address %.8Xh\n", DownloadAddress);  
        printf("Size %.8Xh\n", DownloadSize);   
        printf("Data\n", DownloadSize);        
        for (i = 0; i < 100; i++) { printf("%.2X ", DownloadData[i]); } // display only the first 100 bytes
       //for (i = 0; i < DownloadSize; i++) { printf("%.2X ", DownloadData[i]); }  // needs a lot of time!
        printf("\n");    
      
        printf("\nDownload\n");  
        //Test_FBLDownload(DownloadAddress, DownloadSize, DownloadData);    
        WriteMemory(DownloadData, DownloadAddress, DownloadSize);
      } 
      else
      {
        printf("\nError: %s\n", GetErrorText(ErrorCode));
      }  
      free(DownloadData); // free data buffer    
    } 
  } 
    else 
  {
    printf("\nError: %s\n", GetErrorText(ErrorCode));
  }  
  
 
//  printf("\nCheckProgDependencies\n");
//  Test_CheckProgDependencies();
 
  
  //-----------------------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;   

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }

  printf("\nFinished\n");
  return 0;
}