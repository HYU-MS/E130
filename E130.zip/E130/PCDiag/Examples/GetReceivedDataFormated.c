/***************************************************************************
/* GetReceivedDataFormated.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Single Fault Test & GetReceivedDataFormated()
//
//  Example of performing Demand Measure Values
//
//  using: StartSingleFaultTest2Byte(),GetReceivedData(), GetReceivedDataFormated()
//         SetIniFile(), Login(), Reset()
//
//  Reset ECU, logon using INI-File,
//  start DemandMeasureValues and Show results.
/*--------------------------------------------------------------------------
/* History:
/* 18.03.2014 THF
/*
/**************************************************************************/


#include <PMode.c>

#define BLOCKSIZE 2
#define ARRAYSIZE 1024

struct tSFTRec
{
    unsigned int TimeStamp;
    unsigned char Data[BLOCKSIZE];
};


int main()
{
  struct tSFTRec SFTStructArray[ARRAYSIZE];
  unsigned char mem[ARRAYSIZE]; 
  int i, k;
  int Count; 
  int TimeOut;
  unsigned int TimeStamp;
  unsigned char Data;


  printf("Load INI-File\n");
  if (SetIniFile("PMode","CAN", 1)) {
    printf("Parameter file not found!");
    return 0;
  }     
  
  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;

  TimeOut = 8000;
  printf("StartSingleFaultTest2Byte: TimeOut:%i ms\n", TimeOut);
  StartSingleFaultTest2Byte(TimeOut, "SFT.txt");

  SleepDelay(8000);  // <-- here you can start for example a crash

  StopSingleFaultTest2Byte();
  Count = GetReceivedData(mem, ARRAYSIZE);
  if (CheckError()) return 0;
  printf("SingleFaultTest values:\n");

  printf("Count %i:\n",Count);
  PrintBuffer(mem,Count, 1);
  if (CheckError()) return 0;
  printf("\n");

  Count = GetReceivedDataFormated(SFTStructArray, ARRAYSIZE, BLOCKSIZE);
  printf("Count: %i  BlockSize: %i\n\n", Count, BLOCKSIZE);
  
  for (i=0; i < Count; i++)
  {
    TimeStamp = SFTStructArray[i].TimeStamp;
    printf("TimeStamp: %u ms, ", TimeStamp);   
    
    for (k=0; k < BLOCKSIZE; k++)
    { 
      Data = SFTStructArray[i].Data[k];
      printf("Data[%i]: 0x%x ", k, Data);
    }
    printf("\n");
  }

  printf("\nLogout!\n");
  Logout();    
  if (CheckError()) return 0;  
  
  printf("End\n");
  return 0;
}
