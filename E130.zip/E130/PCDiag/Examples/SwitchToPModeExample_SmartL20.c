/***************************************************************************
/* SwitchToPModeExample_SmartL20.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

#define MaxLength  1024


//******************************************************************************************************************
int main()
{
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size;
  int Code, Command;

  int i, x;
  unsigned char *data;
  int count;
  char *S;



  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("ini\\SRE-SMART-L20", "Landrover", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Set Protocol
  SetProtocolTyp(cSMARTL20);
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);

  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }


  // Switch from the Honda Diagnostic into the PMode
  SwitchToPMode();
  if( CheckError() ) { printf("Result: %x \n", Code); }

  S = GetProtocolName();
  printf("ProtocolName: %s",S);

  // PMode Memory Read
  StartAdr = 0x0800;
  EndAdr   = 0x0820;
  Size = EndAdr - StartAdr +1;

  printf("\nMemoryRead: ");
  ReadMemory(mem, StartAdr, Size);
  if( !CheckError() ){ PrintBuffer(mem, Size,16); }


  // PMode Logout
  printf("Logout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");
  return 0;
}
