/***************************************************************************
/* LogFileExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// LogFile Example
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <eicIDE.h>

int main()
{
  printf("Start \n");
  SetLogParameter(1,0);
  SetLogFileName("c:\\TestFileNamex0.txt");
  SetLogging(1);
  printf("Test0a \n");
  SetLogFileName("c:\\TestFileNamex1.txt");
  printf("Test1 \n");
  SetLogFileName("c:\\TestFileNamex0.txt");
  printf("Test0b \n");



  printf("x0 --> into the default default file:  Output.txt \n");
  SetLogFileName("c:\\TestFileName1.txt");
  SetLogging(1);
  printf("x1 \n");
  SetLogging(0);
  printf("x2 \n");
  SetLogging(1);
  printf("x3 \n");
  SetLogging(0);
  printf("x4 \n");

  SetLogging(1);
  printf("x5 \n");
  SetLogFileName("c:\\TestFileName2.txt");
  printf("x6 \n");
  SetLogFileName("c:\\TestFileName3.txt");
  printf("x7 \n");
  SetLogging(0);
  printf("x8 \n");

  printf("Ende \n");

  return 0;
}          