/***************************************************************************
/* VW40_ETS_Progamming.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 22.08.2018 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <eicIDE.h>
#include <String.h>
#include <time.h>
#include <EICBase.h>
#include <stdio.h>



#define OUTPUT_PATH                "D:\\_Sonstiges"
#define HEXOPT_CODEFLASH_FILENAME  "..\\EOL_Toolbox\\Data\\VW40_CodeFlash\\VW40_Appl_CF.hexopt-cfg"     
#define CODEFLASH_FILENAME_s37     "..\\EOL_Toolbox\\Data\\VW40_CodeFlash\\VW40CodeFlash.s37"



//******************************************************************************
int VW40ReadIdent(char* TN1, char* TN2, char* SN, char* SWIndex, char* HWIndex)
{
  int result, count, i;   
  unsigned char buffer[4000]; 
  
  //TN# (F187 & F191), SW-Index (F189), Seriennummer (F18C), HW-Index(F1A3))
  //-----------------------------------------------------------------------------------------
  printf("\nRead TN F187\n");
  ReadDataByIdentifier(0xF187);   // TN1  
  result = GetErrorCode();
  if (result == 0)
  {                  
    count = GetReceivedTelegram(buffer, sizeof(buffer));
    //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]);                                                               
    sprintf(TN1, "%s",&buffer[2]);  // extract TN part 1    
  }  
     
  if (result == 0)
  {  
    printf("\nRead TN F191\n");
    ReadDataByIdentifier(0xF191);   // TN2  
    result = GetErrorCode();
    if (result == 0)
    {            
      count = GetReceivedTelegram(buffer, sizeof(buffer)); 
      //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]); 
      sprintf(TN2, "%s", &buffer[2]);  // extract TN part 2 
    }
  }     
         
  if (result == 0)
  {                
    printf("\nRead SN F18C\n");
    ReadDataByIdentifier(0xF18C);   // SN 
    result = GetErrorCode();
    if (result == 0)
    {                    
      count = GetReceivedTelegram(buffer, sizeof(buffer)); 
      //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]);                                                               
      sprintf(SN, "%s", &buffer[2]);  // extract SN     
    }             
  }    
  
  if (result == 0)
  {  
    printf("\nRead SW-Index F189\n");
    ReadDataByIdentifier(0xF191);   // SW-Index
    result = GetErrorCode();
    if (result == 0)
    {             
      count = GetReceivedTelegram(buffer, sizeof(buffer)); 
      //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]); 
      sprintf(SWIndex, "%s", &buffer[2]);  // extract SW-Index
    }
  }
     
  if (result == 0)
  {     
    printf("\nRead HW-Index F1A3\n");
    ReadDataByIdentifier(0xF1A3);   // SN
    result = GetErrorCode();
    if (result == 0)
    {                  
      count = GetReceivedTelegram(buffer, sizeof(buffer)); 
      //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]);                                                               
      sprintf(HWIndex, "%s", &buffer[2]);  // extract HW-Index    
    }  
  }        
//  printf("ACU-Info: %s_%s_%s_%s", TN1, TN2, SWIndex, HWIndex);    
  return result;   
}   

//******************************************************************************
int VW40ReadDTC(char* DTC)
{
  int result, count, i , k;  
  char S[100];  
  unsigned char buffer[4000]; 
  
  printf("\nReadDTC\n");
  ReadDTCByStatusMask(0x09);
  result = GetErrorCode();  
  if (result == 0)
  {          
    count = GetReceivedTelegram(buffer, sizeof(buffer)); 
    //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]);   
              
    k = 0;
    for (i = 2; i < count; i++) 
    {                                     
      if ((k % 4) == 3)  
      {
        sprintf(S, "-%2.2X\n", buffer[i]); 
      }
      else
      {
        sprintf(S, "%2.2X", buffer[i]);  
      } 
      strcat(DTC, S);  
      k++; 
    }  
    //printf("DTC: %s", DTC);   
  }
return result; 
}

//******************************************************************************
int VW40ReadIDData(FILE *f, unsigned int Requests[], int RequestCount)
{
  int result, errorCode, count, loop, i;  
  char S[100]; 
  char Output[5000];  
  unsigned char buffer[4000]; 
        
  result = 0;
  for (loop = 0; loop < RequestCount; loop++)
  {      
    for (i=0; i < sizeof(Output); i++) { Output[i] = 0x00; }  
    ReadDataByIdentifier(Requests[loop] & 0xFFFF);   
    errorCode = GetErrorCode();   
    if (errorCode == 0)
    {                
      count = GetReceivedTelegram(buffer, sizeof(buffer));     
      //for (i = 0; i < count; i++) printf("%.2X ", buffer[i]);    
      sprintf(Output, "%4.4X: ", (Requests[loop] & 0xFFFF));
      for (i = 0; i < count; i++) 
      {                                     
        sprintf(S, "%2.2X,", buffer[i]);   
        strcat(Output, S);
      }  
      fprintf(f, "\n%s", Output);   
      
    } else
    {
      fprintf(f, "\n%4.4X: %s", (Requests[loop] & 0xFFFF), GetErrorText(errorCode));  
      result = errorCode;                                                       // last error
    }     
  }
  return result;  
}

//******************************************************************************
int VW40ArchiveMemory(char* FileName, char* Header)
{
  int result;
              
  printf("\nArchive Memory\n");
  ArchiveMemory(NULL, NULL, NULL, -1, -1, FileName, Header);   
  // result = GetErrorCode();   
  result = 0;                   // Ignore errors
  
  return result;
}  

//******************************************************************************
void GetDateTime(char* DateTime)
{
  //struct tm *TimeStructGm;
  struct tm *TimeStructLocal; 
  time_t Time;

  time(&Time);             
  //TimeStructGm = gmtime(&Time);        // 2 Stunden eventuell zur�ck !!
  TimeStructLocal = localtime(&Time);  
  
  //sprintf("UTC-date-time   %i.%i.%i   %i:%i:%i\n\n", TimeStructGm->tm_mday,  TimeStructGm->tm_mon + 1, TimeStructGm->tm_year + 1900, TimeStructGm->tm_hour, TimeStructGm->tm_min, TimeStructGm->tm_sec);    
  //sprintf(DateTime, "%i.%i.%i_%i:%i:%i\n\n", TimeStructLocal->tm_mday,  TimeStructLocal->tm_mon + 1, TimeStructLocal->tm_year + 1900, TimeStructLocal->tm_hour, TimeStructLocal->tm_min, TimeStructLocal->tm_sec);       
  sprintf(DateTime, "%i-%i-%i", TimeStructLocal->tm_mday,  TimeStructLocal->tm_mon + 1, TimeStructLocal->tm_year + 1900);
}

//******************************************************************************
int VW40FlashTETS(char* FlashLogFileName)
{
  int result;

  SetProtocolTyp(cEOL);
  
  Login(); // EOL-Login  
  result = GetErrorCode();   
  if (result == 0)
  {
    printf("ActivateETSToolbox()\n");
    ActivateETSToolbox(cETSToolboxTypeUnicom_Infineon_TriCore, FlashLogFileName);   
    result = GetErrorCode();
    if (result == 0)
    { 
      MessageBox("Hello World", MsgError,   ButtonYes + ButtonNo);

      printf("EraseETSPage()\n");   
      // Erase optional 
      // e.g. Page 17 --> 17=DataPage_17|17|$80070000|$8007FFFF
      //EraseETSPage(17, 1, HEXOPT_CODEFLASH_FILENAME, cETSTargetCodeFlash); 
      result = GetErrorCode();
      if (result == 0)
      { 
        printf("FlashETSFile()\n"); 
        // cETSWriteModeComplete --> Erase and Flash
        FlashETSFile(CODEFLASH_FILENAME_s37, HEXOPT_CODEFLASH_FILENAME, cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeComplete, 0);   
        
        // cETSWriteModeMerge  --> Readout and Flash
        //FlashETSFile(CODEFLASH_FILENAME_s37, HEXOPT_CODEFLASH_FILENAME, cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0); 
        result = GetErrorCode();  
      }   
     
      printf("DeactivateETSToolbox()\n");
      DeactivateETSToolbox();                             // ignore error
    }  
    Logout();                                             // ignore error
  }
  return result; 
}

//******************************************************************************
int VW40GetConfiguration(char *Step, char *DateTime, char* TN1, char* TN2, char* SN, char* SWIndex, char* HWIndex)
{
  unsigned int Requests[] = {0xF1A2, 0xF1AA, 0x05F0};    // Array of ReadDataByIdentifier ID's
  int i, ErrorCode;  
  char FileName[1024];    
  char DTC[5000];  
  char S[100];   
  FILE *f;  
  
  for (i=0; i < sizeof(TN1); i++) { TN1[i] = 0x00; }   
  for (i=0; i < sizeof(TN2); i++) { TN2[i] = 0x00; }   
  for (i=0; i < sizeof(SN); i++) { SN[i] = 0x00; }     
  for (i=0; i < sizeof(SWIndex); i++) { SWIndex[i] = 0x00; }
  for (i=0; i < sizeof(HWIndex); i++) { HWIndex[i] = 0x00; }  
  for (i=0; i < sizeof(DTC); i++) { DTC[i] = 0x00; }
  
  //-------------- Login -------------------------------------------------------
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session   
  ErrorCode = GetErrorCode();
      
  if (ErrorCode == 0)
  {                
    StartDiagnosticSession(0x4F, 1);    // Start DeveloperSession Session with Security Access
    ErrorCode = GetErrorCode();
  }
     
  // -------------- Read Ident -------------------------------------------------                                          
  if (ErrorCode == 0)
  {  
     ErrorCode = VW40ReadIdent(TN1, TN2, SN, SWIndex, HWIndex);      
  }    
                
  // -------------- Archive Memory ---------------------------------------------
  if (ErrorCode == 0)
  {                         
     // "Datum_VW40_SG-Seriennummer_Memory_vorher.par"  
     sprintf(FileName, "%s\\%s_VW40_%s_Memory_%s.par", OUTPUT_PATH, DateTime, SN, Step);   
     sprintf(S, "Info: %s_%s_%s_%s\n", TN1, TN2, SN, SWIndex, HWIndex);  
     ErrorCode = VW40ArchiveMemory(FileName, S);      
  }       
           
  // -------------- Read DTC --------------------------------------------------- 
  if (ErrorCode == 0)
  {  
     ErrorCode = VW40ReadDTC(DTC);  
  }      
              
  // -------------- DTC-File ---------------------------------------------------
  // "Datum_VW40_SG-Seriennummer_DTCInformation_vorher.txt"  
  sprintf(FileName, "%s\\%s_VW40_%s_DTCInformation_%s.txt", OUTPUT_PATH, DateTime, SN, Step);  
  f = fopen (FileName, "w");
  if (f != NULL)
  {       
    fprintf(f, "\nInfo: %s_%s_%s_%s", TN1, TN2, SN, SWIndex, HWIndex);  
    fprintf(f, "\n%s", DTC);     
    fclose(f);
  }
       
  
  // -------------- ReadDataByIdentifier-File ----------------------------------
  // "Datum_VW40_SG-Seriennummer_IDData_vorher.txt"   
  sprintf(FileName, "%s\\%s_VW40_%s_IDData_%s.txt", OUTPUT_PATH, DateTime, SN, Step);            
  f = fopen (FileName, "w");
  if (f != NULL)
  {            
    fprintf(f, "Info: %s_%s_%s_%s", TN1, TN2, SN, SWIndex, HWIndex);  
    if (ErrorCode == 0)
    {             
       ErrorCode = VW40ReadIDData(f, Requests, sizeof(Requests) / sizeof(unsigned int));        
    } 
    fclose(f);
  }   
    
  Logout();                                 // Stop Diagnostic Session, ignore error  
  printf("\nLogout\n");  
  
  return ErrorCode;           
}


//******************************************************************************
int main()
{  
  char DateTime[100];  
  char FileName[1024];
  char TN1[100];   
  char TN2[100];   
  char SN[100];   
  char SWIndex[100];   
  char HWIndex[100]; 
  FILE *f;               
  int ErrorCode = 0;
 
  
  GetDateTime(DateTime);
  printf("\nDateTime: %s", DateTime);    

  printf("Load Project file\n");
  if (SetIniFile("VW40", "655", 1))
  {
    printf("\nProject file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(cCANVectorDeviceOffset + 2, 0, 1);   // Set the correct CAN Device Channel 1,2,3,4,..

  printf("Set Protocoltype\n");
  SetProtocolTyp("VWUDS");
              
  
  ErrorCode = VW40GetConfiguration("vorher", DateTime, TN1, TN2, SN, SWIndex, HWIndex);  // Read data before
   
  // -------------- Flash via ETS ----------------------------------------------  
  sprintf(FileName, "%s\\%s_VW40_%s_FlashLog.txt", OUTPUT_PATH, DateTime, SN);  
  // if (ErrorCode == 0) ErrorCode = VW40FlashTETS(FileName);
                                
  // -------------- Fehlerausgabe ----------------------------------------------  
  if (ErrorCode == 0) 
  {
    // -------------- ReadDataByIdentifier-File before programming --------------------------------
    // "Datum_VW40_SG-Seriennummer_ETS-SuccessfullDone.txt"   
    sprintf(FileName, "%s\\%s_VW40_%s_ETS-SuccessfullDone.txt", OUTPUT_PATH, DateTime, SN);                 
    f = fopen (FileName, "w");
    if (f != NULL)
    {       
      fprintf(f, "PASS: %s_%s_%s_%s", TN1, TN2, SN, SWIndex, HWIndex);     
      fclose(f);
    }                
    
    MessageBox("Please switch Kl.15/30 OFF -->ON", MsgInformation, ButtonOK);
    
    ErrorCode = VW40GetConfiguration("nachher", DateTime, TN1, TN2, SN, SWIndex, HWIndex);  // Read data after
    if (ErrorCode == 0)
    {
      MessageBox("Flash procedure sucsessful.", MsgInformation, ButtonOK);
    }
    else
    {    
      MessageBox("Flash procedure sucsessful, but read data after fail.", MsgWarning, ButtonOK);
    }
  }
  else 
  {    
    // "Datum_VW40_SG-Seriennummer_ETS-NotSuccessfull.txt"   
    sprintf(FileName, "%s\\%s_VW40_%s_ETS-NotSuccessfull.txt", OUTPUT_PATH, DateTime, SN);   
    f = fopen (FileName, "w");
    if (f != NULL)
    {       
      fprintf(f, "FAIL: %s_%s_%s_%s", TN1, TN2, SN, SWIndex, HWIndex);  
      fprintf(f, "\n%s", GetErrorText(ErrorCode));   
      fclose(f);
    }   
    MessageBox("Error flash procedure", MsgError, ButtonOK);
  } 
  
  
  



  printf("\nFinished\n");

  return 0;
}