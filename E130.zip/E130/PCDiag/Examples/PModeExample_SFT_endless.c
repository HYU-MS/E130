/***************************************************************************
/* PModeExample_SFT_endless.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>

int main()
{
  unsigned char mem[1024];
  unsigned char *data;
  int i;
  int count;
  int TestTime;

  printf("Start PMode\n");


  //SetBreakChar("B");
  SetTimes (5, 30, 3500, 3500, 1000);
  SetReadWriteSize (40, 16);
  SetSerialPort (1, 19200, 8, 0, 1);
  //SetBaudRates ( 9600, 9600);


/*
  printf("Lade INI-File\n");

  if (SetIniFile("VW3", "609", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
*/

  Reset();

  Login();
  if (CheckError()) return 0;
while (1) {
// ------- SingleFaultTest -----------------------------------------
  TestTime = 40000;
  printf("\nStarte SingleFaultTest: %i ms\n", TestTime );
  SingleFaultTest(TestTime);
  if (CheckError())
   {
       printf("\nFehler : SingleFaultTest \n");
       return 0;
   }
  printf("\nSingleFaultTest beendet leses daten\n");

  count = GetReceivedData(mem, 24);
  if (CheckError()) return 0;
  printf("\nFertig : Lese SingleFaultTest Daten\n");
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  if (CheckError())
   {
       printf("\nFehler : GetReceivedData\n");
       return 0;
   }

}
  printf("\n\n Logout!\n");
 // Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
