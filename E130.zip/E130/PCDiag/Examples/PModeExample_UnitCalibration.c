/***************************************************************************
/* PModeExample_UnitCalibration.c
/***************************************************************************
/*
/*  PCDiagNT C-Interpreter example program
/*  THF Evolution GmbH
/*
/*  PMode-Sample: UnitCalibration
/*
/*
/*  using: UnitCalibration(), UnitCalibration24Bit(), UnitCalibration32Bit()
/*         WriteUnitCalibrationAutosar(), LoadMappingIDFile() 
/*         SetIniFile(), Login(),
/*
/*  Reset ECU, logon using INI-File,
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/* 08.05.2009 THF PAL file added
/* 11.11.2015 THF Add WriteUnitCalibrationAutosar()
/* 21.12.2015 THF Add LoadNvmIDMappingFile() for load MAPPING_ID file
/**************************************************************************/

#include <PMode.c>

int main()
{                                              
  char FileNameMapping_ID[]         = "D:\\MAPPING_ID.txt";
  char FileNameMapping_ID_Address[] = "D:\\ExampleMAPPING_ID Address.PAR";    
  char FileNameMapping_ID_Autosar[] = "D:\\ExampleMAPPING_ID Autosar.PAR";   
  char FileNameMapping_ID_Mix[]     = "D:\\ExampleMAPPING_ID Mix.PAR";    
  
  char FileName16[]  = "D:\\Example16Bit.par";
  char FileName24[]  = "D:\\Example24Bit.PAR";
  char FileName32[]  = "D:\\Example32Bit.PAR";  
  char FileNamePAL[] = "D:\\Example.pal";
                        
  printf("Set CAN Parameters\n");            
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  if (CheckErrorCR()) return 0;
  
  printf("Load INI-File\n");                           
  if (SetIniFile("PMode", "CANAutosarSpeed30", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Start PMode\n");
  Login();
  if (CheckErrorCR()) return 0;


// ------- WriteUnitCalibration16Bit -----------------------------------------
//  printf("Start UnitCalibaration16Bit with File: %s \n", FileName16);
//  WriteUnitCalibration16Bit(FileName16);
//  CheckErrorCR();


// ------- WriteUnitCalibration24Bit -----------------------------------------
//  printf("Start UnitCalibaration24Bit with File: %s \n", FileName24);
//  WriteUnitCalibration24Bit(FileName24);
//  CheckErrorCR();


// ------- WriteUnitCalibration32Bit -----------------------------------------
//  printf("Start UnitCalibaration32Bit with File: %s \n", FileName32);
//  WriteUnitCalibration32Bit(FileName32);
//  CheckErrorCR();   
  
  
// ------- WriteUnitCalibration32Bit -----------------------------------------
  printf("LoadMappingIDFile MAPPING_ID Mapping file: %s \n", FileNameMapping_ID); 
  
  LoadMappingIDFile(FileNameMapping_ID, 1);  // 0 = no size check; 1 = size check
  if (!CheckErrorCR()) 
  { 
//    printf("Start UnitCalibaration32Bit MAPPING_ID with File: %s \n", FileNameMapping_ID_Address); 
//    WriteUnitCalibration32Bit(FileNameMapping_ID_Address);
//    CheckErrorCR();  
    
//    printf("Start UnitCalibarationAutosar MAPPING_ID with File: %s \n", FileNameMapping_ID_Autosar); 
//    WriteUnitCalibrationAutosar(FileNameMapping_ID_Autosar);
//    CheckErrorCR();    
    
    printf("Start UnitCalibaration MAPPING_ID with File: %s \n", FileNameMapping_ID_Mix); 
    WriteUnitCalibration(FileNameMapping_ID_Mix);
    CheckErrorCR(); 
  }



// ------- WriteUnitCalibration PAL Batch file-------------------------------- 
//  printf("LoadMappingIDFile MAPPING_ID Mapping file: %s \n", FileNameMapping_ID); 
//  
//  LoadMappingIDFile(FileNameMapping_ID, 1);  // 0 = no size check; 1 = size check
//  if (!CheckErrorCR()) 
//  {                      
//    printf("Start UnitCalibaration32Bit with File: %s \n", FileNamePAL);
//    WriteUnitCalibration32Bit(FileNamePAL);
//    CheckErrorCR();  
//    
//    printf("Start WriteUnitCalibrationAutosar with File: %s \n", FileNamePAL);
//    WriteUnitCalibrationAutosar(FileNamePAL);
//    CheckErrorCR();

//    printf("Start UnitCalibaration MAPPING_ID with File: %s \n", FileNamePAL); 
//    WriteUnitCalibration(FileNamePAL);
//    CheckErrorCR(); 
//
//  }
  
  printf("Logout\n");
  Logout();
  printf("Finsh\n");


  return 0;
}