/***************************************************************************
/* DiagnosticExample_Honda_UDS.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 28.08.2013 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;    
  unsigned char Data[] = {0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D};  
  unsigned char Parameter[10];


  printf("Load INI-File\n");
  if (SetIniFile("Honda", "HRS6", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("HONDAUDS");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession Default\n");
  StartDiagnosticSession(0x01, 0);      //Start Default Session without Security Access
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x03, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;        
  
//  //-----------------------------------------------------------------------------------------
//  printf("\nStartDiagnosticSession  Programming\n");
//  StartDiagnosticSession(0x02, 1);    // Start Programming Session with Security Access
//  if (CheckError()) return 0;   
   


  //-----------------------------------------------------------------------------------------
  printf("\nReadDTC (01)\n"); 
  Parameter[0] = 0xCA;
  ReadDTC(0x01, Parameter, 1);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTC (02)\n"); 
  Parameter[0] = 0xCA;
  ReadDTC(0x02, Parameter, 1);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
   
  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
      
    
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF198);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
       
 
  //-----------------------------------------------------------------------------------------
  printf("\nWriteDataByIdentifier\n");
  WriteDataByIdentifier(0xF198, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count i++) printf("%.2X ", mem[i]);            
             
 
  //-----------------------------------------------------------------------------------------
  printf("\nCommunicationControl\n");
  CommunicationControl(0x00, 0x01);
  count = GetReceivedTelegram(mem,1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);

 
  //-----------------------------------------------------------------------------------------
  printf("\nControlDTCSettings\n"); 
  ControlDTCSettings(0x02, Parameter, 0);
  count = GetReceivedTelegram(mem,1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);

      
  //-----------------------------------------------------------------------------------------
  printf("\nRoutineControl (02)\n"); 
  Parameter[0] = 0x02; 
  Parameter[1] = 0x03;
  Parameter[2] = 0x04;
  Parameter[3] = 0x05;
  RoutineControl(0x01, Parameter, 4);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
          

  //-----------------------------------------------------------------------------------------
  printf("\nSendTelegram\n"); 
  Parameter[0] = 0x19; 
  Parameter[1] = 0x02;
  Parameter[2] = 0xCA;
  SendTelegram(Parameter, 3, 0);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
 
  
  //-----------------------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0; 
  
  
  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}