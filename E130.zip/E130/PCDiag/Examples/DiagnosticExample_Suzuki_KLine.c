/***************************************************************************
/* DiagnosticExample_SUZUKI_KLine.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 23.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>


int main()
{
  unsigned char mem[1024];
  int i, count;
 

  printf("Load INI-File\n");
  if (SetIniFile("Suzuki", "YY1", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }


  printf("Set SUZUKI Protocoltype\n");
  SetProtocolTyp("SUZUKIKLINE");

  //-----------------------------------------------------------------------------------------
  AutoTesterPresent(1);  // 1=Testerpresent ON; 0=Testerpresent OFF
  
  //-----------------------------------------------------------------------------------------
  // Login SUZUKI-KLine Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("\nECUIdentification\n");
  ECUIdentification(0x8A);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0x08);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatus\n");
  ReadDTCByStatus(0x00, 0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nReadFreezeFrameData\n");
  ReadFreezeFrameData(0x80, 0x01, 0x83);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }

  printf("\nFinished\n");
  return 0;
}