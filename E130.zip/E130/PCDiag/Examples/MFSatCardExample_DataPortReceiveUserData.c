/***************************************************************************
/* MFSatCardExample_DataPortReceiveUserData.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program          
/* THF Evolution GmbH
/*
// MFSatCard-Sample: Start the satellite communication and receieve userdata
//
// 
//         
//
/*--------------------------------------------------------------------------
/* History:
/* 27.07.2014 THF
/*
/**************************************************************************/

#include <MFSatCard_dll.h>
//#include <PMode.c>

#include <stdio.h>

void* ConfigPortHandle = NULL;   
void* DataPortHandle = NULL;


//******************************************************************************
void OpenPorts(void)
{
  int DataPortBaudrate = 230400; 
  int ConfigPortNo = 1;
  int DataPortNo = 6;  
  int ErrorCode;  
  
  // Open and connect configuration port
  ErrorCode = MFS_OpenCOMPort(ConfigPortNo, 38400, &ConfigPortHandle);
  printf("OpenCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   
       
  ErrorCode = MFS_ConnectConfigPort(ConfigPortHandle, 1000); 
  printf("ConnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));     
    
  ErrorCode = MFS_OpenMonitor(ConfigPortHandle, "Configuration Port COM 1", 50, 500, 400, 600); 
  printf("OpenMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    
          
  // Open and connect data port
  ErrorCode = MFS_OpenCOMPort(DataPortNo, DataPortBaudrate, &DataPortHandle);
  printf("OpenCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   
       
  ErrorCode = MFS_ConnectDataPort(DataPortHandle, 1000); 
  printf("ConnectDataPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));     
    
  ErrorCode = MFS_OpenMonitor(DataPortHandle, "Data Port COM 6", 100, 500, 400, 600); 
  printf("OpenMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
}

//******************************************************************************
void ClosePorts(void)
{
  int ErrorCode;  
   
  // Disconnect and close data port   
  ErrorCode = MFS_CloseMonitor(DataPortHandle);
  printf("CloseMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    
  ErrorCode = MFS_DisconnectDataPort(DataPortHandle);  
  printf("DisconnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));                 
    
  ErrorCode = MFS_CloseCOMPort(DataPortHandle);
  printf("CloseCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));       


    
  // Disconnect and close configuration port   
  ErrorCode = MFS_CloseMonitor(ConfigPortHandle);
  printf("CloseMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    
  ErrorCode = MFS_DisconnectConfigPort(ConfigPortHandle);  
  printf("DisconnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));                 
    
  ErrorCode = MFS_CloseCOMPort(ConfigPortHandle);
  printf("CloseCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
}


//*********************************************************************************************
void PrintUserData(unsigned short *aMem, int aSize, int aLineCount)
{
 int i;

 for (i = 0; i < aSize ; i++)
   {
     if( (i % aLineCount) == 0) printf("\n");
     printf("%4.4X ", *(aMem+i));
   }
   printf("\n");
}

#define RECEIVE_BUFFER_SIZE   5000

//******************************************************************************
int main()
{
  unsigned char CardID = 0x00;  
  int ErrorCode;       
  char SDFFilename[] = ".\\Bin\\MFSatSettings\\SDF_PSI5_PEGASUS10.sdf";
  int i, Size;
  unsigned char SendData[1];    
  unsigned short UserData[RECEIVE_BUFFER_SIZE];
  

  if (MFSatCardLoadDLL() == 1) 
  {    
    OpenPorts();
                    
    // download the correct MFSatCardSetting
    ErrorCode = MFS_DownloadSdfFile(ConfigPortHandle, CardID, NULL, 0x80, SDFFilename);  // RAM
    printf("DownloadSdfFile %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
    
    ErrorCode = MFS_SetDataPortMode(DataPortHandle, 0);
    printf("SetDataPortMode %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));       
    
    
    ErrorCode = MFS_SelectMode(ConfigPortHandle, CardID, NULL, 0x02, 0x91);
    printf("SelectMode %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));
    
    SendData[0] = 0x70; // 'p' --> Switch power on                                  
     
    ErrorCode = MFS_TransmitData(DataPortHandle, NULL, 1, SendData); 
    printf("TransmitData %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));
                  
    Size = RECEIVE_BUFFER_SIZE;
    for (i = 0; i < Size; i++) UserData[i] = 0x0000;   
    ErrorCode = MFS_ReceiveUserData(DataPortHandle, NULL, &Size, UserData, 1000); 
    printf("ReceiveData %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   
    PrintUserData(UserData, Size, 10);
    
    
    
    SendData[0] = 0x63; // 'c' --> switch power off
    ErrorCode = MFS_TransmitData(DataPortHandle, NULL, 1, SendData); 
    printf("TransmitData %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));
    
    ClosePorts();       
    printf("Finished\n");
    return 0;
  }
  else
  {         
    printf("Can not load MFSatCard.dll\n"); 
    return 1;
  }
}
