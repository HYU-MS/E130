/***************************************************************************
/* PModeExample_WriteFile.c
/***************************************************************************
/*
/*  PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: WriteFileToMemory
//
//
//  using: WriteFileToMemory(), 
//         SetIniFile(), Login(), Logout()
//
//  Reset ECU, logon using INI-File,
/*--------------------------------------------------------------------------
/* History:
/* 15.01.2010 THF
/**************************************************************************/

#include <PMode.c>

int main()
{
  char FileNameHex[]  = "C:\\Example.hex";
  char FileNameS[]    = "C:\\Example.s";

  printf("Load INI-File\n");

  if (SetIniFile("VW10", "655", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
  
  printf("Set CAN Parameters\n");
  SetCANParameters(1, 0, 1);  //int Channel, int Bitrate, int UseBitrateStack 
  
  printf("SetProtocolTyp\n");
  SetProtocolTyp("PMODE");
  if (CheckError()) return 0; //

  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;


// ------- WriteFileToMemory Intel Hex -----------------------------------------
/*  printf("Start WriteFileToMemory with File: %s \n", FileNameHex);
  WriteFileToMemory(FileNameHex, 1, 32);
  if (CheckError()) { return 0; }    */
  
// ------- WriteFileToMemory SRecord -------------------------------------------
  printf("Start WriteFileToMemory with File: %s \n", FileNameS);
  WriteFileToMemory(FileNameS, 2, 32);
  if (CheckError()) { return 0; }  
  
  
  printf("Logout\n");
  Logout();
  printf("--End Stop\n");


  return 0;
}