/***************************************************************************
/* CrashSimExample_CrashOutputs.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the Crashsim Outputs (BNC-Plugs)
// Standard Box & Extended Boxes
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>
#include <CrashSimD.h>

//**************************************************************************
int main()
{
   int Ch;
   int ValInt;
   double ValDouble;
   char FileName[256];
   int OK;

   printf("Start CrashSim\n");
   
   
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }
   
   CrashSimInit();
   CrashSimBoot();

   // Set the Crashsim Output parameter
   printf("\nSet the Values\n");
   Ch = 1;
   ChannelSetDelay(Ch,100);
   ChannelSetScale(Ch,10);
   ChannelSetOffset(Ch,5);
   ChannelSetLink(Ch,2);
   ChannelSetFilename(Ch,"C:\\temp\\Test.dat");


   // Get the set values
   ChannelGetDelay(Ch,&ValInt);
   printf("GetDelay: %i\n",ValInt);

   ChannelGetScale(Ch,&ValDouble);
   printf("GetScale: %f\n",ValDouble);

   ChannelGetOffset(Ch,&ValDouble);
   printf("GetOffset: %f\n",ValDouble);

   ChannelGetLink(Ch,&ValInt);
   printf("GetLink: %i\n",ValInt);

   ChannelGetFilename(Ch,FileName);
   printf("GetFileName: %s\n",FileName);


   // inc the values
   printf("\nInc the Values\n\n");
   ChannelIncDelay(Ch,1);
   ChannelIncScale(Ch,1.5);
   ChannelIncOffset(Ch,2.5);


    // Get the new values
   ChannelGetDelay(Ch,&ValInt);
   printf("GetDelay: %i\n",ValInt);

   ChannelGetScale(Ch,&ValDouble);
   printf("GetScale: %f\n",ValDouble);

   ChannelGetOffset(Ch,&ValDouble);
   printf("GetOffset: %f\n",ValDouble);

   ChannelGetLink(Ch,&ValInt);
   printf("GetLink: %i\n",ValInt);

   ChannelGetFilename(Ch,FileName);
   printf("GetFileName: %s\n",FileName);



   printf("Ececute\n");
   EXECUTE();

   printf("End\n");

   return 0;
}
