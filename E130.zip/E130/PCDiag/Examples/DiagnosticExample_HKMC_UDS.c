/***************************************************************************
/* DiagnosticExample_HKMC_UDS.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 20.01.2014 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>


//******************************************************************************
int main()
{  
  unsigned char mem[1024];
  int i, count;    
  unsigned char Data[] = {0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D};  
  unsigned char Parameter[10];
                         
  
  printf("Load INI-File\n");
  if (SetIniFile("HMC", "UDS", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("HKMCUDS");



  //----------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Extended Diagnostic Session
  if (CheckError()) return 0;
                                   

  //----------------------------------------------------------------------------
  printf("\nExtendedSession\n");
  StartDiagnosticSession(0x03, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;   
                
  
//  //----------------------------------------------------------------------------
//  printf("\nProgrammingSession\n");
//  StartDiagnosticSession(0x02, 1);    // Start Programming Session with Security Access
//  if (CheckError()) return 0;     
             
            
//  //----------------------------------------------------------------------------
//  printf("\nProgrammingSession\n");
//  StartDiagnosticSession(0x02, 0);    // Start Programming Session without Security Access
//  if (CheckError()) return 0;       
//  //----------------------------------------------------------------------------
//  printf("\nSecurityAccess\n");
//  SecurityAccess(0x01);             // Programming Session: Security Access Key 0x01 
//  if (CheckError()) return 0;  
 

  //----------------------------------------------------------------------------
  printf("\nReadDTC (01)\n"); 
  Parameter[0] = 0x08;
  ReadDTC(0x01, Parameter, 1);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);

  //----------------------------------------------------------------------------
  printf("\nReadDTC (02)\n"); 
  Parameter[0] = 0x08;
  ReadDTC(0x02, Parameter, 1);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
   
  
  //----------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
      
    
  //----------------------------------------------------------------------------
  printf("\nReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF198);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
       
 
  //----------------------------------------------------------------------------
  printf("\nWriteDataByIdentifier\n");
  WriteDataByIdentifier(0xF198, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);     
     
          
  //----------------------------------------------------------------------------
  printf("\nControlDTCSetting\n");
  ControlDTCSettings(0x02, NULL, 0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
                          
 
  //----------------------------------------------------------------------------
  printf("\nCommunicationControl\n");
  CommunicationControl(0x03, 0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);    
  
  //----------------------------------------------------------------------------
  printf("\nRoutineControl\n");
  count = 2;
  Parameter[0] = 0x01;  
  Parameter[1] = 0x02;  
  RoutineControl(0x00, Parameter, count);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
          
  //----------------------------------------------------------------------------
  printf("\nSendTelegram\n");  
  count = 4;
  Parameter[0] = 0x14;  
  Parameter[1] = 0xFF;  
  Parameter[2] = 0xFF; 
  Parameter[3] = 0xFF;           
  SendTelegram(Parameter, count, 0); 
  
  
  //----------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;   

  //----------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }

  printf("\nFinished\n");
  return 0;
}