/***************************************************************************
/* CalculateKeyFromSeedExample.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>

//**************************************************************************
int main()
{
  unsigned char Parameter[4];
  unsigned char Seed[2];
  unsigned char Key[4];
  int KeySize;


  printf("CalculateSeedFromKey\n");

  Seed[0] = 0x8F;
  Seed[1] = 0x26;
  printf("Seed[0]: %x \n", Seed[0]);
  printf("Seed[1]: %x \n", Seed[1]);
                        
  // calculate the key from the seed   
  KeySize = CalculateSeedFromKey(0x19, Seed, 2, Key, 2); // The AlgoType 0x19 needs no parameter 
  
           
/* 
  // optional someone seed-->key calculation need an parameter for the calcualtion 
  // SetSecuritySpecialParam() must called before CalculateSeedFromKey()                
  Parameter[0] = 0x01;  
  Parameter[1] = 0x02;
  Parameter[2] = 0x03;
  Parameter[3] = 0x04;     
  SetSecuritySpecialParam(Parameter, 4);     
  // calculate the key from the seed
  KeySize = CalculateSeedFromKey(0x56, Seed, 2, Key, 2); // The AlgoType 0x56 needs the SetSecuritySpecialParam() before
*/  
 

  printf("KeySize: %i \n", KeySize);
  printf("Key[0]: %x \n", Key[0]);
  printf("Key[1]: %x \n", Key[1]);

  printf("End Stop\n");

  return 0;
}