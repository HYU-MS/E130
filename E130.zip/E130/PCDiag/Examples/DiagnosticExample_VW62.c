/***************************************************************************
/* DiagnosticExample_VW62.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

#define MaxLength  1024



int main()
{
  char *S;
  int count;
  int Channel, DeviceNr, ImportNr, GarageNr, State, aabb;
  int Block;
  int StateFlag;
  unsigned char mem[MaxLength];

  // Set Protocol
  SetProtocolTyp(cVWDTS);
  if( CheckError() ) { return 0; }
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);


  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("VW62", "605", 1)) {
    printf("Parameter file not found!");
    return 0;
  }



  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }

/*  Identification();
  count = GetReceivedTelegram(mem, 46);
  if (CheckError()) return 0;
  printf("Count: %i\n",count);
  PrintBuffer(mem,count,count);   */


  /*printf("\nSecurityAccess -> Diagnostic Mode\n");
  VWDTSSecurityAccess(cModeDiagnostic);
  CheckError();

  printf("\nSecurityAccess -> EOL Mode\n");
  VWDTSSecurityAccess(cModeEOL);
  CheckError();  */

/*  printf("\nSecurityAccess -> Developer Mode\n");
  VWDTSSecurityAccess(cModeDeveloper);
  CheckError();

  ReadMemory(mem, 0x0C6B, 100);
  if (CheckError()) return 0;
  PrintBuffer(mem,100,16);

  mem[0] = 0xF1;
  mem[1] = 0xF2;
  WriteMemory(mem, 0x0C6B, 2);
  if (CheckError()) return 0;

  ReadMemory(mem, 0x0C6B, 2);
  if (CheckError()) return 0;
  PrintBuffer(mem,2,16);

  mem[0] = 0xA1;
  mem[1] = 0xA2;
  WriteMemory(mem, 0x0C6B, 2);
  if (CheckError()) return 0;

  ReadMemory(mem, 0x0C6B, 2);
  if (CheckError()) return 0;
  PrintBuffer(mem,2,16);


              */
  Channel = 6;

  VWDTSReadChannel(Channel, &DeviceNr, &ImportNr, &GarageNr, &State, &aabb);
  printf("VWDTSReadChannel Channel: %i  DeviceNr: %i ImportNr: %i  GarageNr: %i State: 0x%x   aabb: 0x%x\n",Channel, DeviceNr, ImportNr, GarageNr, State, aabb);

  count = GetReceivedTelegram(mem, 46);
  if (CheckError()) return 0;
  printf("Count: %i\n",count);
  PrintBuffer(mem,count,count);

  DeviceNr = 54321;
  ImportNr = 987;
  GarageNr = 12345;
  StateFlag = 0;
  VWDTSWriteChannel(Channel, DeviceNr, ImportNr, GarageNr, StateFlag);

  VWDTSReadChannel(Channel, &DeviceNr, &ImportNr, &GarageNr, &State, &aabb);
  printf("VWDTSReadChannel Channel: %i  DeviceNr: %i ImportNr: %i  GarageNr: %i State: 0x%x   aabb: 0x%x\n",Channel, DeviceNr, ImportNr, GarageNr, State, aabb);

  DeviceNr = 12345;
  ImportNr = 678;
  GarageNr = 98765;
  StateFlag = 1;
  VWDTSWriteChannel(Channel, DeviceNr, ImportNr, GarageNr, StateFlag);

  VWDTSReadChannel(Channel, &DeviceNr, &ImportNr, &GarageNr, &State, &aabb);
  printf("VWDTSReadChannel Channel: %i  DeviceNr: %i ImportNr: %i  GarageNr: %i State: 0x%x   aabb: 0x%x\n",Channel, DeviceNr, ImportNr, GarageNr, State, aabb);


  Block = 1;
  printf("VWDTSNormedValues");
  VWDTSReadNormedValues(Block);

  count = GetReceivedTelegram(mem, 100);
  if (CheckError()) return 0;
  printf("Count: %i\n",count);
  PrintBuffer(mem,count,count);


  printf("Logout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}