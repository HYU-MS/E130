/***************************************************************************
/* CrashSimExample_Inputs.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the Inputs ZP (red plugs)
// Standard Box & Extended Boxes
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>
#include <CrashSimD.h>

int main()
{
   int Box, Group;
   int i;
   double Value;
   int OK;

   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }


   CrashSimSetLogging(1);

   printf("Start CrashSim\n");
   CrashSimInit();
   CrashSimBoot();


   Box = 0;
   Group = 1;
   Value = 3;
   printf("InputSetZPThresholds,\n");
   InputSetZPThresholds(Box, Group, Value);

   Box = 1;
   Group = 4;
   Value = 3;
   InputSetZPThresholds(Box, Group, Value);

   Box = 0;
   Group = 1;
   Value = 0;
   InputGetZPThresholds(Box, Group, &Value);
   printf("Box %i   Group %i   Value %f\n",Box,Group,Value);

   Box = 1;
   for(Group=1; Group<=4; Group++)
   {
    Value = 0;
    InputGetZPThresholds(Box, Group, &Value);
    printf("Box %i   Group %i   Value %f\n",Box,Group,Value);
   }

   printf("Ececute\n");
   EXECUTE();

   printf("Input Standard Box,\n");
   for(i=1; i<=7; i++)
   {
     Value = 0.0;
     InputGetTTF(0,i, &Value);
     printf("Channel %i    Value %f\n",i,Value);
   }
   printf("\n");

   printf("Input Extended Box 1,\n");
   for(i=1; i<=16; i++)
   {
     Value = 0.0;
     InputGetTTF(1,i, &Value);
     printf("Channel %i    Value %f\n",i,Value);
   }

   printf("End\n");

   return 0;
}
