/***************************************************************************
/* SwitchToPModeExample_SUZUKI_UDS.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 03.08.2012 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, BlockCount;
  unsigned char Data[] = {0x50,0x43,0x44};   




  printf("Load INI-File\n");
  if (SetIniFile("Suzuki", "YA_UDS", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("SUZUKIUDS");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;
 
  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatusMask\n");
  ReadDTCByStatusMask(0xF9);
  count = GetReceivedTelegram(mem, 24);
  CheckError();
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nSwitchToPMode\n");
  SwitchToPMode();
   
  printf("ReadMemoryAutosar()\n");  
  BlockCount = ReadMemoryAutosar(mem, 0x0009, sizeof(mem));
  if (!CheckError())
  {
    printf("Read data successful\n");  
    printf("Count: %i\n", BlockCount);
    PrintBuffer(mem, BlockCount, 16); 

    for (i = 0; i < 20; i++) mem[i] = i;
    printf("\nWriteMemoryAutosar()\n");  
    WriteMemoryAutosar(mem, 0x0009, BlockCount);
    if (!CheckError())
    {
      printf("Write data successful\n");  
    }
   }
  

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}