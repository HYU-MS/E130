/***************************************************************************
/* LoadLibraryExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  LoadLibrary Example
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <Windows.h>
#include <stdio.h>


// function prototypes
typedef int t_Test1(int i1);
typedef int t_Test2(int i1, int i2);




int main() {

  void* hDll;
  t_Test1* pTest1;
  t_Test2* pTest2;

  int i;


  printf("LoadLibrary\n");
  hDll = LoadLibrary("DemoD.dll");

  if(hDll) {
    pTest1 = GetProcAddress(hDll, "Test_int__int");
    if(pTest1)
    {
      i = pTest1(5);
      printf("Test1 %i \n",i);
    }
    pTest2 = GetProcAddress(hDll, "Test_int_int__int");
    if(pTest2)
    {
      i = pTest2(1,2);
      printf("Test2 %i \n",i);
    }
  }
  i = FreeLibrary(hDll);
  printf("FreeLibrary %i \n",i);
  return 0;
}