/***************************************************************************
/* PModeExample_BlockWiseDMV.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Blockwise Demand Measure Values
//
//  Example of performing Demand Measure Values
//
//  using: DemandMeasureValues(),GetReceivedData()
//         SetIniFile(), Login(), Reset()
//
//  Reset ECU, logon using INI-File,
//  start DemandMeasureValues and Show results.
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i;
  int BlockCode;
  int Code;
  int Count;
  int RecordCount;
  int RecordSize;
  int TimeOut;

  printf("Load INI-File\n");

  if (SetIniFile("PMode", "Test", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
 // printf("Reset ECU\n");
 // Reset();
  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;

// ------- DemandMeasureValues -----------------------------------------
  BlockCode = 1;              // Block Code
  Code = 244;                 // DMV function code
  RecordCount = 300;          // Record count
  RecordSize = 2;             // Record size
  TimeOut = 8000;             // Timeout
  printf("Start BlockDemandMeasureValues: Code:%i RecordSize:%i RecordCount:%i TimeOut:%i ms\n", Code, RecordSize, RecordCount, TimeOut );
  StartBlockWiseMeasureValues(BlockCode, Code, RecordCount, TimeOut, RecordSize, "BlockDMV.txt");

  printf("-->start\n");
  SleepDelay(8000);  // <-- here you can start for example a crash
  printf("-->stop\n");

  StopBlockWiseMeasureValues();

  Count = GetReceivedData(mem, 1024);  // Count = RecordSize * RecordCount
  if (CheckError()) return 0;
  printf("BlockDemandMeasureValues Values:\n");
  printf("-->ende\n");
  printf("Count %i:\n", Count);
  PrintBuffer(mem, Count, RecordSize);
  if (CheckError()) return 0;


  Count = 100;   // Count of data
  printf("BlockDemandMeasureValues: Code:%i Count:%i TimeOut:%i ms\n", Code, Count, TimeOut);
  BlockWiseMeasureValues(BlockCode, Code, Count, TimeOut);
  if (CheckError()) {
    printf("\nFehler : BlockDemandMeasureValues \n");
    return 0;
  }
  printf("BlockDemandMeasureValues finished\n");

  Count = GetReceivedData(mem, 1024);
  if (CheckError()) return 0;
  printf("DemandMeasureValues Values:\n");
  PrintBuffer(mem, Count, 1);

  printf("Count %i:\n", Count);
  for (i = 0; i < Count; i++) printf("%.2X ", mem[i]);
  if (CheckError()) return 0;

  printf("\nLogout!\n");
  Logout();
  if (CheckError()) return 0;

  printf("--End Stop\n");

  return 0;
}