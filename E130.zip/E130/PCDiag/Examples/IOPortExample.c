/***************************************************************************
/* IOPortExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 13.01.2012 THF
/*
/**************************************************************************/

#include <IOBoard.h>
#include <stdio.h>


int main()
{
  int error;
  char* text;
  unsigned char OutData;    
  unsigned char InData;

  printf("Start\n\n"); 
  
  OutData = 0x55;
  error = IOSetOutputs(0, OutData);
  printf("IOSetOutputs  OutData: 0x%2.2X \n",  OutData);  
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
  
  
  
  OutData = 0xAA;
  error = IOSetOutputs(0, OutData);
  printf("IOSetOutputs  OutData: 0x%2.2X \n",  OutData);
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);    
  
  
  InData = 0x00;
  error = IOGetInputs(0, &InData);
  printf("IOGetInputs   InData: 0x%2.2X \n", InData); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
  


  printf("\nEnd\n");

  return 0;
}


