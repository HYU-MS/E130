/***************************************************************************
/* CrashSimExample_LogFile.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the CrashSim LogFile
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <CrashSimD.h>


int main()
{
   double Value;
   int i;
   int OK;
   
   printf("Start\n");

   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }

   CrashSimSetLogFileName("Log1File.txt");
   PAUSE(1);
   CrashSimSetLogging(1);
   CrashSimSetLogTypes(1,1,1,1,1);
   CrashSimGetVersion();
   CrashSimResetDefaultValues();
   CrashSimBoot();
   CrashSimResetDefaultValues();

   i = Booted();
   printf("Booted %i\n",i);
   i = ZPBoxesFound();
   printf("ZP %i\n",i);
   i = RelayBoxesFound();
   printf("Relay %i\n",i);

   CrashSimInit();
   CrashSimBoot();

   i = Booted();
   printf("Booted %i\n",i);
   i = ZPBoxesFound();
   printf("ZP %i\n",i);
   i = RelayBoxesFound();
   printf("Relay %i\n",i);

   InputSetZPThresholds(1, 1, 12.5);
   Value = 0;
   InputGetZPThresholds(1, 1, &Value);

   PAUSE(2);
   CrashSimSetLogging(0);
   PAUSE(3);
   CrashSimSetLogFileName("Log2File.txt");
   PAUSE(4);
   CrashSimSetLogging(1);
   PAUSE(5);
   CrashSimSetLogFileName("Log3File.txt");
   PAUSE(6);
   CrashSimSetLogging(0);

   printf("End\n");
   return 0;
}
