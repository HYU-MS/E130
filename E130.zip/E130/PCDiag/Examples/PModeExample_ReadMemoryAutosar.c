/***************************************************************************
/* PModeExample_ReadMemoryAutosar.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH/* THF Evolution GmbH
/*
/*
/*--------------------------------------------------------------------------
/* History:
/* 14.10.2010 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

int main()
{
  unsigned char mem[1024];
  int i;
  unsigned int BlockSize, BlockCount, Size;

  if (SetIniFile("PMode", "CANAutoSAR", 1))
  {
    printf("Parameter file not found!");
    return 0;
  }     
  
  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  
  
  Login();
  if (CheckError()) return 0;    
  
  
  
  Size = ReadAutosarSize(0x0009, &BlockSize, &BlockCount);
  if (!CheckError())
  {
    printf("ReadAutosarSize successful\n");  
    printf("Size: %i\n", Size); 
    printf("BlockSize: %i\n", BlockSize);
    printf("BlockCount: %i\n", BlockCount);
  }
  

  printf("ReadMemoryAutosar()\n");  
  BlockCount = ReadMemoryAutosar(mem, 0x0009, sizeof(mem));
  if (!CheckError())
  {
    printf("Read data successful\n");  
    printf("Count: %i\n", BlockCount);
    PrintBuffer(mem, BlockCount, 16); 

    for (i = 0; i < 20; i++) mem[i] = i;
    printf("\nWriteMemoryAutosar()\n");  
    WriteMemoryAutosar(mem, 0x0009, BlockCount);
    if (!CheckError())
    {
      printf("Write data successful\n");  
    }
   }
  Logout();
  
  return 0;
}