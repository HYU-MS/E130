/***************************************************************************
/* PModeExample_ClearMemory.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  if (SetIniFile("VW5", "605", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
  Login();
  if (CheckError()) return 0;


  ClearFaultMemory();

  CheckError();


  ClearMemory("CClear");

  CheckError();

  ClearCrash();  // this function is defined in "Pmode.c" and have the same function as  ClearMemory("CClear");
  CheckError();



  ClearMemory("SCClear");
  CheckError();

  ClearSideCrash(); // this function is defined in "Pmode.c" and have the same function as ClearMemory("SCClear");
  CheckError();



  ClearMemory("IFClear");
  CheckError();

  ClearFaults(); // this function is defined in "Pmode.c" and have the same function as ClearMemory("IFClear");

  CheckError();

   Logout();

  return 0;
}
