/***************************************************************************
/* PModeExample_inifile_login.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Login through INI-File
//
//  Using: SetIniFile(), login(), GetReceivedTelegram()
//
//  logon with loading an INI-file
//  and show Identification of ECU after sucessfull login.
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i;
  int count;
  int bufferlength;

  printf("Load INI-File\n");

  if (SetIniFile("VW5", "605", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Start PMode login\n");

  Login();
  if (CheckError()) return 0;

  bufferlength = 24;
  count = GetReceivedTelegram(mem, bufferlength );
  if (CheckError()) {
      printf("Error : GetReceivedTelegram\n");
      return 0;
  }

  printf("Telegram length: %i \n", count);
  for (i = 0; i < bufferlength -1 ; i++) printf("%.2X ", mem[i]);

  printf("\nPMode logout\n");

  Logout();
  if (CheckError()) return 0;

  printf("\n--End Stop\n");

  return 0;
}
