/***************************************************************************
/* SwitchToPModeExample_Suzuki.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, size;
  unsigned char data[10];

  printf("Load INI-File\n");
  if (SetIniFile("Suzuki", "YW1", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Suzuki Protocoltype\n");
  SetProtocolTyp("SUZUKICAN");


  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               
  if (CheckError()) return 0;
 
  //-----------------------------------------------------------------------------------------
  printf("\nSecurityAccess enable PMode\n");
  SecurityAccess(0xC1);             
  if (CheckError()) return 0;
  
  //-----------------------------------------------------------------------------------------
  printf("\nSwitchToPMode\n");
  SwitchToPMode();
  if (CheckError()) return 0;
  
  //-----------------------------------------------------------------------------------------
  printf("\nPMode --> ReadMemory32Bit \n");  
  ReadMemory32Bit(mem, 0x80000, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]); 
  
  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}