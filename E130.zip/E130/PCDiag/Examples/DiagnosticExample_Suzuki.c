/***************************************************************************
/* DiagnosticExample_Suzuki.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, size;
  unsigned char data[10];

  printf("Load INI-File\n");
  if (SetIniFile("Suzuki", "YW1", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Suzuki Protocoltype\n");
  SetProtocolTyp("SUZUKICAN");


  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("\nSecurityAccess EDR data access\n");
  SecurityAccess(0x01);             
  if (CheckError()) return 0;
  
   //-----------------------------------------------------------------------------------------
  printf("\nSecurityAccess enable PMode\n");
  SecurityAccess(0xC1);             
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("\nECUIdentification\n");
  ECUIdentification(0x8A);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatus\n");
  ReadDTCByStatus(0x00, 0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
/*
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/
/*
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0xC0);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/
  //-----------------------------------------------------------------------------------------
  printf("\nWriteDataByLocalIdentifier\n");
  data[0] = 0x01;
  size    = 1;
  WriteDataByLocalIdentifier(0xC0, data, size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}