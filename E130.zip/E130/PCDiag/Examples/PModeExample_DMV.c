/***************************************************************************
/* PModeExample_DMV.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Demand Measure Values
//
//  Example of performing Demand Measure Values
//
//  using: DemandMeasureValues(),GetReceivedData()
//         SetIniFile(), Login(), Reset()
//
//  Reset ECU, logon using INI-File,
//  start DemandMeasureValues and Show results.
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i;
  int Code;
  int Count;
  int RecordCount;
  int RecordSize;
  int TimeOut;

  printf("Load INI-File\n");

  if (SetIniFile("PMode", "Test", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
 // printf("Reset ECU\n");
 // Reset();
  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;

// ------- DemandMeasureValues -----------------------------------------
  Code = 244;                 // DMV function code
  RecordCount = 300;          // Record count
  RecordSize = 2;             // Record size
  TimeOut = 8000;             // Timeout
  printf("Start DemandMeasureValues: Code:%i RecordSize:%i Count:%i TimeOut:%i ms\n", Code, RecordSize, Count, TimeOut );
  StartDemandMeasureValues(Code, RecordCount, TimeOut, RecordSize,"DMV.txt");

  printf("-->start\n");
  SleepDelay(8000);  // <-- here you can start for example a crash
  printf("-->stop\n");

  StopDemandMeasureValues();

  Count = GetReceivedData(mem, 1024);  // Count = RecordSize * RecordCount
  if (CheckError()) return 0;
  printf("DemandMeasureValues Values:\n");
  printf("-->ende\n");
  printf("Count %i:\n", Count);
  PrintBuffer(mem, Count, RecordSize);
  if (CheckError()) return 0;


  Count = 200;
  printf("DemandMeasureValues: Code:%i Count:%i TimeOut:%i ms\n", Code, Count, TimeOut);
  DemandMeasureValues(Code, Count, TimeOut);
  if (CheckError()) {
    printf("\nFehler : DemandMeasureValues \n");
    return 0;
  }
  printf("DemandMeasureValues finished\n");

  Count = GetReceivedData(mem, 1024);
  if (CheckError()) return 0;
  printf("DemandMeasureValues Values:\n");
  PrintBuffer(mem, Count, 1);

  printf("Count %i:\n", Count);
  for (i = 0; i < Count; i++) printf("%.2X ", mem[i]);
  if (CheckError()) return 0;

  printf("\nLogout!\n");
  Logout();
  if (CheckError()) return 0;

  printf("--End Stop\n");

  return 0;
}
