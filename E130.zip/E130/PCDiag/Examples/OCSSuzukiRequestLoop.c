/***************************************************************************
/* OCSSuzukiRequestLoop.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>
#include <string.h>          // memset()
#include <EICBase.h>       // Messagebox



#define cTXDBufferSize 10
#define cRXDBufferSize 256
#define cTrue          1
#define cFalse         0

int main()
{
  unsigned char TXD[cTXDBufferSize];
  unsigned char RXD[cRXDBufferSize];
  int TXDSize;
  int RXDSize;
  int AutoCS;  // 0 --> false; 1 --> true
  int i, X, OK, Error, Retry, WaitTime, Value;
  int InterByteTime, InterBlockTime, Timeout;



//if (SetIniFile("OCSSUZUKI", "Kernel", 1))          // Load the COM Port Parameters Kernel Interface
                                                    // please install the before use the "PCDiagNT IO-Port & Timer & Serial Driver 7.01"
  if (SetIniFile("OCSSUZUKI", "WinAPI", 1))          // Load the COM Port Parameters WinApi Interface
  {
    printf("Parameter file not found!");
    return 0;
  }
  SetProtocolTyp(cOCSSUZUKI);               // Set the OCS-Suzuki-Protocol
  Login();                                  // Set The Protocol active
  AutoCS = cFalse;                          // CS must set manual
  InterByteTime = 5;                        // ms
  InterBlockTime = 0;                       // ms
  Timeout = 500;                            // ms
  SetTimes(InterByteTime, InterBlockTime, 0, 0, Timeout);


  do
  {
    OK = MessageBox("Transmit A/B telegram", MsgConfirmation, ButtonOK | ButtonAbort);
    if(OK == IDOK)
    {
      memset(TXD, 0x00, cTXDBufferSize);
      TXDSize = 0;

      Value = 0;
      X = InputBoxInt("Input","Header:", &Value, 1);
      if (X == IDOK) TXD[TXDSize++] = Value & 0xFF;

      Value = 0;
      X = InputBoxInt("Input","Data1:", &Value, 1);
      if (X == IDOK) TXD[TXDSize++] = Value & 0xFF;

      Value = 0;
      X = InputBoxInt("Input","Data2:", &Value, 1);
      if (X == IDOK) TXD[TXDSize++] = Value & 0xFF;

      Value = 0;
      X = InputBoxInt("Input","CS:", &Value, 1);
      if (X == IDOK)  TXD[TXDSize++] = Value & 0xFF;

      Value = 500;
      X = InputBoxInt("Input","WaitTime:", &Value, 0);
      if (X == IDOK) WaitTime = Value; else WaitTime = 500;

      Value = 5;
      X = InputBoxInt("Input","Retry:", &Value, 1);
      if (X == IDOK) Retry = Value; else  Retry = 5;

      X = MessageBox("Start Transmit", MsgConfirmation, ButtonOK | ButtonAbort);
      if (X == IDOK)
      {
        Error = 0;
        for(i = 0; ((i < Retry) && (Error == 0)); i++)
        {
          SleepDelay(WaitTime);
          printf("OCSRequest\n");
          RXDSize = cRXDBufferSize;
          OCSRequest(TXD, 0, RXD, &RXDSize, 0);
          Error = GetErrorCode();
        }
        if( Error != 0)
        {
          printf("Error: %s\n", GetErrorText(Error));
        }
      }
    }
  }
  while(OK == ButtonOK);


  Logout();                     // Set The Protocol inactive
  printf("Finish");
  return 0;
}