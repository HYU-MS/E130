/***************************************************************************
/* SwitchToPModeExample_DC_STAR2X.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 05.07.2013 THF
/*
/**************************************************************************/

#include <PMode.c>

#define MaxLength  1024


//******************************************************************************************************************
int main()
{
  unsigned char mem[MaxLength];
  //int  Size;
  //int Code, Command, 
  int BlockCount;

  //int i, x;
  //unsigned char *data;
  //int count;
  char *S;

  printf("Load Project-File:\n");
  if (SetIniFile("DAIMLER", "STAR2", 1)) 
  {
    printf("Parameter file not found!");
    return 0;
  }  
  
  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("DAIMLERUDS");   
  S = GetProtocolName();
  printf("ProtocolName: %s\n", S);



  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }  
                          
   
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession Default 10 01 \n");
  StartDiagnosticSession(0x01, 0);      //Start Extended Session without Security Access
  if (CheckError()) return 0;      
  
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession Extended 10 03\n");
  StartDiagnosticSession(0x03, 1);      //Start Extended Session with Security Access
  if (CheckError()) return 0;
    
  
  // Switch from the DC-STAR2X Diagnostic into the PMode
  SwitchToPMode();

  S = GetProtocolName();
  printf("ProtocolName: %s",S);

  // PMode Memory Read
  printf("\nReadMemoryAutosar: ");
  BlockCount = ReadMemoryAutosar(mem, 0x0009, sizeof(mem));
  if( !CheckError() )
  { 
    printf("Count: %i\n", BlockCount);
    PrintBuffer(mem, BlockCount, 16);   
  }

  // PMode Logout
  printf("Logout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");
  return 0;
}