/***************************************************************************
/* DiagnosticExample_VW10_AUDI8_UDS.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, ID, Size;
  unsigned char DataBuffer[10];
  unsigned char Data[] = {0x50,0x43,0x44,0x49,0x41,0x47};


  printf("Load INI-File\n");
  if (SetIniFile("VW10", "655", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("VWUDS");
  //SetProtocolTyp("AUDIUDS");


  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;

/*
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession EOL\n");
  StartDiagnosticSession(0x40, 1);      //Start EOL Session with Security Access
  if (CheckError()) return 0;
*/
/*
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x03, 0);    // Start EOL Session without Security Access
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("\nSecurityAccess Extended\n");
  SecurityAccess(0x03);             // Extended Session Key
  if (CheckError()) return 0;
*/

/*  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/  
/*
  //-----------------------------------------------------------------------------------------
  printf("\nRoutineControl\n");
  ID            = 0x01;  
  DataBuffer[0] = 0x01;  
  DataBuffer[1] = 0x02;  
  DataBuffer[2] = 0x10;  
  DataBuffer[3] = 0x04;  
  DataBuffer[4] = 0x00;  
  DataBuffer[5] = 0x00;  
  Size          = 6;
  RoutineControl(ID, DataBuffer, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/
/* 
  //-----------------------------------------------------------------------------------------
  printf("\nInputOutputControlByIdentifier\n");
  ID            = 0x0520;  
  DataBuffer[0] = 0x03;  
  Size          = 1;
  InputOutputControlByIdentifier(ID, DataBuffer, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/ 
/* 
  //-----------------------------------------------------------------------------------------
  printf("\nControlDTCSetting\n");
  ControlDTCSetting(0x01, 0x020304);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/ 
/*  
  //-----------------------------------------------------------------------------------------
  printf("\nCommunicationControl\n");
  CommunicationControl(0x03, 0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/ 
 
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF198);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  
  //-----------------------------------------------------------------------------------------
  printf("\nWriteDataByIdentifier\n");
  WriteDataByIdentifier(0xF198, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);


  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatusMask\n");
  ReadDTCByStatusMask(0x09);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  
  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCExtendedDataRecordingByDTCNumber\n");
  ReadDTCExtendedDataRecordingByDTCNumber(0x90111B, 0x8F);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  

  //-----------------------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}