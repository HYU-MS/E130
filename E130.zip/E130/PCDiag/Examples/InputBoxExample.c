/***************************************************************************
/* InputBoxExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// LogFile Example
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <EICBase.h>

int main()
{

  int i, Value;
  char Input[100];


  printf("Start \n");



  Value = 1234;
  i = InputBoxInt("Titel", "Value:", &Value, 0);    // decimal display
  printf("InputBox decimal -->  %i \n",Value);




  strcpy(Input, "Default"); 
  i = InputBox("Titel","Value:", Input);
  printf("InputBox %i, --> %s \n",i, Input);



  printf("Ende \n");

  return 0;
}