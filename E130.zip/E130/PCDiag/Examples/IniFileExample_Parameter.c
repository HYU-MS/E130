/***************************************************************************
/* IniFileExample_Parameter.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/* 12.10.2012 THF Adapt to *.prj file up PCDiagNT versioin 2.7.0.0
/*
/**************************************************************************/

#include <stdio.h>
#include <PMode.c>
#include <biADWin.h>
#include <Deprecated.h>

int main()
{
  char *ParameterText;
  int ParameterInt;
  unsigned int ParameterUInt;


  printf("Load Project-File\n");
  if (SetIniFile("PMode", "CAN", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

// ------- Parameter -----------------------------------------

  printf("\nStart Parameter:");
  ParameterText = PModeParamGetVersion();
  if (CheckError()) return 0;
  printf("\nVersion %s", ParameterText);

  ParameterText = PModeParamGetText("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetText: %s", ParameterText);

  ParameterInt = PModeParamGetAddress("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetAddress: 0x%8.8x", ParameterInt);    
  
  ParameterInt = PModeParamGetAddress2("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetAddress: 0x%8.8x", ParameterInt);

  ParameterUInt = PModeParamGet32BitAddress("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGet32BitAddress: 0x%8.8x", ParameterUInt);

  ParameterUInt = PModeParamGet32BitAddress2("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGet32BitAddress2: 0x%8.8x", ParameterUInt);


  ParameterInt = PModeParamGetBoolean("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetBoolean: %i", ParameterInt);

  ParameterInt = PModeParamGetParameter("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetParameter: %i", ParameterInt);

  ParameterInt = PModeParamGetValue("Adressen","Test");
  if (CheckError()) return 0;
  printf("\nPModeParamGetValue: %i", ParameterInt);


  printf("\nEnde Parameter\n");

  return 0;
}