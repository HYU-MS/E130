/***************************************************************************
/* DiagnosticExample_GMDAT.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>


#define MaxLength  256


int main()
{
  char *S;
  unsigned char LID;
  int count;
  unsigned char mem[MaxLength];


  int i;


   i = GetErrorCode();
  // Set Protocol
  SetProtocolTyp(cV250);
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);


  printf("Load Project-File:\n");
  if (SetIniFile("GMDAT", "SRE-V250", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Login:\n");
  Login();
  if( CheckErrorCR() ) { return 0; }

  //---------------------------------------------
  LID = 0x04;
  printf("StartRoutineByLocalID:\n");
  GMDATStartRoutineByLocalID(LID);
  CheckErrorCR();

  printf("StopRoutineByLocalID:\n");
  GMDATStopRoutineByLocalID(LID);
  CheckErrorCR();

  //---------------------------------------------
  printf("ReadCrashRecording:\n");
  GMDATReadCrashRecording(0x81);
  if ( !CheckErrorCR())
  {
    count = GetReceivedTelegram(mem, MaxLength);
    PrintBuffer(mem, count, 16);
  }

  //---------------------------------------------
  printf("GMDATReadLocalID (Read Measurement Values):\n");
  GMDATReadLocalID(0xFB);
  if ( !CheckErrorCR())
  {
    count = GetReceivedTelegram(mem, MaxLength);
    PrintBuffer(mem, count, 16);
  }

  //---------------------------------------------
  printf("GMDATReadLocalID (Read Operation Time):\n");
  GMDATReadLocalID(0xFA);
  if ( !CheckErrorCR())
  {
    count = GetReceivedTelegram(mem, MaxLength);
    PrintBuffer(mem, count, 16);
  }

  //---------------------------------------------
  printf("GMDATReadDTC (Read Operation Time):\n");
  GMDATReadDTC();
  if ( !CheckErrorCR())
  {
    count = GetReceivedTelegram(mem, MaxLength);
    PrintBuffer(mem, count, 16);
  }

  //---------------------------------------------
  printf("GMDATClearFaultMemory (Read Operation Time):\n");
  GMDATClearFaultMemory();
  CheckErrorCR();


  //---------------------------------------------
  printf("Logout:\n");
  Logout();
  if (CheckErrorCR()) return 0;

  printf("End Stop\n");
  return 0;
}