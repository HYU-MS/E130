/***************************************************************************
/* PModeCANPassThruExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>

//***************************************************************************************
int PassThruCAN()
{
  unsigned char mem[1024];
  int i;
  int loop;

   if (SetIniFile("IPPS", "PassThru", 1))
  {
    printf("Parameter file not found!");
    return 0;
  }

  Reset();
  printf("Login\n");
  Login();
  if (CheckError()) return 0;

  for (loop = 0; loop < 10; loop++)
  {
   printf("Copy Data\n");
   CopyData(ECUtoPC, mem, 0x0800, 20);
   if (CheckError()) return 0;
   for (i = 0; i < 20; i++) printf("%.2X ", mem[i]);
   printf("\n");

   if (CheckError()) return 0;
   printf("Loop  %i\n",loop);
  }

  printf("Logout\n");
  Logout();
  return 0;
}

//***************************************************************************************
int SerialKLine()
{
  unsigned char mem[1024];
  int i;
  int loop;

  if (SetIniFile("PMode", "Test", 1))
  {
    printf("Parameter file not found!");
    return 0;
  }

  Reset();
  printf("Login\n");
  Login();
  if (CheckError()) return 0;

  for (loop = 0; loop < 10; loop++)
  {
   printf("Copy Data\n");
   CopyData(ECUtoPC, mem, 0x0800, 20);
   if (CheckError()) return 0;
   for (i = 0; i < 20; i++) printf("%.2X ", mem[i]);
   printf("\n");

   if (CheckError()) return 0;
   printf("Loop  %i\n",loop);
  }

  printf("Logout\n");
  Logout();
  return 0;
}
//***************************************************************************************
int main()
{
  printf("Start\n");

  PassThruCAN();

  MessageBox("Change the Hardware to KLine", MsgConfirmation, ButtonOK);
  SerialKLine();

  MessageBox("Change the Hardware to CAN", MsgConfirmation, ButtonOK);
  PassThruCAN();


  printf("End Stop\n");

  return 0;
}