/***************************************************************************
/* GetProgramFileName.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <windows.h>


int main()
{
  char * ProgramFileName;
  
  ProgramFileName = GetProgramFileName();
  printf("%s\n", ProgramFileName);

  return 0;
}


