/***************************************************************************
/* MFSatCardExample_GetCardInfo.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program              
/* THF Evolution GmbH
/*
//  MFSatCard-Sample: Get the MFSatCard information 
//
//
//         
//
/*--------------------------------------------------------------------------
/* History:
/* 27.07.2014 THF
/*
/**************************************************************************/

#include <MFSatCard_dll.h>
#include <PMode.c>

#include <stdio.h>


void* ConfigPortHandle = NULL;   

//******************************************************************************
void OpenPorts(void)
{ 
  int ConfigPortNo = 1; 
  int ErrorCode;  
  
  // Open and connect configuration port
  ErrorCode = MFS_OpenCOMPort(ConfigPortNo, 38400, &ConfigPortHandle);
  printf("OpenCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   
       
  ErrorCode = MFS_ConnectConfigPort(ConfigPortHandle, 1000); 
  printf("ConnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));     
    
  ErrorCode = MFS_OpenMonitor(ConfigPortHandle, "Configuration Port COM 1", 50, 500, 400, 600); 
  printf("OpenMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
}

//******************************************************************************
void ClosePorts(void)
{
  int ErrorCode;  
   
  // Disconnect and close configuration port   
  ErrorCode = MFS_CloseMonitor(ConfigPortHandle);
  printf("CloseMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    
  ErrorCode = MFS_DisconnectConfigPort(ConfigPortHandle);  
  printf("DisconnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));                 
    
  ErrorCode = MFS_CloseCOMPort(ConfigPortHandle);
  printf("CloseCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
}

//******************************************************************************
int main()
{
  unsigned char CardID = 0x00;
  int ErrorCode;      
  int Size;  
  unsigned char VersionData[100];
  unsigned char StatusData[100];
  unsigned char CardTypeData[100];      
  char FPGAType[3];  
  


  if (MFSatCardLoadDLL() == 1) 
  {    
    OpenPorts(); // Open and connect configuration port
                 
    // Read the MFSatCard Information   
    Size = sizeof(CardTypeData);
    ErrorCode = MFS_GetCardType(ConfigPortHandle, CardID, NULL, &Size, CardTypeData); 
    printf("MFS_GetCardType %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));    
    PrintBuffer(CardTypeData, Size, Size);  
    printf("CardType: %s\n", CardTypeData);
    
           
    Size = sizeof(VersionData);
    ErrorCode = MFS_GetVersions(ConfigPortHandle, CardID, NULL, &Size, VersionData); 
    printf("MFS_GetVersions %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));    
    PrintBuffer(VersionData, Size, Size);  
    FPGAType[0] = VersionData[6]; 
    FPGAType[1] = VersionData[7];  
    FPGAType[2] = 0x00;   
    printf("HWVersion: %d.%3.3d, SWVersion: %d.%3.3d, FPGAVersion: %d.%3.3d, FPGAType: %s\n", VersionData[0], VersionData[1], VersionData[2], VersionData[3], VersionData[4], VersionData[5], FPGAType); 
                                              
     
    Size = sizeof(StatusData);
    ErrorCode = MFS_GetStatus(ConfigPortHandle, CardID, NULL, &Size, StatusData);   
    printf("MFS_GetStatus %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    PrintBuffer(StatusData, Size, Size);        
    printf("Mode: %2.2X, SubMode: %2.2X, FPGAIndex: %2.2X\n", StatusData[0], StatusData[1], ((StatusData[2] & 0xF0) >> 4));   
    
    
    ClosePorts(); // Disconnect and close configuration port               
    printf("Finished\n");
    return 0;
  }
  else
  {         
    printf("Can not load MFSatCard.dll\n"); 
    return 1;
  }
}
