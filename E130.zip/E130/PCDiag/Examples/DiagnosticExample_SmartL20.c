/***************************************************************************
/* DiagnosticExample_SmartL20.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

#define MaxLength  1024



int main()
{
  char *S;


  // Set Protocol
  SetProtocolTyp(cSMARTL20);
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);

  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("ini\\SRE-SMART-L20", "Landrover", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }

  SleepDelay(2000);

  printf("Logout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
