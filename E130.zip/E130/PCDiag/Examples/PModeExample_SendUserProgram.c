/***************************************************************************
/* PModeExample_SendUserProgram.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
//  PMode-Sample: Send User Program
//
//  Example of performing Send User Program
//
//  using: SendUserProgram()
//         SetIniFile(), Login(), Reset() 
// 
//  Reset ECU, logon using INI-File, 
//  SendUserProgram AWL Lamp off, SleepDelay 4000
//  SendUserProgram AWL Lamp on,  SleepDelay 4000
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()  
{
  unsigned char mem[1024];
  int i;
  char *s;
  printf("Load INI-File\n");

  if (SetIniFile("VW3", "609", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;
 
// ------- SendUserProgram -----------------------------------------  
  printf("Start Send User Program AWL_Lamp Off\n" );
  s = "$C6 $01 $02 x X AA 02 C7 01 02 CC FD ED";
  SendUserProgram(s);  
  if (CheckError()) {
       printf("\nError : SendUserProgram \n");
       return 0;
   }
  SleepDelay(4000);
  printf("Start Send User Program AWL_Lamp On " );
  s = "C60102AA02C70102CCFDEA";
  SendUserProgram(s);
  if (CheckError()) {
       printf("\nError : SendUserProgramt 2\n");
       return 0;
   }  
  SleepDelay(4000);

  printf("Send User Program finished\n");

  printf("\nLogout!\n");
  Logout();
  if (CheckError()) return 0;

  printf("--End Stop\n");

  return 0;
}
