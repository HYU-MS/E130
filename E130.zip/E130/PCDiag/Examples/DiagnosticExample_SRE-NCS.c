/***************************************************************************
/* DiagnosticExample_SRE-NCS.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>
#include <string.h>

#define MaxLength  1024



int main()
{
  char *S;
  unsigned char data[MaxLength];
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size, Count;


  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("NCS.ini", "5WY6", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Set Protocol
  SetProtocolTyp(cSRENCS);
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);

  // Login
  printf("\nLogin");
  Login();
  Size = GetReceivedTelegram(mem, 13);
  if( CheckError() )
    {
      return 0;
    } else {
      PrintBuffer(mem, Size, 16);
    }


  // Identification
  printf("\nIdentification:");
  Identification();
  Size = GetReceivedTelegram(mem, 13);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  // Read Status
  printf("\nRead Status");
  SRENCSReadStatus();
  Size = GetReceivedTelegram(mem, 5);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


   // Read Operation Time
  printf("\nRead Operation Time");
  SRENCSReadOperationTime();
  Size = GetReceivedTelegram(mem, 7);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  // Read Snap Shot
  printf("\nRead SnapShot");
  SRENCSSnapShot();
  Size = GetReceivedTelegram(mem, 15);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  // Clear Fault Memory
  printf("\nClear Fault Memory");
  SRENCSClearFaultMemory();
  Size = GetReceivedTelegram(mem, 4);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  printf("\nLogout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}