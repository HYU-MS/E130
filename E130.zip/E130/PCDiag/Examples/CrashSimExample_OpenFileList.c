/***************************************************************************
/* CrashSimExample_OpenFileList.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>

char FileListName[] = "Filelist.txt";
char *FileName;
int i;
int OK;

int main() {
   printf("Start OpenFileList: %s\n",FileListName);
   
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }
   
   
   if( !OpenFileList(FileListName) )
   { return 1;}

   for(i=0; i<=10; i++)
   {
     FileName = GetFileName(i);
     printf("Filename %i = %s\n",i,FileName);
   }

   printf("End OpenFileList\n");
   return 0;
}
