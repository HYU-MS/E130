/***************************************************************************
/* CrashSimExample_Execute.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>

char *ParameterText;
int OK;

int main() {
	
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }		
	
   CrashSimSetLogging(1);

   printf("Start CrashSim\n");
   
   
   
   CrashSimInit();
   CrashSimBoot();

   EXECUTE();
   RECORDRESULTS();

   printf("End CrashSim\n");

   return 0;
}
