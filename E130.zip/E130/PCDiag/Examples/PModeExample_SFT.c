/***************************************************************************
/* PModeExample_SFT.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample:    Single Fault Test
//
//  Example of performing Demand Measure Values
//
//  using: SingleFaultTest(),GetReceivedData()
//         SetIniFile(), Login(), Reset()
//
//  Reset ECU, logon using INI-File,
//  start DemandMeasureValues and Show results.
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i;
  int Count;
  int TimeOut;

  printf("Load INI-File\n");

  if (SetIniFile("VW5","605", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

 // printf("Reset ECU\n");
 // Reset();
  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;


  TimeOut = 8000;
  printf("StartSingleFaultTest: TimeOut:%i ms\n",TimeOut );
  StartSingleFaultTest(TimeOut, "SFT.txt");

  SleepDelay(8000);  // <-- here you can start for example a crash

  StopSingleFaultTest();

  Count = GetReceivedData(mem, 1024);
  if (CheckError()) return 0;
  printf("SingleFaultTest Values:\n");

  printf("Count %i:\n",Count);
  PrintBuffer(mem,Count, 1);
  if (CheckError()) return 0;



  printf("SingleFaultTest: TimeOut:%i ms\n", TimeOut );
  SingleFaultTest(TimeOut);
  if (CheckError()) {
       printf("\nError: SingleFaultTest \n");
       return 0;
   }
  printf("SingleFaultTest finished\n");

  Count = GetReceivedData(mem, 1024);
  if (CheckError()) return 0;
  printf("SingleFaultTest Values:\n");

  printf("Count %i:\n",Count);
  for (i = 0; i < Count; i++) printf("%.2X ", mem[i]);
  if (CheckError()) return 0;

  printf("\nLogout!\n");
  Logout();
  if (CheckError()) return 0;

  printf("--End Stop\n");

  return 0;
}
