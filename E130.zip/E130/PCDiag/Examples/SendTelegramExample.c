/***************************************************************************
/* SendTelegramExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <string.h>

int main()
{
  int i;
  unsigned char Mem[1024];
  unsigned char Data[100];
  int count;

  // Set Protocol
  SetProtocolTyp("HONDA");

  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("HONDA", "HRS3", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }

  printf("HondaSleepProhibit()");
  HondaSleepProhibit();
  if( CheckError() ) { return 0; }


  printf("SendTelegram()");
  Data[0] = 0x60;
  Data[1] = 0x05;
  Data[2] = 0x70;
  Data[3] = 0x10;
  Data[4] = 0x1B;

  SendTelegram(Data, 5, 0);

  if( CheckError() ) { return 0; }
  count = GetReceivedTelegram(Mem, 256);
  printf("count: %i  \nData: ", count);
  PrintBuffer(Mem, count, 16);


  printf("End Stop\n");

  return 0;
}