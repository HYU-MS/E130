/***************************************************************************
/* OCSSuzukiRequest.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>
#include <string.h>          // memset()

#define cTXDBufferSize 10
#define cRXDBufferSize 256
#define cTrue          1
#define cFalse         0

int main()
{
  unsigned char TXD[cTXDBufferSize];
  unsigned char RXD[cRXDBufferSize];
  int TXDSize;
  int RXDSize;
  int AutoCS;  // 0 --> false; 1 --> true


//if (SetIniFile("OCSSUZUKI", "Kernel", 1))          // Load the COM Port Parameters Kernel Interface
                                               // please install the before use the "PCDiagNT IO-Port & Timer & Serial Driver 6.05"
  if (SetIniFile("OCSSUZUKI", "WinAPI", 1))          // Load the COM Port Parameters WinApi Interface
  {
    printf("Parameter file not found!");
    return 0;
  }
  SetProtocolTyp(cOCSSUZUKI);

  Login();

  AutoCS = cTrue;
  TXDSize = 2;
  RXDSize = cRXDBufferSize;
  memset(TXD, 0x00, cTXDBufferSize);
  TXD[0] = 0x28;


  printf("Start OCSRequest\n");
  OCSRequest(TXD, TXDSize, RXD, &RXDSize, AutoCS);
  CheckError();
  printf("\n");

  printf("TXD  ");
  PrintBuffer(TXD, TXDSize, TXDSize);
  printf("\n");

  printf("\nRXD  ");
  PrintBuffer(RXD, RXDSize, RXDSize);
  printf("\n");

  Logout();
  printf("Finish");
  return 0;
}