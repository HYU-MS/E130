/***************************************************************************
/* DiagnosticExample_HMC.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, ID, Size;
  unsigned char Data[] = {0x50,0x43,0x44,0x49,0x41,0x47,0x20,0x48,0x4D,0x43,0x20,0x00,0x06,0x0C,0x03,0x00};


  printf("Load INI-File\n");
  if (SetIniFile("HMC", "PB", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set HMC Protocoltype\n");
  SetProtocolTyp("HMCCAN");


  //-----------------------------------------------------------------------------------------
  // Login HMC Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;

  /*
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession Extended\n");
  StartDiagnosticSession(0x90, 1);      //Satrt Extended Session with Security Access
  if (CheckError()) return 0;
  */

  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x90, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("SecurityAccess Extended\n");
  SecurityAccess(0x01);             // Extended Session Key
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("ECUIdentification\n");
  ECUIdentification(0x80);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("ReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0x44);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("ReadDTCByStatus\n");
  ReadDTCByStatus(0x00, 0x8000);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("ReadStatusOfDTC\n");
  ReadStatusOfDTC(0x9527);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("ClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);


  //-----------------------------------------------------------------------------------------
  ID      = 0x05;  
  Data[0] = 0x00;  
  Size    = 0;
  
  printf("FunctRoutineRun\n");
  FunctRoutineRun(ID, Data, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  ID      = 0x05;  
  Data[0] = 0x00;  
  Size    = 0;

  printf("StartRoutineByLocalIdentifier\n");
  StartRoutineByLocalIdentifier(ID, Data, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  printf("StartRoutineByLocalIdentifier\n");
  RequestRoutineResultByLocalIdentifier(ID);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  printf("StopRoutineByLocalIdentifier\n");
  StopRoutineByLocalIdentifier(ID);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);


  //-----------------------------------------------------------------------------------------
  printf("WriteDataByLocalIdentifier\n");
  WriteDataByLocalIdentifier(0xF190, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("ReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF190);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("WriteDataByIdentifier\n");
  WriteDataByIdentifier(0xF190, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);



  //-----------------------------------------------------------------------------------------
  printf("Reset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("Logout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}