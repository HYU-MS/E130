/***************************************************************************
/* PModeExample_login.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>

int main() 
{
  int i;unsigned char mem[1024];
  unsigned char *data;
  int i;
  int count;

  printf("Load INI-File\n");

  if (SetIniFile("VW3", "609", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Start PMode\n");
  
  Login();
  if (CheckError()) return 0;

  count = GetReceivedTelegram(mem, 24);
  count = 10;
  if (CheckError()) return 0;
  printf("\nFertig : ddd \n");
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  if (CheckError()) 
   {
       printf("\nError : GetReceivedTelegram\n");
       return 0;
   }


  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
