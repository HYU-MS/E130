/***************************************************************************
/* PModeExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 05.10.2015 THF
/*
/**************************************************************************/

#include <PMode.c>

#define HEXOPT_DATAFLASH_FILENAME      "..\\Data\\DataFlash_PageConfig.hexopt-cfg"    
#define DATAFLASH_FILENAME_S37         "..\\Data\\ManufacturingData.s37"
#define DATAFLASH_FILENAME_HEXBAT      "..\\Data\\Batch\\ManufacturingData.hex-bat"
#define CODEFLASH_FILENAME             "..\\Data\\CodeFlash.par"



int main() 
{
  unsigned char mem[1024];
  int i, Count; 
  char* OutputName; 
  

  printf("Start\n");  
  
  printf("SetCANParameters()\n");            
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  CheckErrorCR();
  
  printf("SetIniFile()\n");   
  if (SetIniFile("PMODE", "EOLSpeed30_2_Toolboxes", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
        
  
  SetProtocolTyp(cEOL);
  
  Login(); // EOL-Login
  if (CheckErrorCR()) return 0;
            
  printf("ActivateETSToolbox()\n");
  ActivateETSToolbox(cETSToolboxTypeUnicom_rh850_f1l, ".\\Data\\FlashLog.txt");   // realtive to the root folder of PModeD.dll
  CheckErrorCR(); 
  

  Count = GetHexOptOutputCount(HEXOPT_DATAFLASH_FILENAME); 
  for (i=0; i < Count; i++)
  {
    OutputName = GetHexOptOutputByIndex(HEXOPT_DATAFLASH_FILENAME, i);  
    printf("HexOpt output name[%i]: %s\n", i, OutputName);  
  }    
  
  printf("EraseETSPage()\n");
//  EraseETSPage(3, 1, "", cETSTargetCodeFlash); 
  EraseETSPage(480, 2, "", cETSTargetDataFlash);      
      
  printf("FlashETSFile()\n");
//  FlashETSFile(CODEFLASH_FILENAME, "", cETSTargetCodeFlash, HEXOPT_RUN, cETSWriteModeComplete, 1);  
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetDataFlash, HEXOPT_NO_RUN, cETSWriteModeComplete, 0);   
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetDataFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);     
  
//  FlashETSFile(DATAFLASH_FILENAME_HEXBAT, "", cETSTargetDataFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);  

  FlashETSFile(DATAFLASH_FILENAME_S37, HEXOPT_DATAFLASH_FILENAME, cETSTargetDataFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);    
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetDataFlash, HEXOPT_RUN, cETSWriteModeMerge, 1);  // use the HexOpt file defined in the *.prj file  
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, HEXOPT_DATAFLASH_FILENAME, cETSTargetDataFlash, HEXOPT_RUN   , cETSWriteModeMerge, 1);  // use the defined HexOpt file defined as parameter 
  
  
  CheckErrorCR();
                  
  printf("DeactivateETSToolbox()\n");
  DeactivateETSToolbox();
  CheckErrorCR();
  

  Logout(); // EOL-Logout
  if (CheckErrorCR()) return 0;

  printf("End Stop\n");

  return 0;
}
