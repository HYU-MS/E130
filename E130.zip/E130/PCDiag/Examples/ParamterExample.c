/***************************************************************************
/* ParamterExample.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
// Get parameter Example
/*--------------------------------------------------------------------------
/* History:
/* 07.05.2009 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)   
{       
  int i;

  printf("ParameterCount: %i:\n", argc);
  for (i = 0; i < argc ; i++) printf("Parameter[%i]: %s:\n", i, argv[i]);
  
  return 0;
}
