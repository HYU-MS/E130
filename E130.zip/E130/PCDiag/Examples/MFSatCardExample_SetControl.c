/***************************************************************************
/* MFSatCardExample_SetControl.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program                       
/* THF Evolution GmbH
/*
// MFSatCard-Sample: SetControl() & SetControlBuffer() MFSatCard function code 0x22
//
// 
//         
//
/*--------------------------------------------------------------------------
/* History:
/* 01.08.2014 THF
/*
/**************************************************************************/

#include <MFSatCard_dll.h>
#include <PMode.c>

#include <stdio.h>

void* ConfigPortHandle = NULL;   

//******************************************************************************
void OpenPorts(void)
{ 
  int ConfigPortNo = 1; 
  int ErrorCode;  
  
  // Open and connect configuration port
  ErrorCode = MFS_OpenCOMPort(ConfigPortNo, 38400, &ConfigPortHandle);
  printf("OpenCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   
       
  ErrorCode = MFS_ConnectConfigPort(ConfigPortHandle, 1000); 
  printf("ConnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));     
    
  ErrorCode = MFS_OpenMonitor(ConfigPortHandle, "Configuration Port COM 1", 50, 500, 400, 600); 
  printf("OpenMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
}

//******************************************************************************
void ClosePorts(void)
{
  int ErrorCode;  
   
  // Disconnect and close configuration port   
  ErrorCode = MFS_CloseMonitor(ConfigPortHandle);
  printf("CloseMonitor %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));  
    
  ErrorCode = MFS_DisconnectConfigPort(ConfigPortHandle);  
  printf("DisconnectConfigPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));                 
    
  ErrorCode = MFS_CloseCOMPort(ConfigPortHandle);
  printf("CloseCOMPort %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
}

int main()
{
  unsigned char CardID = 0x00;
  int ErrorCode;    
  int Size;  
  unsigned char Data[200];    


  if (MFSatCardLoadDLL() == 1) 
  {    
    OpenPorts(); // Open and connect configuration port
                       
    
    ErrorCode = MFS_SetControl(ConfigPortHandle, CardID, NULL, 0x04, 0x1234);     
    printf("MFS_SetControl() %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode)); 
             
    Size = 3;
    Data[0] = 0x04;   
    Data[1] = 0x05;
    Data[2] = 0x06;
    ErrorCode = MFS_SetControlBuffer(ConfigPortHandle, CardID, NULL, 0x04, Size, Data);     
    printf("MFS_SetControlBuffer() %i --> %s\n", ErrorCode, MFS_GetErrorText(ErrorCode));   

    
    ClosePorts(); // Disconnect and close configuration port   

    printf("Finished\n");
    return 0;
  }
  else
  {         
    printf("Can not load MFSatCard.dll\n"); 
    return 1;
  }
}
