/***************************************************************************
/* IOPortExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 13.01.2012 THF
/* 17.04.2013 THF Changes for RelaisCard Version 2.0
//* 11.06.2013 Change DLL-Version 2.0.0.1 Add new functions IOSetSinglePort() & IOGetSinglePort() & IOGetTrigger() &
//*                                       IOGetTriggerLatched() & IOGetADRawData() & IOGet_HS_LS_Current() & IOGetVoltage()
/**************************************************************************/

#include <RelayCard.h>
#include <EICBase.h>
#include <stdio.h>


int main()
{
  int i, error, DeviceIndex, CardNo;
  char* text;  
  char* SerialNo; 
  char* CardInfo;
  unsigned short OutData, InData;       
  unsigned char OutValue, InValue;

  printf("Start\n\n"); 

  CardNo = IOCardGetCardsCount();
  printf("IOCardGetCardsCount:  %i\n" ,CardNo);    


  SerialNo = IOCardGetSerialNoByIndex(0);
  printf("IOCardGetSerialNoByIndex: %s \n" ,SerialNo);       
   
  CardInfo = IOCardGetCardIDByIndex(0);
  printf("IOCardGetCardIDByIndex: %s \n" ,CardInfo);    

  CardNo = IOCardGetIndexBySerialNo(SerialNo);
  printf("IOCardGetIndexBySerialNo: %i \n" ,CardNo);   

  DeviceIndex = 0; 
                
  //**********************************************************
  OutData = 0x55;
  error = IOCardSetPort(DeviceIndex, OutData);
  printf("IOCardSetPort  OutData: 0x%2.2X \n",  OutData);  
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
      
               
  OutData = 0xAA;
  error = IOCardSetPort(DeviceIndex, OutData);
  printf("IOCardSetPort  OutData: 0x%2.2X \n",  OutData);
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);    
  
   
  InData = 0x00;
  error = IOCardGetPort(DeviceIndex, &InData);
  printf("IOCardGetPort   InData: 0x%2.2X \n", InData); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
  
  OutData = 0x00;
  error = IOCardSetPort(DeviceIndex, OutData);
  printf("IOCardSetPort  OutData: 0x%2.2X \n",  OutData);
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);    
  
           
  
  OutValue = 1;
  error = IOCardSetSinglePort(DeviceIndex, OutValue, RELAIS_1); 
  printf("IOCardSetSinglePort   OutValue: 0x%2.2X \n", OutValue); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
          
  
  InValue = 0;
  error = IOCardGetSinglePort(DeviceIndex, &InValue, RELAIS_1); 
  printf("IOCardGetSinglePort   InValue: 0x%2.2X \n", InValue);  
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  
       
  
  InValue = 0;
  error = IOCardGetTrigger(DeviceIndex, &InValue); 
  printf("IOCardGetTrigger   InValue: %i \n", InValue); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  
         
         
  InValue = 0;
  error = IOCardGetTriggerLatched(DeviceIndex, &InValue);  
  printf("IOCardGetTriggerLatched   InValue: %i \n", InValue); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  
           
        
  InData = 0;
  error = IOCardGetADRawData(DeviceIndex, &InData, VPERI_VOLTAGE_RAWDATA_CHANNEL);
  printf("IOCardGetADRawData   InData: %i \n", InData); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  
           
        
  InData = 0;
  error = IOCardGet_HS_LS_Current(DeviceIndex, &InData, LS1_CURRENT_CHANNEL);  
  printf("IOCardGet_HS_LS_Current   InData: %imA \n", InData);   
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  
         
           
  InData = 0;
  error = IOCardGetVoltage(DeviceIndex, &InData, VPERI_VOLTAGE_CHANNEL); 
  printf("IOCardGetVoltage   InData: %imV \n", InData); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);  


  printf("\nEnd\n");

  return 0;
}