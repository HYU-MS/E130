/***************************************************************************
/* IniFileExample_Topic.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/* 12.10.2012 THF Adapt to *.prj file up PCDiagNT versioin 2.7.0.0
/*
/**************************************************************************/

#include <stdio.h>
#include <PModeD.h>

  //------------------------------------------
  void PrintParam( struct sIniParameter Param)
  {
    printf("Typ: %s | ",Param.Typ);
    printf("SW: %s | ",Param.SW);
    printf("Variable: %s | ",Param.Variable);
    printf("Text: %s | ",Param.Text);
    printf("Wert: %i | ",Param.Wert);
    printf("Adresse: %8.8x | ",Param.Adresse);
    printf("Adresse2: %8.8x | ",Param.Adresse2);
    printf("Anzahl: %i | ",Param.Anzahl);
    printf("Verknuepfung: %i | ",Param.Verknuepfung);
    printf("Verarbeitung: %i | ",Param.Verarbeitung);
    printf("Faktor1: %f | ",Param.Faktor1);
    printf("Faktor2: %f | ",Param.Faktor2);
    printf("Faktor3: %f | ",Param.Faktor3);
    printf("Kurztext1: %s | ",Param.Kurztext1);
    printf("Kurztext2: %s | ",Param.Kurztext2);
    printf("MaskenNr: %s | ",Param.MaskenNr);
    printf("\n\n");
  }

//-------------------------------------------------------------------
 int main()
 {
  struct sIniParameter Param;
  int found;

  printf("Load Project-File\n");
  if (SetIniFile("PMode", "CAN", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  found = PModeParamGetFirstTopic("Adressen", &Param);
  if(found)
  {
    while(found)
    {
      PrintParam(Param);
      found = PModeParamGetNextTopic(&Param);
    }
  }


  printf("End");
  return 0;
 }