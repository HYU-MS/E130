/***************************************************************************
/* DiagnosticExample_SYMC.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 09.10.2008 THF
/*
/**************************************************************************/

#include <PMode.c>


int main()
{
  unsigned char mem[1024];
  int i, count;
 

  printf("Load INI-File\n");
  if (SetIniFile("SYMC", "SPEED-10", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }


  printf("Set SYMC Protocoltype\n");
  SetProtocolTyp("SYMC");

  //-----------------------------------------------------------------------------------------
  // Login SYMC-KLine Diagnostic
  printf("\nLogin\n");
  Login();                               //StartCommunication
  if (CheckError()) return 0;
 
  //-----------------------------------------------------------------------------------------
  printf("\nECUIdentification\n");
  ECUIdentification(0x80);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
 
  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatus\n");
  ReadDTCByStatus(0x00, 0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

  //-----------------------------------------------------------------------------------------
  printf("\nReadStatusOfDTC\n");
  ReadStatusOfDTC(0x9527);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0x08);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // StopCommunication
  if( CheckError() ) { return 0; }

  printf("\nFinished\n");
  return 0;
}