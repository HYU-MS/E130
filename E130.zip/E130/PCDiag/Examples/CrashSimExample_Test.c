/***************************************************************************
/* CrashSimExample_Test.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the CrashSim LogFile
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <CrashSimD.h>


int main()
{
   double Value;
   int i, i2;
   char String[1024];
   int OK;
   
   
   printf("Start\n");
   
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }

   CrashSimSetLogFileName("Log1File.txt");
   PAUSE(1);
   CrashSimSetLogging(1);
   CrashSimSetLogTypes(1,1,1,0,1);
   CrashSimGetVersion();
   CrashSimInit();
   CrashSimBoot();

ChannelSetFilename(1, "Test.dat");
ChannelGetFilename(1,String);

ChannelSetScale(1, 1);
ChannelIncScale(1, 2);
ChannelGetScale(1, &Value);

ChannelSetOffset(1, 1);
ChannelIncOffset(1, 2);
ChannelGetOffset(1, &Value);

ChannelSetDelay(1, 1);
ChannelIncDelay(1, 2);
ChannelGetDelay(1, &i);

ChannelSetLink(1, 1);
ChannelGetLink(1, &i);

ChannelSetZero(1, 1);
ChannelIncZero(1, 2);
ChannelGetZero(1, &Value);

ChannelSetSelfTest(1, 1);
ChannelIncSelfTest(1, 2);
ChannelGetSelfTest(1, &Value);

ChannelSetSense(1, 1);
ChannelIncSense(1, 2);
ChannelGetSense(1, &Value);

ChannelSetPWM(1, 1);
ChannelGetPWM(1, &i);

ChannelSetGain(1, 1);
ChannelIncGain(1, 2);
ChannelGetGain(1, &Value);

ChannelSetCenter(1, 1);
ChannelIncCenter(1, 2);
ChannelGetCenter(1, &Value);

InputSetZPThresholds(1, 2, 12);
InputGetZPThresholds(1, 2, &Value);
InputGetTTF(1, 2, &Value);

SetDigitalOutput(1, 1, 100, 200);
GetDigitalOutput(1, 1, &i, &i2);



   printf("End\n");
   return 0;
}
