/***************************************************************************
/* SPI-SensorExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>


int main()
{
  int i;   
  unsigned short MISO, MOSI;

   
  SetProtocolTyp("SAT-SPI");  // Set Protocol

  if (SetIniFile("Sensor", "SPI", 3))  // // Load Ini-File, Data COM-Port
  {
    printf("Parameter file not found!");
    return 0;
  }             


 if (SPI_Init("SDF_SPI_Sensor_XY2kHz.sdf", 2) == 0)  // MFSat Config file, MFSatCard Config COM-Port
 {   
    printf("SPI Init Fail!");
    return 0;            
 }     
    

    
  MOSI = SPI_WR_GRANGE(0x33);    
  MOSI = SPI_RD_GRANGE();                         printf("SPI_WR_GRANGE--> 0x%4.4X \n", MOSI); 
  MOSI = SPI_RD_SENSOR_DATA(0x00);                printf("SPI_RD_GRANGE--> 0x%4.4X \n", MOSI); 

  if (GetErrorCode() == 0) 
  {
    MOSI = SPI_WR_DEVCTL_REG(0x18);
    MOSI = SPI_RD_DEVICE_ID();                    printf("SPI_WR_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_REVISION_ID();                  printf("SPI_RD_DEVICE_ID--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_DEVSTAT_REG();                  printf("SPI_RD_REVISION_ID--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x02);              printf("SPI_RD_DEVSTAT_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x03);              printf("SPI_RD_SENSOR_DATA 02--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_DEVCTL_REG();                   printf("SPI_RD_SENSOR_DATA 03--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x01);              printf("SPI_RD_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
   
   for (i=0; i<45; i++)
    {
      MOSI = SPI_RD_SENSOR_DATA(0x00);            printf("SPI_RD_SENSOR_DATA Y--> 0x%4.4X \n", MOSI); 
      MOSI = SPI_RD_SENSOR_DATA(0x01);            printf("SPI_RD_SENSOR_DATA X--> 0x%4.4X \n", MOSI); 
    }                    
      
    MOSI = SPI_WR_DEVCTL_REG(0x19);
    MOSI = SPI_RD_DEVCTL_REG();                   printf("SPI_WR_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x01);              printf("SPI_RD_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    
    for (i=0; i<10; i++)
    {
      MOSI = SPI_RD_SENSOR_DATA(0x00);            printf("SPI_RD_SENSOR_DATA Y--> 0x%4.4X \n", MOSI); 
      MOSI = SPI_RD_SENSOR_DATA(0x01);            printf("SPI_RD_SENSOR_DATA X--> 0x%4.4X \n", MOSI); 
    }      
    
    MOSI = SPI_WR_DEVCTL_REG(0x1B);
    MOSI = SPI_RD_DEVCTL_REG();                   printf("SPI_WR_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x01);              printf("SPI_RD_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
  
    for (i=0; i<10; i++)
    {
      MOSI = SPI_RD_SENSOR_DATA(0x00);            printf("SPI_RD_SENSOR_DATA Y--> 0x%4.4X \n", MOSI); 
      MOSI = SPI_RD_SENSOR_DATA(0x01);            printf("SPI_RD_SENSOR_DATA X--> 0x%4.4X \n", MOSI); 
    }

    MOSI = SPI_WR_DEVCTL_REG(0x18);
    MOSI = SPI_RD_DEVCTL_REG();                   printf("SPI_WR_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x01);              printf("SPI_RD_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
   
    for (i=0; i<45; i++)
    {
      MOSI = SPI_RD_SENSOR_DATA(0x00);            printf("SPI_RD_SENSOR_DATA Y--> 0x%4.4X \n", MOSI); 
      MOSI = SPI_RD_SENSOR_DATA(0x01);            printf("SPI_RD_SENSOR_DATA X--> 0x%4.4X \n", MOSI); 
    }
                 
            
    MOSI = SPI_WR_DEVCTL_REG(0x38);
    MOSI = SPI_RD_DEVCTL_REG();                   printf("SPI_WR_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_DEVSTAT_REG();                  printf("SPI_RD_DEVCTL_REG--> 0x%4.4X \n", MOSI); 
    MOSI = SPI_RD_SENSOR_DATA(0x00);              printf("SPI_RD_DEVSTAT_REG--> 0x%4.4X \n", MOSI); 
  }
      
                   
  MOSI = SPI_RD_READCNT();
  MOSI = SPI_RD_SENSOR_DATA(0x00);                printf("SPI_RD_READCNT--> 0x%4.4X \n", MOSI); 
  
  MOSI = SPI_SendMOSI(0x2000); 
  MOSI = SPI_SendMOSI(0x6000);                    printf("SendMOSI(0x2000) = RD_SENSOR_DATA X)--> 0x%4.4X \n", MOSI); 
  MOSI = SPI_SendMOSI(0x6000);                    printf("SendMOSI(0x6000) = RD_SENSOR_DATA Y)--> 0x%4.4X \n", MOSI);       
  
 
  if (SPI_Done == 0) 
 {   
    printf("SPI Init Fail!");
    return 0;            
 }    


  printf("End \n");

  return 0;
}
