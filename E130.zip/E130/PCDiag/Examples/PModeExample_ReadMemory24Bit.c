/***************************************************************************
/* PModeExample_ReadMemory24Bit.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

int main()
{
  unsigned char mem[1024];
  int i;

  if (SetIniFile("HMC", "OC", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
  Login();
  if (CheckError()) return 0;

  ReadMemory24Bit(mem, 0x0800, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]);

  for (i = 0; i < 20; i++) mem[i] = i;
  WriteMemory24Bit(mem, 0x0800, 20);

  Logout();
  CheckError();
   return 0;
}