/***************************************************************************
/* PModeExample_manuel_login.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Login setting parameters
//
//  Using: SetBreakChar(), SetTimes(), SetSerialPort()
//         SetBaudRates(), Login() and GetReceivedTelegram()
//
//  Logon setting patameters
//  and show Identification of ECU after sucessfull login.
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i;
  int count;
  int bufferlength;

  printf("Setting parameter\n");

  //SetBreakChar("B");                   // needed for some ECU's
  SetTimes (5, 30, 3500, 3500, 1000);
  SetReadWriteSize (40, 16);
  SetSerialPort (1, 19200, 8, 0, 1);
  SetBaudRates (19200,57600);
  printf("Start PMode login\n");

  Login();
  if (CheckError()) return 0;

  bufferlength = 24;
  count = GetReceivedTelegram(mem, bufferlength );
  if (CheckError()) {
      printf("Error : GetReceivedTelegram\n");
      return 0;
  }

  printf("Telegram length: %i \n", count);
  for (i = 0; i < bufferlength -1 ; i++) printf("%.2X ", mem[i]);



  printf("\nPMode logout\n");

  Logout();
  if (CheckError()) return 0;

  printf("\n--End Stop\n");

  return 0;
}
