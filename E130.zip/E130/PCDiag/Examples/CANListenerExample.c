/***************************************************************************
/* CANListener_Example.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*
/*--------------------------------------------------------------------------
/* History:
/* 15.11.2010 THF
/* 11.10.2017 THF add SetIniFile() because CAN-Settings
/* 02.04.2019 THF add CANFD support
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

#define MESSAGELIST_COUNT 1000


//**************************************************************************
void GetAndDisplayMessages(unsigned int ID, int ExtendedIDFlag)
{
  int i, k;
  struct tCANFilter CANFilter;  
  struct tCANRxdData MessageList[MESSAGELIST_COUNT];  
  int MessagesCount;
      
  printf("--------------------------------------------------\n"); 
  MessagesCount = MESSAGELIST_COUNT; 
  
  CANFilter.ExtendedIDFlag = ExtendedIDFlag;
  CANFilter.ID             = ID;  
  CANListenerGetMessages(&CANFilter, MessageList, &MessagesCount); 
  CheckError(); 
  printf("\n");   
                                                   
  printf("ID: %8.8X   MessagesCount: %i\n", CANFilter.ID, MessagesCount); 
  for (i = 0; i < MessagesCount; i++) 
  {
    printf("CAN-ID: %8.8X\n", MessageList[i].ID); 
    printf("TimeStamp[ms]: %d\n", MessageList[i].TimeStamp);  
    
    printf("DataCount: %i  Data: ", MessageList[i].DataCount); 
    for (k = 0; k < MessageList[i].DataCount; k++)
    {
      printf("%2.2X;", MessageList[i].Data[k]);
    }  
    printf("\n\n"); 
  }  
}



//**************************************************************************
int main()
{
  struct tCANFilter CANFilterList[5];  
  int FilterCount;   
          
  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
                         
   if (SetIniFile("PMode", "CAN_XLibrary", 1)) {      // Used for CAN-Settings parameter 'ListenerCANSettings'
    printf("Parameter file not found!");
    return 0;
  }    


  // Set filter, which CAN messages are should recorded
  FilterCount = 4;
  CANFilterList[0].ExtendedIDFlag = 0;
  CANFilterList[0].ID             = 0x156;   
  
  CANFilterList[1].ExtendedIDFlag = 0;
  CANFilterList[1].ID             = 0x320;
 
  CANFilterList[2].ExtendedIDFlag = 1;
  CANFilterList[2].ID             = 0x1B000015;    
  
  CANFilterList[3].ExtendedIDFlag = 1;
  CANFilterList[3].ID             = 0x1C420015;
                                                                 
//  CANListenerOpen(CANFilterList, FilterCount, cCANTypeCAN);  // set filter and start recording CAN-Classic
  CANListenerOpen(CANFilterList, FilterCount, cCANTypeCANFD);  // set filter and start recording CAN-FD
  CheckError();  
  printf("\n");
  

//  // Set no filter, all CAN messages are recorded
//  CANListenerOpen(NULL, 0); // set no filter and start recording
//  CheckError(); 
//  printf("\n"); 
     
  CANListenerClearMessages();  // clear the recording list

  
  SleepDelay(1000);  // wait until the CAN messages are recorded, here any other function can called 
  
  CANListenerClose();  // stop recording      
  
  GetAndDisplayMessages(0x156, 0); // Get only recorded messages with this standard CAN ID 
  GetAndDisplayMessages(0x320, 0); // Get only recorded messages with this standard CAN ID 
  GetAndDisplayMessages(0x5D2, 0); // Get only recorded messages with this standard CAN ID 
  GetAndDisplayMessages(0x1B000015, 1); // Get only recorded messages with this extended CAN ID  
  GetAndDisplayMessages(0x000, 0); // Get all recorded CAN messages        
  
  return 0;
}