/***************************************************************************
/* PModeExample_ReadMemory32Bit.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>

int main()
{
  unsigned char mem[1024];
  int i;  
  


  if (SetIniFile("PMode", "CAN", 1)) {
    printf("Parameter file not found!");
    return 0;
  }           

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);    
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
 
  
  Login();
  if (CheckError()) return 0;

  ReadMemory32Bit(mem, 0x0800, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]);

//  for (i = 0; i < 20; i++) mem[i] = i;
//  WriteMemory32Bit(mem, 0x0800, 20);

  Logout();
  CheckError();
  return 0;
}