/***************************************************************************
/* VirtualTesterPresentExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 10.02.2013 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <PModeD.h>


int main()
{
  int i, index, ok; 
  struct tVCar VCarElement;
                 
  
  printf("Start\n");    
  
  if (SetIniFile("Honda", "HRS7", 0))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);

  
  VCarOpen(0);  // Open the Virtual Car // 0 = empty; 1 = load configuration from Project-Ini-File
   
  index = VCarNewElement();   // Add new element to the Virtual Car list       
  if (index >= 0) 
  {
    ok = VCarGetElement(i, &VCarElement); // Get the element 
    if(ok == 1)
    { 
      // Manipulate the element data  
      // Main 
      VCarElement.Type                   = 1;  
      VCarElement.StartDelayTime         = 0;
      VCarElement.CycleTime              = 2000;    // Tester Presen Cylce Time
      // TXD
      VCarElement.TxtData.Active         = 1;
      VCarElement.TxtData.ExtendedIDFlag = 1;
      VCarElement.TxtData.ID             = 0x18DA53F1;
      VCarElement.TxtData.DataCount      = 8;
      VCarElement.TxtData.Data[0]        = 0x02;
      VCarElement.TxtData.Data[1]        = 0x3E;
      VCarElement.TxtData.Data[2]        = 0x80;
      VCarElement.TxtData.Data[3]        = 0x;
      VCarElement.TxtData.Data[4]        = 0xFF;
      VCarElement.TxtData.Data[5]        = 0xFF;
      VCarElement.TxtData.Data[6]        = 0xFF;   
      VCarElement.TxtData.Data[7]        = 0xFF; 
      // RXD
      VCarElement.RxdDataListCount       = 0;                                
        
      ok = VCarSetElement(i, &VCarElement); // Set the manipulated element 
      if(ok != 1) printf("Error VCarSetElement()\n");    
    } 
    else printf("Error VCarGetElement()\n");   
    
    
     VCarStart();        // Start Virtual Car (Testerpreset) 
     printf("Wait\n");   
     SleepDelay(10000);  // <-- Wait do here your other actions
     VCarStop();         // Stop Virtual Car (Testerpreset)  
     
     VCarDeleteElement(index);    // Delete element from Virtual Car list
  }
  
     
  
  VCarClose();    // Close the Virtual Car & free the memory


  printf("End\n");
  return 0;
}