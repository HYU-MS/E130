/***************************************************************************
/* PModeExample_ClearEDRMemory79.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*
/*--------------------------------------------------------------------------
/* History:
/* 25.11.2010 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>                                             

int main()
{
  if (SetIniFile("PMode", "CANAutoSAR", 1))
  {
    printf("Parameter file not found!");
    return 0;
  }
  Login();
  if (CheckError()) return 0;

  printf("ClearEDRMemory79()\n");  
  ClearEDRMemory79();
  if (!CheckError())
  {
    printf("ClearEDRMemory79 successful\n");  
   }
  Logout();
  
  return 0;
}