/***************************************************************************
/* Pragma_LinkLibraryExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/


#pragma linklibrary("DemoD.Dll", "Demo.h" )


#include <stdio.h>
#include <Demo.h>

int main() {


  int i, i1, i2, i3;
  double d, d1,d2,d3;
  float f1, f2, f3;
  unsigned char byte;

  byte = 55;
  byte = Test_char__char(byte);
  printf("byte: %i   \n",byte);

  i1 = 11;
  i2 = 123456;
  i3 = 100;

  i = Test_int_int_int__int( i1, i2, i3);
  printf("i: %i   \n",i);

  i1 = 1;
  d2 = 1.234;
  f3 = 5.678;
  d1 = Test_int_double_float__double(i1, d2, f3);
  printf("d: %f   \n",d1);

  i1 = 1;
  d2 = 2.0;
  f3 = 3.0;
  Test_intX_doubleX_floatX__void(&i1, &d2, &f3);
  printf("i1: %i   d2: %f   f3: %f  \n",i1, d2 , f3);

  return 0;
}