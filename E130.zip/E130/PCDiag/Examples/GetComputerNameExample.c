/***************************************************************************
/* GetComputerNameExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// GetComputerName(), GetComputerUserName()
/*--------------------------------------------------------------------------
/* History:
/* 15.12.2011 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <EICBase.h>

int main()
{
   char* S;
          
   S = GetComputerName();
   printf("ComputerName: %s\n", S); 
   
   S = GetComputerUserName();     
   printf("UserName: %s\n", S); 

   return 0;
}