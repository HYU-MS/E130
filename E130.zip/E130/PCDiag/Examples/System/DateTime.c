/***************************************************************************
/* DateTime.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 13.04.2013 THF
/*
/**************************************************************************/


#include <PMode.c>
#include <time.h>



int main()
{
  struct tm *TimeStructGm; 
  struct tm *TimeStructLocal; 
  time_t Time;

  time(&Time);             
  //TimeStructGm = gmtime(&Time);        // 2 Stunden eventuell zur�ck !!
  TimeStructLocal = localtime(&Time);  
  
  //printf("UTC-date-time   %i.%i.%i   %i:%i:%i\n\n", TimeStructGm->tm_mday,  TimeStructGm->tm_mon + 1, TimeStructGm->tm_year + 1900, TimeStructGm->tm_hour, TimeStructGm->tm_min, TimeStructGm->tm_sec);    
  printf("Local-date-time %i.%i.%i   %i:%i:%i\n\n", TimeStructLocal->tm_mday,  TimeStructLocal->tm_mon + 1, TimeStructLocal->tm_year + 1900, TimeStructLocal->tm_hour, TimeStructLocal->tm_min, TimeStructLocal->tm_sec);
//                           
//  struct tm {
//        int tm_sec;     /* seconds after the minute - [0,59] */
//        int tm_min;     /* minutes after the hour - [0,59] */
//        int tm_hour;    /* hours since midnight - [0,23] */
//        int tm_mday;    /* day of the month - [1,31] */
//        int tm_mon;     /* months since January - [0,11] */
//        int tm_year;    /* years since 1900 */
//        int tm_wday;    /* days since Sunday - [0,6] */
//        int tm_yday;    /* days since January 1 - [0,365] */
//        int tm_isdst;   /* daylight savings time flag */
//        };
  
  


  return 0;
}