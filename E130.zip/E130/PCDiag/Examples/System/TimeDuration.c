/***************************************************************************
/* TimeDuration.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <PModeD.h>
#include <time.h>


int main()
{
   clock_t start, finish;
   double  duration;

   printf( "Start measure\n");
   start = clock();

   SleepDelay(200);

   finish = clock();
   duration = (double)(finish - start) / CLOCKS_PER_SEC;
   printf("%2.3f seconds\n", duration);

   return 0;
}