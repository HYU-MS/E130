/***************************************************************************
/* PModeExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>

int main() 
{
  unsigned char mem[1024];
  int i;

  printf("Start PMode\n");
  
  if (SetIniFile("VW5", "605", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  Login();
  if (CheckError()) return 0;

  CopyData(ECUtoPC, mem, 0x0800, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]);
  printf("\n");

  ClearCrash();
  if (CheckError()) return 0;

  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
