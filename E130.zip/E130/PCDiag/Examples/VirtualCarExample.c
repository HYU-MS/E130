/***************************************************************************
/* VirtualCarExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/* 02.04.2019 THF New CANFD support
/*
/**************************************************************************/

#include <stdio.h>
#include <PModeD.h>


int main()
{
  int i, count, index, ok; 
  struct tVCar VCarElement;
                 
  
  printf("Start\n");    
  
  if (SetIniFile("VirtualCar", "CANFD", 0))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  
  VCarOpen(1);  // Open the Virtual Car // 0 = empty; 1 = load configuration from Project-Ini-File
  VCarStart();  // Start Virtual Car
  
  count = VCarElementCount(); 
  for(i=0; i<count; i++)
  {
    ok = VCarGetElement(i, &VCarElement); // Get the element 
    if(ok == 1)
    { 
      // Manipulate the element data  
      // Main 
      VCarElement.Type                   = 2;  
      VCarElement.StartDelayTime         = 1000;
      VCarElement.CycleTime              = 55; 
      // TXD
      VCarElement.TxtData.Active         = 1;
      VCarElement.TxtData.ExtendedIDFlag = 0;
      VCarElement.TxtData.ID             = 0x05FC;
      VCarElement.TxtData.DataCount      = 8;
      VCarElement.TxtData.Data[0]        = 0xA1;
      VCarElement.TxtData.Data[1]        = 0xA2;
      VCarElement.TxtData.Data[2]        = 0xA3;
      VCarElement.TxtData.Data[3]        = 0xA4;
      VCarElement.TxtData.Data[4]        = 0xA5;
      VCarElement.TxtData.Data[5]        = 0xA6;
      VCarElement.TxtData.Data[6]        = 0xA7;   
      VCarElement.TxtData.Data[7]        = 0xA8; 
      // RXD
      VCarElement.RxdDataListCount              = 1;  
      VCarElement.RxdDataList[0].Active         = 1;
      VCarElement.RxdDataList[0].Action         = 1;       
      VCarElement.RxdDataList[0].ExtendedIDFlag = 0;
      VCarElement.RxdDataList[0].ID             = 0x316; 
      
      // CAN-Classic
//      VCarElement.RxdDataList[0].DataCount      = 8;
//      
//      VCarElement.RxdDataList[0].Data[0]        = 0xB1;
//      VCarElement.RxdDataList[0].Data[1]        = 0xB2;
//      VCarElement.RxdDataList[0].Data[2]        = 0xB3;
//      VCarElement.RxdDataList[0].Data[3]        = 0x00;                   
//      VCarElement.RxdDataList[0].Data[4]        = 0x00;
//      VCarElement.RxdDataList[0].Data[5]        = 0x00;
//      VCarElement.RxdDataList[0].Data[6]        = 0xB7;   
//      VCarElement.RxdDataList[0].Data[7]        = 0xB8;   
//      
//      VCarElement.RxdDataList[0].DataMask[0]    = 0xFF;
//      VCarElement.RxdDataList[0].DataMask[1]    = 0xFF;
//      VCarElement.RxdDataList[0].DataMask[2]    = 0xFF;
//      VCarElement.RxdDataList[0].DataMask[3]    = 0x00;
//      VCarElement.RxdDataList[0].DataMask[4]    = 0x00;
//      VCarElement.RxdDataList[0].DataMask[5]    = 0x00;
//      VCarElement.RxdDataList[0].DataMask[6]    = 0xFF;   
//      VCarElement.RxdDataList[0].DataMask[7]    = 0xF8;    
      
      // CAN-FD
      VCarElement.RxdDataList[0].DataCount      = 12;
      
      VCarElement.RxdDataList[0].Data[0]        = 0xB1;
      VCarElement.RxdDataList[0].Data[1]        = 0xB2;
      VCarElement.RxdDataList[0].Data[2]        = 0xB3;
      VCarElement.RxdDataList[0].Data[3]        = 0x00;                   
      VCarElement.RxdDataList[0].Data[4]        = 0x00;
      VCarElement.RxdDataList[0].Data[5]        = 0x00;
      VCarElement.RxdDataList[0].Data[6]        = 0xB7;   
      VCarElement.RxdDataList[0].Data[7]        = 0xB8;   
      VCarElement.RxdDataList[0].Data[8]        = 0xB9;   
      VCarElement.RxdDataList[0].Data[9]        = 0xBA;   
      VCarElement.RxdDataList[0].Data[10]       = 0xBB;    
      VCarElement.RxdDataList[0].Data[11]       = 0xBC;   
      
      VCarElement.RxdDataList[0].DataMask[0]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[1]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[2]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[3]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[4]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[5]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[6]    = 0x00;   
      VCarElement.RxdDataList[0].DataMask[7]    = 0x00;  
      VCarElement.RxdDataList[0].DataMask[8]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[9]    = 0x00;
      VCarElement.RxdDataList[0].DataMask[10]   = 0x00;
      VCarElement.RxdDataList[0].DataMask[11]   = 0xFF;
                                  
        
      ok = VCarSetElement(i, &VCarElement); // Set the manipulated element 
      if(ok != 1) printf("Error VCarSetElement()\n");    
    } 
    else printf("Error VCarGetElement()\n");    
  } 
  
  
  VCarStop();     // Stop Virtual Car  
   
  
  
//______________________________________________________________________________  
  index = VCarNewElement();   // Add new element to the Virtual Car list
       
  if (index >= 0) 
  {
    ok = VCarGetElement(i, &VCarElement); // Get the element 
    if(ok == 1)
    { 
      // Manipulate the element data  
      // Main 
      VCarElement.Type                   = 1;  
      VCarElement.StartDelayTime         = 1500;
      VCarElement.CycleTime              = 100; 
      // TXD
      VCarElement.TxtData.Active         = 1;
      VCarElement.TxtData.ExtendedIDFlag = 0;
      VCarElement.TxtData.ID             = 0x316;  
      
      // CAN-Classic
//      VCarElement.TxtData.DataCount      = 8;
//      VCarElement.TxtData.Data[0]        = 0xC1;
//      VCarElement.TxtData.Data[1]        = 0xC2;
//      VCarElement.TxtData.Data[2]        = 0xC3;
//      VCarElement.TxtData.Data[3]        = 0xC4;
//      VCarElement.TxtData.Data[4]        = 0xC5;
//      VCarElement.TxtData.Data[5]        = 0xC6;
//      VCarElement.TxtData.Data[6]        = 0xC7;   
//      VCarElement.TxtData.Data[7]        = 0xC8;  
   
      
      // CAN-FD
      VCarElement.TxtData.DataCount      = 12;
      VCarElement.TxtData.Data[0]        = 0xC1;
      VCarElement.TxtData.Data[1]        = 0xC2;
      VCarElement.TxtData.Data[2]        = 0xC3;
      VCarElement.TxtData.Data[3]        = 0xC4;
      VCarElement.TxtData.Data[4]        = 0xC5;
      VCarElement.TxtData.Data[5]        = 0xC6;
      VCarElement.TxtData.Data[6]        = 0xC7;   
      VCarElement.TxtData.Data[7]        = 0xC8;  
      VCarElement.TxtData.Data[8]        = 0xA1; 
      VCarElement.TxtData.Data[9]        = 0xA2;  
      VCarElement.TxtData.Data[10]       = 0xA3; 
      VCarElement.TxtData.Data[11]       = 0xBC; 
                  
      
      // RXD
      VCarElement.RxdDataListCount       = 0;                                
        
      ok = VCarSetElement(i, &VCarElement); // Set the manipulated element 
      if(ok != 1) printf("Error VCarSetElement()\n");    
    } 
    else printf("Error VCarGetElement()\n");   
    
    
     VCarStart();       // Start Virtual Car  
     printf("Wait\n");   
     SleepDelay(5000);  // Wait 
     VCarStop();        // Stop Virtual Car  
     
     VCarDeleteElement(index);    // Delete element from Virtual Car list
  }
  
     
  
  VCarClose();    // Close the Virtual Car & free the memory


  printf("End\n");
  return 0;
}