/***************************************************************************
/* CrashSimExample_TTL and Relays.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the digital outputs and Relays
// Standard Box & Extended Boxes
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>
#include <CrashSimD.h>

int main()
{
   int Box, Channel;
   int ValueHigh, ValueLow;
   int OK;
   
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }

   CrashSimSetLogging(1);

   printf("Start CrashSim\n");
   CrashSimInit();
   CrashSimBoot();



   Box = 1;
   Channel = 1;


  /* ValueHigh = 100;
   ValueLow  = 200;
   DIO(1, ValueHigh, ValueLow);
   PAUSE(2000);
   ValueHigh = 200;
   ValueLow  = 100;
   DIO(1, ValueHigh, ValueLow);
   PAUSE(2000);
   ValueHigh = 0;
   ValueLow  = 0;
   DIO(1, ValueHigh, ValueLow);
   printf("DIO\n");
    */

   ValueHigh = 100;
   ValueLow  = 300;
   printf("SetDigitalOutput\n");
   SetDigitalOutput(Box, Channel, ValueHigh, ValueLow);
   ValueHigh = 0;
   ValueLow  = 0;
   GetDigitalOutput(Box, Channel, &ValueHigh, &ValueLow);
   printf("%i   %i\n",ValueHigh, ValueLow);

   PAUSE(2000);
   ValueHigh = 200;
   ValueLow  = 100;
   printf("SetDigitalOutput\n");
   SetDigitalOutput(Box, Channel, ValueHigh, ValueLow);

   PAUSE(2000);
   ValueHigh = 0;
   ValueLow  = 0;
   printf("SetDigitalOutput\n");
   SetDigitalOutput(Box, Channel, ValueHigh, ValueLow);

   printf("End\n");

   return 0;
}
