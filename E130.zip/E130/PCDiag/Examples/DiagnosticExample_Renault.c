/***************************************************************************
/* DiagnosticExample_Renault.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 16.09.2011 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;
  unsigned char Data[] = {0x50,0x43,0x44};   




  printf("Load INI-File\n");
  if (SetIniFile("Renault", "T4", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("RENAULTUDS");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic 
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session 0x81
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
//  printf("\nStartDiagnosticSession Programming\n");
//  StartDiagnosticSession(0x85, 0);      //Start Session without Security Access 
//  CheckError();   
  
  //-----------------------------------------------------------------------------------------
//  printf("\nStartDiagnosticSession Extended\n");
//  StartDiagnosticSession(0xC0, 0);      //Start Session without Security Access 
//  CheckError();
  
  //-----------------------------------------------------------------------------------------
//  printf("\nStartDiagnosticSession Scrapping\n");
//  StartDiagnosticSession(0x04, 0);      //Start Session without Security Access 
//  CheckError();  
  
  //-----------------------------------------------------------------------------------------
//  printf("\nStartDiagnosticSession Default\n");
//  StartDiagnosticSession(0x81, 0);      //Start Session without Security Access 
//  CheckError(); 

  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  CheckError();
 

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatusMask\n");
  ReadDTCByStatusMask(0xF9);
  count = GetReceivedTelegram(mem, 24);
  CheckError();
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0xF1);
  
  //-----------------------------------------------------------------------------------------
  printf("\nWriteDataByLocalIdentifier\n");
  WriteDataByLocalIdentifier(0x44, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  CheckError();
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
 
  //-----------------------------------------------------------------------------------------
  printf("\nInputOutputControlByLocalIdentifier\n");
  InputOutputControlByLocalIdentifier(0x12, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  CheckError();
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
  

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}