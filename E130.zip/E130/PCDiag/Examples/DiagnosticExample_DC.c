/***************************************************************************
/* DiagnosticExample_DC.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count, ID, Size;
  unsigned char Data[100];


  printf("Load INI-File\n");
  if (SetIniFile("DC", "Aramis1", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set DC Protocoltype\n");
  SetProtocolTyp("DC");


  //-----------------------------------------------------------------------------------------
  // Login DC Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;

  /*
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession Extended\n");
  StartDiagnosticSession(0x92, 1);      //Start Extended Session with Security Access
  if (CheckError()) return 0;
  */
  
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x92, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;

  //-----------------------------------------------------------------------------------------
  printf("SecurityAccess Extended\n");
  SecurityAccess(0x01);             // Extended Session Key
  if (CheckError()) return 0;
   
  //-----------------------------------------------------------------------------------------
  printf("ECUIdentification\n");
  ECUIdentification(0x87);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
  printf("\n\n");

  //-----------------------------------------------------------------------------------------
  printf("ReadDataByLocalIdentifier\n");
  ReadDataByLocalIdentifier(0x02);
  count = GetReceivedTelegram(mem, 300);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");  
  
   //-----------------------------------------------------------------------------------------
  printf("WriteDataByLocalIdentifier\n"); 
  for (i = 0; i < count; i++) Data[i] = mem[i];  
  WriteDataByLocalIdentifier(0x02, Data, count);
  count = GetReceivedTelegram(mem, 300);
  //if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
  printf("\n\n");

  //-----------------------------------------------------------------------------------------
  printf("ReadDTCByStatus\n");
  ReadDTCByStatus(0x02, 0xFF00);
  count = GetReceivedTelegram(mem, 300);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
  printf("\n\n");

  //-----------------------------------------------------------------------------------------
  printf("ReadStatusOfDTC\n");
  ReadStatusOfDTC(0xC171);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
  printf("\n\n");
        
  //-----------------------------------------------------------------------------------------
  printf("ClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 24);
  //if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
  printf("\n\n");
    
  //-----------------------------------------------------------------------------------------
  printf("DisableNormalMessageTransmission\n");  
  DisableNormalMessageTransmission(0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
  printf("\n\n");   
  
  //-----------------------------------------------------------------------------------------
  printf("EnableNormalMessageTransmission\n");  
  EnableNormalMessageTransmission(0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
  printf("\n\n");
  
  //-----------------------------------------------------------------------------------------
  printf("ControlDTCSettingMode\n");  
  ControlDTCSettingMode(0x01, 0xFF00, 0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
  printf("\n\n");

  //-----------------------------------------------------------------------------------------
  ID      = 0x14;  
  Data[0] = 0x00;  
  Data[1] = 0x00; 
  Size    = 2;

  printf("StartRoutineByLocalIdentifier\n");
  StartRoutineByLocalIdentifier(ID, Data, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");  


  //-----------------------------------------------------------------------------------------
  printf("Reset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;  
  printf("\n\n"); 


  //-----------------------------------------------------------------------------------------
  printf("Logout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}