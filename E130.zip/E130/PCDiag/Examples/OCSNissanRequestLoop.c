/***************************************************************************
/* OCSNissanRequestLoop.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>
#include <string.h>          // memset()
#include <EICBase.h>       // Messagebox



#define cTXDBufferSize 10
#define cRXDBufferSize 256
#define cTrue          1
#define cFalse         0

int main()
{
  unsigned char TXD[cTXDBufferSize];
  unsigned char RXD[cRXDBufferSize];
  int TXDSize;
  int RXDSize;
  int i, X, OK, Error, Retry, WaitTime, Value;
  int InterByteTime, InterBlockTime, Timeout;



//if (SetIniFile("OCSNISSAN", "Kernel", 1))          // Load the COM Port Parameters Kernel Interface
                                                     // please install the before use the "PCDiagNT IO-Port & Timer & Serial Driver 7.01"
  if (SetIniFile("OCSNISSAN", "WinAPI", 1))          // Load the COM Port Parameters WinApi Interface
  {
    printf("Parameter file not found!");
    return 0;
  }
  SetProtocolTyp(cOCSNISSAN);               // Set the OCS-Nissan-Protocol
  Login();                                  // Set The Protocol active
  Timeout = 20;                             // ms
  SetTimes(0, 0, 0, 0, Timeout);


  do
  {
    OK = MessageBox("Transmit A/B telegram", MsgConfirmation, ButtonOK | ButtonAbort);
    if(OK == IDOK)
    {
      memset(TXD, 0x00, cTXDBufferSize);
      TXDSize = 0;

      Value = 0;
      X = InputBoxInt("Input","Request", &Value, 1);
      if (X == IDOK) TXD[TXDSize++] = Value & 0xFF;

      Value = 200;
      X = InputBoxInt("Input","WaitTime:", &Value, 0);
      if (X == IDOK) WaitTime = Value; else WaitTime = 200;

      Value = 5;
      X = InputBoxInt("Input","Retry:", &Value, 1);
      if (X == IDOK) Retry = Value; else  Retry = 5;

      X = MessageBox("Start Transmit", MsgConfirmation, ButtonOK | ButtonAbort);
      if (X == IDOK)
      {
        Error = 0;
        for(i = 0; ((i < Retry) && (Error == 0)); i++)
        {
          SleepDelay(WaitTime);
          printf("OCSRequest\n");
          RXDSize = cRXDBufferSize;
          OCSRequest(TXD, 0, RXD, &RXDSize, 0);
          Error = GetErrorCode();
        }
        if( Error != 0)
        {
          printf("Error: %s\n", GetErrorText(Error));
        }
      }
    }
  }
  while(OK == ButtonOK);


  Logout();                     // Set The Protocol inactive
  printf("Finish");
  return 0;
}