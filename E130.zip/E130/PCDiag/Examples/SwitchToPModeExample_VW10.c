/***************************************************************************
/* SwitchToPModeExample_VW10.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;



  printf("Load INI-File\n");
  if (SetIniFile("VW10", "655", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("VWUDS");


  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x03, 1);    // Start Extended Session with Security Access
  if (CheckError()) return 0;
   
  
  //-----------------------------------------------------------------------------------------
  printf("\nSwitchToPMode\n");
  SwitchToPMode();
  if (CheckError()) return 0;
  
  //-----------------------------------------------------------------------------------------
  printf("\nPMode --> ReadMemory32Bit \n");  
  ReadMemory32Bit(mem, 0x80000, 20);
  if (CheckError()) return 0;
  for (i = 0; i < 20; i++) printf("%.2X ", mem[i]); 
  
  
  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}