/***************************************************************************
/* SwitchToPModeExample_Ford.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>
#include <string.h>

#define MaxLength  1024



//******************************************************************************************************************
int main()
{
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size;
  int Code, Command;

  int i, x;
  unsigned char *data;
  int count;
  char *S;


  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("FORD", "DCF-RCM", 1)) {
    printf("\nParameter file not found!");
    return 0;
  }

  // Set to Diagnostic
  SetProtocolTyp("FORD");
  S = GetProtocolName();
  printf("ProtocolName: %s",S);

  // Login Diagnostic
  printf("\nLogin\n");
  Login();
  if( CheckError() ) { return 0; }


  // FordDiagStateEntry
  printf("FordDiagStateEntry()\n");
  FordDiagStateEntry();
  CheckError();


  printf("\nProtocolName: %s\n", GetProtocolName() );

  // Switch from the Diagnostic to PMode
  SwitchToPMode();
  CheckError();

  printf("\nProtocolName: %s\n", GetProtocolName() );

  // PMode Memory Read
  StartAdr = 0x0800;
  EndAdr   = 0x081F;
  Size = EndAdr - StartAdr +1;

  printf("\nMemoryRead: ");
  ReadMemory(mem, StartAdr, Size);
  CheckError();

  PrintBuffer(mem,Size,16);


  // PMode Logout
  printf("\nLogout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}