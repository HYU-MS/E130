/***************************************************************************
/* PModeExample_FSRMeasurement.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: FSR-Measurement
//
//  Example of performing Send User Program
//
//  using: FSRMeasurement(), GetReceivedTelegram()
//         SetIniFile(), Login(), Reset()
//
//  When there is a Timout you can set the timeout time by an entry in the
//  projektparameter-file the default is 1000ms
//  SW:   CommPar
//  Var:  PModeTimeOut
//  Wert: 2000    [ms]

//
//  Reset ECU, logon using INI-File,
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int Count;
  int i,z;

  printf("Load INI-File\n");

  if (SetIniFile("VW5", "605", 1)) {           // Baudrate 10400 Baud
    printf("Parameter file not found!");
    return 0;
  }

  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;

// ------- FSRMeasurement -----------------------------------------

  printf("Start FSR-Measurement\n" );
  for(z=0;z < 50; z++)
  {
    FSRMeasurement(0x00,0x00);
    if (CheckError()) {
       printf("\nError : FSRMeasurement \n");
       return 0;
    }
    printf("FSR-Measurememt finished\n");
    Count = GetReceivedTelegram(mem, 255);
    if (CheckError()) return 0;
    printf("Datacount: %i \n",Count);
    printf("FSR-Measurememt Data: \n");
    for (i = 0; i < Count; i++) printf("%.2X ", mem[i]);
    printf("\n");
    SleepDelay(1000);
   }

  printf("Logout\n");
  Logout();
  printf("--End Stop\n");


  return 0;
}
