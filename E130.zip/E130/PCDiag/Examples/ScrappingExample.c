/***************************************************************************
/* ScrappingExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>

int main()
{
  unsigned char mem[1024];
  int i, count, ID, Size;
  unsigned char Data[100];


  printf("Load INI-File\n");
  if (SetIniFile("Scrapping", "UDS", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Srcapping Protocoltype\n");
  SetProtocolTyp("SCRAPPING");


  //-----------------------------------------------------------------------------------------
  // Login Srapping 
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;
  printf("\n\n");          
  
  //-----------------------------------------------------------------------------------------
  // --> Read info 
  //-----------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------
  printf("ReadDataByIdentifier\n");
  ReadDataByIdentifier(0xFA01);
  count = GetReceivedTelegram(mem, 100);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");   
  
  //-----------------------------------------------------------------------------------------
  printf("ReadDataByIdentifier\n");
  ReadDataByIdentifier(0xFA00);
  count = GetReceivedTelegram(mem, 100);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");    
  
  //-----------------------------------------------------------------------------------------
  printf("ReadDataByIdentifier\n");
  ReadDataByIdentifier(0xFA02);
  count = GetReceivedTelegram(mem, 100);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");   
  
  //-----------------------------------------------------------------------------------------
  printf("ReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF190);
  count = GetReceivedTelegram(mem, 100);
  //if (CheckError()) return 0;       // Alway false --> VW10 don't support this request
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n"); 
        
  
  //-----------------------------------------------------------------------------------------
  // --> Write Dismantler info 
  //-----------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------
  printf("WriteDataByLocalIdentifier\n");
  count    = 16;
  Data[0]  = 0x00; 
  Data[1]  = 0x00;
  Data[2]  = 0x00;
  Data[3]  = 0x00;
  Data[4]  = 0x00;
  Data[5]  = 0x00;
  Data[6]  = 0x00;
  Data[7]  = 0x00;
  Data[8]  = 0x00;
  Data[9]  = 0x00;
  Data[10] = 0x00;
  Data[11] = 0x00;  
  Data[12] = 0x00;
  Data[13] = 0x00;
  Data[14] = 0x00;
  Data[15] = 0x00;
  WriteDataByIdentifier(0xFA07, Data, count);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
  printf("\n\n"); 
     
              
  //-----------------------------------------------------------------------------------------
  // --> Securiy Access
  //-----------------------------------------------------------------------------------------
  //-----------------------------------------------------------------------------------------
  printf("StartDiagnosticSession\n");
  StartDiagnosticSession(0x04, 0);    // Start Scrapping Session without Security Access
  if (CheckError()) return 0;
  printf("\n\n");  
  
  //-----------------------------------------------------------------------------------------
  printf("SecurityAccess\n");
  SecurityAccess(0x00);             // The parameter is bei scrapping not used
  if (CheckError()) return 0;
  printf("\n\n");   


  //-----------------------------------------------------------------------------------------
  ID      = 0x01;  
  Size    = 3;
  Data[0] = 0xE2;  
  Data[1] = 0x00; 
  Data[2] = 0x01; 

  printf("RoutineControl\n");
  RoutineControl(ID, Data, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");   
  
  //-----------------------------------------------------------------------------------------
  ID      = 0x03;  
  Size    = 2;
  Data[0] = 0xE2;  
  Data[1] = 0x00; 

  printf("RoutineControl\n");
  RoutineControl(ID, Data, Size);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
  printf("\n\n");   
  
  
  //-----------------------------------------------------------------------------------------
  // --> Fire loop
  //-----------------------------------------------------------------------------------------
  
  if (IDYES == MessageBox("Do you really want to fire th loop?", MsgConfirmation , ButtonYes + ButtonNo) ) 
  {
    //-----------------------------------------------------------------------------------------
    ID      = 0x01;  
    Size    = 3;
    Data[0] = 0xE2;  
    Data[1] = 0x01; 
    Data[2] = 0x4B; 

    printf("RoutineControl\n");
    RoutineControl(ID, Data, Size);
    count = GetReceivedTelegram(mem, 24);
    if (CheckError()) return 0;
    for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
    printf("\n\n");   
                     
    //-----------------------------------------------------------------------------------------
    ID      = 0x03;  
    Size    = 3;
    Data[0] = 0xE2;  
    Data[1] = 0x01;
    Data[2] = 0x4B;  

    printf("RoutineControl\n");
    RoutineControl(ID, Data, Size);
    count = GetReceivedTelegram(mem, 24);
    if (CheckError()) return 0;
    for (i = 0; i < count; i++) printf("%.2X ", mem[i]);  
    printf("\n\n"); 
  }  
        
  //-----------------------------------------------------------------------------------------
  printf("Reset\n");
  ECUReset(0x81);
  if (CheckError()) return 0;  
  printf("\n\n"); 


  //-----------------------------------------------------------------------------------------
  printf("Logout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}