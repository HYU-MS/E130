/***************************************************************************
/* DiagnosticExample_Honda.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/* 30.10.2008 THF add HondaAllECUInitialization() & HondaSRSECUInitialization() 
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>
#include <string.h>

#define MaxLength  1024



int main()
{
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size;
  int Code, Command, State;

  int i, x;
  unsigned char Commands[10];
  int count;
  char *s1;
  char *s2;
  char *s3;
  char *s4;


  // Set Protocol
  SetProtocolTyp("HONDA");

  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("HONDA", "HRS4", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Login
  printf("Login\n");
  Login();
  if( CheckError() ) { return 0; }

  count = GetReceivedTelegram(mem, 256);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,16);
  

  printf("\nHondaAllECUInitialization()");
  HondaAllECUInitialization(70, 130, 990);
  if( CheckError() ) { return 0; }
  
  
  Commands[0] = 0x71;
  Commands[1] = 0xAA;
  Commands[2] = 0xBB;
  Size        = 3;
  
  printf("\nHondaSRSECUInitialization()\n");
  HondaSRSECUInitialization(Commands, Size, 1, 70, 130, 990, 30);
  if( CheckError() ) { return 0; }
  
  
   /*

  //  Sensor Compensation
  printf("HondaSensorCompensation()");
  State = HondaSensorCompensation(0x02,0x11);
  printf("State: %x \n", State);
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // Start ODU
  printf("HondaStartODU()");
  HondaStartODU();
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // Stop ODU
  printf("HondaStopODU()");
  HondaStopODU();
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // Single Function Test
  printf("HondaSingleFunctionTest()");
  HondaSingleFunctionTest(0x01);
  if( !CheckError() ) { printf("Result: %x \n", Code); }


  // Sleep Prohibit
  printf("HondaSleepProhibit()");
  HondaSleepProhibit();
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // Sleep Deactivate
  printf("HondaSleepDeactivate()");
  HondaSleepDeactivate();
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // Clear Funktions
  printf("HondaFaultRecordClear()");
  Code = HondaFaultRecordClear();   //0x01
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  printf("HondaOpRecordClear()");
  Code = HondaOpRecordClear();      //0x02
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  printf("HondaAllClear()");
  Code = HondaAllClear();           //0x03
  if( !CheckError() ) { printf("Result: %x \n", Code); }

  // manual Clear Function call
  printf("Manual Clear(): ");
  Command = 0x02;
  Code =  HondaClear(Command);
  if( !CheckError() )
  {
    if(Code = Command)
    {
      printf("Code: %x, ",Code);
      i = 0;
      while(i++ < 4)
      {
        Code =  HondaClear(Command + 0x10);
        printf("Code: %x, ",Code);
        if( CheckError() ) { break; }
        if( Code == (Command + 0x10) ) { break; }   // finished
        if( Code == (Command + 0x50) )              // fault
        {
         printf(" ECU error");
         break;
        }
      }
    }
    printf("\n");
  }


  // Memory Read
  StartAdr = 0x0000;
  EndAdr   = 0x00FF;
  Size = EndAdr - StartAdr +1;

  printf("MemoryRead: \n");
  ReadMemory(mem, StartAdr, Size);
  if( !CheckError() ){ PrintBuffer(mem, Size, 16); }


  // CopyData
  printf("CopyData: \n");
  memset(mem,0x00,Size);    // Buffer mit 0x00 f�llen
  CopyData(ECUtoPC, mem, StartAdr, Size);
  if( !CheckError() ){ PrintBuffer(mem, Size, 16); }


  // MemoryReadODU
  StartAdr = 0x0000;
  EndAdr   = 0x00FF;
  Size = EndAdr - StartAdr +1;
  printf("MemoryReadODU: \n");
  memset(mem,0x00,Size);    // Buffer mit 0x00 f�llen
  HondaReadMemoryODU(mem, StartAdr, Size,0x00);       // 0x00 = OPDS    0x10 = SWS
  if( !CheckError() ){ PrintBuffer(mem, Size, 16); }
  
  
  // ReadMemoryExpanded(mem, 
  StartAdr = 0x0000;
  EndAdr   = 0x00FF;  
  Size = EndAdr - StartAdr + 1;
  printf("HondaReadMemoryExpanded: \n");
  memset(mem, 0x00, Size);    // Buffer mit 0x00 f�llen
  HondaReadMemoryExpanded(mem, StartAdr, Size ,0x00);       
  if( !CheckError() ){ PrintBuffer(mem, Size, 16); }

                            */
  printf("Logout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
