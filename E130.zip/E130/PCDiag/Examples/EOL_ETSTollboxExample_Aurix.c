/***************************************************************************
/* EOL_ETSToolboxExample_Aurix.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/* Aurix one toolbox
/*--------------------------------------------------------------------------
/* History:
/* 19.06.2018 THF
/*
/**************************************************************************/

#include <PMode.c>

#define HEXOPT_CODEFLASH_FILENAME           "..\\EOL_Toolbox\\Data\\VW40_CodeFlash\\VW40_Appl_CF.hexopt-cfg"     
#define DATAFLASH_FILENAME_S37              "..\\EOL_Toolbox\\Data\\ManufacturingData.s37"
#define DATAFLASH_FILENAME_HEXBAT           "..\\EOL_Toolbox\\Data\\Batch\\ManufacturingData.hex-bat"
#define CODEFLASH_FILENAME                  "..\\EOL_Toolbox\\Data\\CodeFlash.par"



int main() 
{
  unsigned char mem[1024];
  int i, Count; 
  char* OutputName; 
  

  printf("Start\n");  
  
  printf("SetCANParameters()\n");            
  SetCANParameters(4 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  CheckErrorCR();
  
  printf("SetIniFile()\n");   
  if (SetIniFile("VW40", "655", 1)) {
    printf("Parameter file not found!");
    return 0;
  }
        
  
  SetProtocolTyp(cEOL);
  
  Login(); // EOL-Login
  if (CheckErrorCR()) return 0;
            
  printf("ActivateETSToolbox()\n");
  ActivateETSToolbox(cETSToolboxTypeUnicom_Infineon_TriCore, ".\\Data\\FlashLog.txt");   // realtive to the root folder of PModeD.dll
  CheckErrorCR(); 
  

  Count = GetHexOptOutputCount(HEXOPT_CODEFLASH_FILENAME); 
  for (i=0; i < Count; i++)
  {
    OutputName = GetHexOptOutputByIndex(HEXOPT_CODEFLASH_FILENAME, i);  
    printf("HexOpt output name[%i]: %s\n", i, OutputName);  
  }    
  
  printf("EraseETSPage()\n");
//  EraseETSPage(3, 1, "", cETSTargetCodeFlash); 
//  EraseETSPage(480, 2, "", cETSTargetDataFlash);      
      
  printf("FlashETSFile()\n");
//  FlashETSFile(CODEFLASH_FILENAME, "", cETSTargetDataFlash, HEXOPT_RUN, cETSWriteModeComplete, 1);  
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeComplete, 0);   
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);     
  
//  FlashETSFile(DATAFLASH_FILENAME_HEXBAT, "", cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);  

//  FlashETSFile(DATAFLASH_FILENAME_S37, HEXOPT_CODEFLASH_FILENAME, cETSTargetCodeFlash, HEXOPT_NO_RUN, cETSWriteModeMerge, 0);    
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, "", cETSTargetCodeFlash, HEXOPT_RUN, cETSWriteModeMerge, 1);  // use the HexOpt file defined in the *.prj file  
  
//  FlashETSFile(DATAFLASH_FILENAME_S37, HEXOPT_CODEFLASH_FILENAME, cETSTargetCodeFlash, HEXOPT_RUN   , cETSWriteModeMerge, 1);  // use the defined HexOpt file defined as parameter 
  
  
  CheckErrorCR();
                  
  printf("DeactivateETSToolbox()\n");
  DeactivateETSToolbox();
  CheckErrorCR();
  

  Logout(); // EOL-Logout
  if (CheckErrorCR()) return 0;

  printf("End Stop\n");

  return 0;
}
