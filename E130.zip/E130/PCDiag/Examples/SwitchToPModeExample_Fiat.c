/***************************************************************************
/* SwitchToPModeExample_Fiat.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>
#include <string.h>

#define MaxLength  1024



//******************************************************************************************************************
int main()
{
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size;
  int Code, Command;

  int i, x;
  unsigned char *data;
  int count;
  char *S;


  // Load Ini-File
  printf("\nLoad INI-File\n");
  if (SetIniFile("FIAT", "192", 1)) {
    printf("\nParameter file not found!");
    return 0;
  }

  // Set to Fiat-Diagnostic
  SetProtocolTyp("FIAT");
  S = GetProtocolName();
  printf("ProtocolName: %s",S);

  // Login Honda Diagnostic
  printf("\nLogin\n");
  Login();
  if( CheckError() ) { return 0; }

  // SnapShot 05h
  printf("FiatSnapShot(0x05)\n");
  FiatSnapShot(0x05);
  CheckError();

  count = GetReceivedData(mem, 10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,16);


  printf("ProtocolName: %s\n", GetProtocolName() );

  // Switch from the Fiat Diagnostic to PMode
  SwitchToPMode();
  CheckError();

  printf("ProtocolName: %s\n", GetProtocolName() );

  // PMode Memory Read
  StartAdr = 0x0800;
  EndAdr   = 0x081F;
  Size = EndAdr - StartAdr +1;

  printf("\nMemoryRead: ");
  ReadMemory(mem, StartAdr, Size);
  CheckError();

  PrintBuffer(mem,Size,16);


  // PMode Logout
  printf("\nLogout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
