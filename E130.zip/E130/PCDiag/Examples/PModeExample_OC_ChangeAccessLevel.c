/***************************************************************************
/* PModeExample_OC_ChangeAccessLevel.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <stdio.h>

int main()
{
  unsigned char mem[1024];
  int count;
  int level;

  printf("Load INI-File\n");

  if (SetIniFile("SUZUKIOC", "OC", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  printf("Login\n");

  Login();
  if (CheckError()) return 0;

  level = 2;
  printf("ChangeAccessLevel to %i\n", level);
  ChangeAccessLevel(level);
  if (CheckError()) return 0;

  count = GetReceivedTelegram(mem, 24);
  if (count == 1)
  {
    if (mem[0] == level)
    { printf("Level sucsessful changed to %i\n", mem[0]); }
    else
    { printf("Error changing Level %i\n", mem[0]); }
  }

  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}