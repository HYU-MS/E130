/***************************************************************************
/* CrashSimExample_Sensors.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
// Example for the Crashsim Sensors (yellow-Plugs)
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <CrashSim.c>
#include <CrashSimD.h>

int main()
{
   int Ch;
   int ValInt;
   double ValDouble;
   char FileName[256];
   int OK;

   printf("Start CrashSim\n");
   
   // Load the CrashSimD.dll 
   OK = CrashSimLoadDLL();
   if (OK == 0)
   {
     printf("Load CrashSimD.dll fail");
     return 0;
   }
   
   CrashSimInit();
   CrashSimBoot();

   // Set the Crashsim Output parameter
   printf("\nSet the Values\n");
   Ch = 1;
   ChannelSetZero(Ch,5);
   ChannelSetSelfTest(Ch,5);
   ChannelSetSense(Ch,5);
   ChannelSetPWM(Ch,1);
   ChannelSetGain(Ch,2);
   ChannelSetCenter(Ch,5);


   // Get the set values
   ChannelGetZero(Ch,&ValDouble);
   printf("GetZero: %f\n",ValDouble);

   ChannelGetSelfTest(Ch,&ValDouble);
   printf("GetSelfTest: %f\n",ValDouble);

   ChannelGetSense(Ch,&ValDouble);
   printf("GetSense: %f\n",ValDouble);

   ChannelGetPWM(Ch,&ValInt);
   printf("GePWM: %i\n",ValInt);

   ChannelGetGain(Ch,&ValDouble);
   printf("GetGain: %f\n",ValDouble);

   ChannelGetCenter(Ch,&ValDouble);
   printf("GetCenter: %f\n",ValDouble);


   // inc the values
   printf("\nInc the Values\n\n");
   ChannelIncZero(Ch,1.1);
   ChannelIncSelfTest(Ch,1.2);
   ChannelIncSense(Ch,1.3);
   ChannelIncGain(Ch,1.4);
   ChannelIncCenter(Ch,1.5);


   // Get the set values
   ChannelGetZero(Ch,&ValDouble);
   printf("GetZero: %f\n",ValDouble);

   ChannelGetSelfTest(Ch,&ValDouble);
   printf("GetSelfTest: %f\n",ValDouble);

   ChannelGetSense(Ch,&ValDouble);
   printf("GetSense: %f\n",ValDouble);

   ChannelGetPWM(Ch,&ValInt);
   printf("GetPWM: %i\n",ValInt);

   ChannelGetGain(Ch,&ValDouble);
   printf("GetGain: %f\n",ValDouble);

   ChannelGetCenter(Ch,&ValDouble);
   printf("GetCenter: %f\n",ValDouble);



   printf("Ececute\n");
   EXECUTE();

   printf("End\n");

   return 0;
}
