/***************************************************************************
/* PModeExample_DMV16Bit.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
//  PMode-Sample: Demand Measure Values
//
//  Example of performing Demand Measure Values
//
//  using: DemandMeasureValues(),GetReceivedData()
//         SetIniFile(), Login(), Reset()
//
//  Reset ECU, logon using INI-File,
//  start DemandMeasureValues and Show results.
/*--------------------------------------------------------------------------
/* History:
/* 18.03.2014 THF
/*
/**************************************************************************/

#include <PMode.c>

#define BLOCKSIZE 2
#define ARRAYSIZE 1024

struct tSFTRec
{
    unsigned int TimeStamp;
    unsigned char Data[BLOCKSIZE];
};



int main()
{
  struct tSFTRec SFTStructArray[ARRAYSIZE];
  unsigned int TimeStamp;
  unsigned char Data;

  unsigned char mem[1024];
  int i, k;
  int Code;
  int Count;
  int RecordCount;
  int RecordSize;
  int TimeOut;

  printf("Load INI-File\n");

  if (SetIniFile("PMode", "CAN", 1)) {
    printf("Parameter file not found!");
    return 0;
  }             
  
   printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);
  

  printf("Start PMode\n");
  Login();
  if (CheckError()) return 0;

// ------- DemandMeasureValues16Bit -----------------------------------------
  Code = 300;                 // 16Bit DMV function code
  RecordCount = 10;           // Record count
  RecordSize = 2;             // Record size
  TimeOut = 8000;             // Timeout
  printf("Start DemandMeasureValues: Code:%i RecordSize:%i RecordCount:%i TimeOut:%i ms\n", Code, RecordSize, RecordCount, TimeOut );
  StartDemandMeasureValues16Bit(Code, RecordCount, TimeOut, RecordSize, "DMV.txt");

  printf("-->start\n");
  SleepDelay(8000);  // <-- here you can start for example a crash
  printf("-->stop\n");

  StopDemandMeasureValues16Bit();

  Count = GetReceivedData(mem, 1024);  // Count = RecordSize * RecordCount
  if (CheckError()) return 0;
  printf("DemandMeasureValues Values:\n");
  printf("-->ende\n");
  printf("Count %i:\n", Count);
  PrintBuffer(mem, Count, RecordSize);
  if (CheckError()) return 0;

 
  RecordCount = 20;           // Record count
  RecordSize = 2;             // Record size 
  printf("DemandMeasureValues16Bit: Code:%i RecordSize:%i RecordCount:%i TimeOut:%i  ms\n", Code, RecordSize, RecordCount, TimeOut);
  DemandMeasureValues16Bit(Code, RecordCount, TimeOut, RecordSize);
  if (CheckError()) {
    printf("\nFehler : DemandMeasureValues \n");
    return 0;
  }
  printf("DemandMeasureValues finished\n");

  Count = GetReceivedData(mem, 1024);
  if (CheckError()) return 0;
  printf("DemandMeasureValues Values:\n");
  PrintBuffer(mem, Count, RecordSize);    
  
  
  Count = GetReceivedDataFormated(SFTStructArray, ARRAYSIZE, BLOCKSIZE);
  printf("Count: %i  BlockSize: %i\n\n", Count, BLOCKSIZE);

  for (i=0; i < Count; i++)
  {
    TimeStamp = SFTStructArray[i].TimeStamp;
    printf("TimeStamp: %u ms, ", TimeStamp);

    for (k=0; k < BLOCKSIZE; k++)
    { 
      Data = SFTStructArray[i].Data[k];
      printf("Data[%i]: 0x%x ", k, Data);
    }
    printf("\n");
  }  

  printf("\nLogout!\n");
  Logout();
  if (CheckError()) return 0;

  printf("--End Stop\n");

  return 0;
}
