/***************************************************************************
/* ListExample.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct tRec
{
        struct        tRec* Prev;
        struct        tRec* Next;
        char*               Text;
};


int main()
{
  struct tRec* First = NULL;
  struct tRec* p;
  struct tRec* Cur;
  char String1[500];
  char String2[500];
  char String3[500];
  int i;

  // Fill
  printf("--- Fill -----\n");
  for(i=0; i < 1000; i++)
  {
    Cur = p;
    p = (struct tRec*) malloc(sizeof(struct tRec));

    if(First)
     { Cur->Next = p; }
    else
     { First = p; }

    p->Prev = Cur;
    p->Next = NULL;

    sprintf(String1, "Line_%i", i);
    printf("%s\n", String1);
    p->Text = (char*) malloc(sizeof(char) * (strlen(String1)+1));
    strcpy(p->Text, String1);
  }


  // Output
  printf("--- Output -----\n");
  p = First;

  while(p)
  {
    printf("%s\n", p->Text);
    p = p->Next;
  }


  // Free
  printf("--- Free -----\n");
  p = First;
  while(p)
  {
    Cur = p;
    p = p->Next;
    printf("%s\n", Cur->Text);
    free(Cur->Text);
    free(Cur);
  }



  First = NULL;

  // Fill
  printf("--- Fill2 -----\n");
  for(i=0; i < 1000; i++)
  {
    Cur = p;
    p = (struct tRec*) malloc(sizeof(struct tRec));

    if(First)
     { Cur->Next = p; }
    else
     { First = p; }

    p->Prev = Cur;
    p->Next = NULL;

    sprintf(String1, "Line_%i", i);
    printf("%s\n", String1);
    p->Text = (char*) malloc(sizeof(char) * (strlen(String1)+1));
    strcpy(p->Text, String1);
  }


  // Output
  printf("--- Output2 -----\n");
  p = First;

  while(p)
  {
    printf("%s\n", p->Text);
    p = p->Next;
  }


  // Free
  printf("--- Free2 -----\n");
  p = First;
  while(p)
  {
    Cur = p;
    p = p->Next;
    printf("%s\n", Cur->Text);
    free(Cur->Text);
    free(Cur);
  }


 printf("--- End -----\n");
 return 0;
}