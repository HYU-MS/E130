/***************************************************************************
/* DiagnosticExample_SYMC_CAN.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 20.01.2014 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <EICBase.h>


//******************************************************************************
int main()
{  
  unsigned char mem[1024];  
  unsigned char SendBuffer[1024];   
  int i, count, size;    
  unsigned char Data[] = {0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D};  
  unsigned char Parameter[10];
                         
  
  printf("Load INI-File\n");
  if (SetIniFile("SYMC", "C210_CAN", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("SYMCCAN");



  //----------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Extended Diagnostic Session
  if (CheckError()) return 0;
                                   
//  //----------------------------------------------------------------------------
//  printf("\nDefaultSession\n");
//  StartDiagnosticSession(0x81, 0);    // Start Default Session without Security Access
//  if (CheckError()) return 0;       
  
  
  //------------------------------------------------------------------------------
  printf("\nExtendedSession\n");
  StartDiagnosticSession(0x92, 1);    // Start Extended Session with Security Access
  if (CheckError()) return 0;         // Note if the "Parameter-->ExtendedSessionID" is in the *.prj file is set then 0x10 XX is send
    
//  //----------------------------------------------------------------------------
//  printf("\nExtendedSession\n");
//  StartDiagnosticSession(0x92, 0);    // Start Extended Session without Security Access
//  if (CheckError()) return 0;         // Note if the "Parameter-->ExtendedSessionID" is in the *.prj file is set then 0x10 XX is send
//  //----------------------------------------------------------------------------
//  printf("\nSecurityAccess\n");
//  SecurityAccess(0x01);              // Programming Session: Security Access Key 0x01 
//  if (CheckError()) return 0;  
  
//  //----------------------------------------------------------------------------
//  printf("\nProgrammingSession\n");
//  StartDiagnosticSession(0x85, 1);    // Start Programming Session with Security Access
//  if (CheckError()) return 0;         // Note if the "Parameter-->ProgrammingSessionID" is in the *.prj file is set then 0x10 XX is send
             

  //----------------------------------------------------------------------------
  printf("\nECUIdentification\n");
  ECUIdentification(0x87);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
       
  
  //----------------------------------------------------------------------------
  printf("\nReadDTCByStatus\n");
  ReadDTCByStatus(0x00, 0xFF00);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
        
  
  //----------------------------------------------------------------------------
  printf("\nReadStatusOfDTC\n");
  ReadStatusOfDTC(0x9527);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
   
  
  //----------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFF00);
  count = GetReceivedTelegram(mem, 1024);
  if (CheckError()) return 0;
  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
      
    
//  //----------------------------------------------------------------------------
//  printf("\nReadDataByLocalIdentifier\n");
//  ReadDataByLocalIdentifier(0x80);
//  count = GetReceivedTelegram(mem, 24);
//  if (CheckError()) return 0;
//  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
       
 
//  //----------------------------------------------------------------------------
//  printf("\nWriteDataByLocalIdentifier\n");
//  WriteDataByLocalIdentifier(0x80, Data, sizeof(Data));
//  count = GetReceivedTelegram(mem, 1024);
//  if (CheckError()) return 0;
//  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);     
     
          
//  //----------------------------------------------------------------------------
//  printf("\nControlDTCSettings\n");
//  ControlDTCSettings(0x02, NULL, 0);
//  count = GetReceivedTelegram(mem, 24);
//  if (CheckError()) return 0;
//  for (i = 0; i < count; i++) printf("%.2X ", mem[i]); 
                          
 
//  //----------------------------------------------------------------------------
//  printf("\nCommunicationControl\n");
//  CommunicationControl(0x00, 0x01);
//  count = GetReceivedTelegram(mem, 24);
//  if (CheckError()) return 0;
//  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);
  

//  //----------------------------------------------------------------------------
//  printf("\nRoutineControl\n");
//  size = 2;
//  SendBuffer[0] = 0x00;  
//  SendBuffer[1] = 0x00;  
//  RoutineControl(0x00, SendBuffer, size);
//  count = GetReceivedTelegram(mem, 24);
//  if (CheckError()) return 0;
//  for (i = 0; i < count; i++) printf("%.2X ", mem[i]);

  
  //----------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0;   

  //----------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }

  printf("\nFinished\n");
  return 0;
}