/***************************************************************************
/* DiagnosticExample_Suzuki_UDSn.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 03.08.2012 THF
/*
/**************************************************************************/

#include <PMode.c>

int main()
{
  unsigned char mem[1024];
  int i, count;    
  unsigned char Data[] = {0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D,0x2D};


  printf("Load INI-File\n");
  if (SetIniFile("Suzuki", "YA_UDS", 1))
  {
    printf("\nParameter file not found!\n");
    return 0;
  }

  printf("Set CAN Parameters\n");
  SetCANParameters(1 + cCANVectorDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANPeakDeviceOffset, 0, 1);
  //SetCANParameters(1 + cCANNeoIVDeviceOffset, 0, 1);

  printf("Set Protocoltype\n");
  SetProtocolTyp("SUZUKIUDS");



  //-----------------------------------------------------------------------------------------
  // Login Diagnostic
  printf("\nLogin\n");
  Login();                               //Start Diagnostic Session
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession Default\n");
  StartDiagnosticSession(0x01, 0);      //Start EOL Session with Security Access
  if (CheckError()) return 0;


  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Programming\n");
  StartDiagnosticSession(0x02, 1);    // Start Programming Session with Security Access
  if (CheckError()) return 0;     
  
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  EDR\n");
  StartDiagnosticSession(0x40, 1);    // Start EDR Session with Security Access
  if (CheckError()) return 0;     
          
    
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  EDR\n");
  StartDiagnosticSession(0x40, 0);    // Start EDR Session without Security Access
  if (CheckError()) return 0;                   
  //-----------------------------------------------------------------------------------------
  printf("SecurityAccess EDR\n");
  SecurityAccess(0x21);             // EDR Session: Security Access Key 0x21
  if (CheckError()) return 0;
      
            
  //----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Programming\n");
  StartDiagnosticSession(0x02, 0);    // Start Programming Session without Security Access
  if (CheckError()) return 0;       
  //-----------------------------------------------------------------------------------------
  printf("SecurityAccess Programming\n");
  SecurityAccess(0x01);             // Programming Session: Security Access Key 0x01 
  if (CheckError()) return 0;
       
                          
  
  //-----------------------------------------------------------------------------------------
  printf("\nStartDiagnosticSession  Extended\n");
  StartDiagnosticSession(0x03, 0);    // Start Extended Session without Security Access
  if (CheckError()) return 0;  
                
  
/*  
  //-----------------------------------------------------------------------------------------
  printf("\nClearDiagnosticInformation\n");
  ClearDiagnosticInformation(0xFFFFFF);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/ 

  //-----------------------------------------------------------------------------------------
  printf("\nReadDTCByStatusMask\n");
  ReadDTCByStatusMask(0xF9);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
      
    
  //-----------------------------------------------------------------------------------------
  printf("\nReadDataByIdentifier\n");
  ReadDataByIdentifier(0xF198);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
       
 /* 
  //-----------------------------------------------------------------------------------------
  printf("\nWriteDataByIdentifier\n");
  WriteDataByIdentifier(0xF198, Data, sizeof(Data));
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);            
 */            
 
  //-----------------------------------------------------------------------------------------
  printf("\nCommunicationControl\n");
  CommunicationControl(0x00, 0x01);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);

/*  
  //-----------------------------------------------------------------------------------------
  printf("\nControlDTCSetting\n");
  ControlDTCSetting(0x02, 0xFFFFFF);
  count = GetReceivedTelegram(mem, 24);
  if (CheckError()) return 0;
  for (i = 0; i < count - 1; i++) printf("%.2X ", mem[i]);
*/
 
 
  
  //-----------------------------------------------------------------------------------------
  printf("\nReset\n");
  ECUReset(0x01);
  if (CheckError()) return 0; 
  
  

  //-----------------------------------------------------------------------------------------
  printf("\nLogout\n");
  Logout();                                 // Stop Diagnostic Session
  if( CheckError() ) { return 0; }


  printf("\nFinished\n");

  return 0;
}