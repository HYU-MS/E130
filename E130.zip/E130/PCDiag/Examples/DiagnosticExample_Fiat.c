/***************************************************************************
/* DiagnosticExample_Fiat.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <biADWin.h>
#include <string.h>

#define MaxLength  1024



//******************************************************************************************************************
int main()
{
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size;
  int Code, Command;

  int i, x;
  unsigned char *data;
  int count;
  char *S;


  // Load Ini-File
  printf("\nLoad INI-File\n");
  if (SetIniFile("FIAT", "192", 1)) {
    printf("\nParameter file not found!");
    return 0;
  }

  // Set to Fiat-Diagnostic
  SetProtocolTyp("FIAT");
  S = GetProtocolName();
  printf("ProtocolName: %s",S);

  // Login Fiat Diagnostic
  printf("\nLogin\n");
  Login();
  if( CheckError() ) { return 0; }


  // Read Identification
  printf("Identification()\n");
  Identification();
  CheckError();

  count = GetReceivedTelegram(mem, 256);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,20);

  // SnapShot 05h
  printf("FiatSnapShot(0x05)\n");
  FiatSnapShot(0x05);
  CheckError();

  count = GetReceivedData(mem, 10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,16);

  // SnapShot 07h
  printf("FiatSnapShot(0x07)\n");
  FiatSnapShot(0x07);
  CheckError();

  count = GetReceivedData(mem, 10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,10);

  // SnapShot 08h
  printf("FiatSnapShot(0x08)\n");
  FiatSnapShot(0x08);
  CheckError();

  count = GetReceivedData(mem, 10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,10);

  // SnapShot 09h
  printf("FiatSnapShot(0x09)\n");
  FiatSnapShot(0x09);
  CheckError();

  count = GetReceivedData(mem, 10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,10);


  // ReadEventMemory
  printf("FiatReadEventMemory()\n");
  FiatReadEventMemory();
  CheckError();

  count = GetReceivedData(mem, 1024);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,5);


  // ReadParameter
  printf("FiatReadParameter(0x01)\n");
  FiatReadParameter(0x01);
  CheckError();

  count = GetReceivedData(mem,10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,10);



  // WriteParameter
  printf("FiatWriteParameter(0x01)\n");
  memset(mem,0x00,MaxLength);    // Fill buffer with 0x00
  mem[0]= 0x02;
  FiatWriteParameter(0x01,mem,1);
  CheckError();

  // optional get the request from the ECU
  count = GetReceivedData(mem,10);
  printf("count: %i  \nData: ", count);
  PrintBuffer(mem,count,10);


  // WriteActiveDiagnosis
  printf("FiatActiveDiagnosis(0x01)\n");
  FiatActiveDiagnosis(0x05);
  CheckError();


  // ClearErrorMemory
  printf("ClearErrorMemory\n");
  FiatClearErrorMemory();
  CheckError();


  // Logout
  printf("\nLogout: \n");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}
