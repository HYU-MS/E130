/***************************************************************************
/* IOPortPWMExample.c
/***************************************************************************
/*
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 27.04.2012 THF
/*
/**************************************************************************/

#include <IOBoard.h>
#include <stdio.h>


int main()
{
  int error;
  char* text;

  printf("Start\n\n"); 
                
  IOSetOutputs(0, 0x00);
            
  error = IOSetPWM(0, 0x20, 2);       
  printf("IOSetPWM \n"); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
  
  error = IOSetPWM(0, 0xC0, 4);       
  printf("IOSetPWM \n"); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error); 
    
  error = IOSetPWM(0, 0x80, 8);       
  printf("IOSetPWM \n"); 
  text = IOGetErrorText(error);
  printf("ErrorText: %s  ErrorCode %i\n" ,text ,error);   
  
  printf("\nEnd\n");

  return 0;
}


