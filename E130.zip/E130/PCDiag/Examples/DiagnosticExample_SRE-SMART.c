/***************************************************************************
/* DiagnosticExample_SRE-SMART.c
/***************************************************************************
/*
/* PCDiagNT C-Interpreter example program
/* THF Evolution GmbH
/*
/*--------------------------------------------------------------------------
/* History:
/* 18.09.2008 THF
/*
/**************************************************************************/

#include <PMode.c>
#include <PModeD.h>
#include <string.h>

#define MaxLength  1024



int main()
{
  char *S;
  unsigned char data[MaxLength];
  unsigned char mem[MaxLength];
  int StartAdr, EndAdr, Size, Count;


  // Set Protocol
  SetProtocolTyp(cSRESMART);
  S = GetProtocolName();
  printf("ProtocolName: %s\n",S);

  // Load Ini-File
  printf("Load INI-File\n");
  if (SetIniFile("SRE-SMART.ini", "Csample", 1)) {
    printf("Parameter file not found!");
    return 0;
  }

  // Login
  printf("\nLogin");
  Login();
  if( CheckError() ) { return 0; }


  // Identification
  printf("\nIdentification:");
  Identification();
  Size = GetReceivedTelegram(mem, 2);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  // SRESMARTTestMode
  printf("\nTestMode");
  data[0] = 0xB4;
  data[1] = 0x1B;
  Count  = 2;
  SRESMARTTestMode(Count, data);
  Size = GetReceivedData(mem, 10);
  if( !CheckError() ) { PrintBuffer(mem, Size, 16); }


  printf("\nLogout:");
  Logout();
  if (CheckError()) return 0;

  printf("End Stop\n");

  return 0;
}