Files for PCDiagNT

Last update: 18.09.2019

Note: - by Windows Vista and Windows 7 the programm files and the configuration files must be splitted.
      - the program files must be installed into C:\Program Files\...        --> {PF} (=Program Data Files)
      - the configuration files must be installed into C:\ProgramData\...    --> {AF} (=Application Data Files)

      - When you install by Windows Vista Windows 7 the programm files NOT in C:\Program Files\... e.g. D:\MyProgramms\... then the files are NOT splitted, all files installed in the same folder structure!
 
      - by Windows XP all files installed into C:\Program Files\...


*************************************************************************************
PCDiagNT:
*************************************************************************************
\BIN\
	- PCDiagNT.exe  	{PF}--> Main-Program file

	- PcdFunctions.cfg	{PF}--> Uses PCDiagNT includes the available functions
	- PCDiag.ini		{AF}--> Temporary file is created bei at runtime by PCDiagNT.exe

	- PCDWin.bmp		{AF}--> User defined standard Bitmap
	- ******.bmp		{AF}--> User defined Bitmap must have the same name as the Project-Parameter-file: example VW5.bmp, FIAT.bmp


	********* SDK.DLL **********************************************************
	- sdk.dll		{PF}--> Security access calculation for different Projects

	********* SeedNKeyXcp.dll **************************************************
	- SeedNKeyXcp.dll	{PF}--> XCP-Protocol Security access calculation for different Projects

	********* TdrDecoder.DLL ***************************************************
	- TdrDecoder.dll	{PF}--> TEDR-Recorder

        ********* EDR2WORD.DLL *****************************************************
	- EDR2WORD.dll	        {PF}--> EDR to Word report

 	********* HexOpt.DLL *****************************************************
	- HexOpt.dll	        {PF}--> ETS-DataFlash data optimization

	********* Correlation ******************************************************
	- ADWin32.dll		{PF}--> Driver for the ADWin-Card
	- Adwin4.btl		{PF}--> Basic-Program for the ADWin 4-Card
	- Adwin9.btl		{PF}--> Basic-Program for the ADWin 9-Card
	- Pcdiag_4khz.T42	{PF}--> Program for the ADWin 4-Card
	- Pcdiag_4khz.T92	{PF}--> Program for the ADWin 9-Card


	********* SAT4 Files *******************************************************
	- ResetgSat4gen*.USR    {PF}--> For ECU programm for gSat4
	- ResetgSat4Tgen*.USR   {PF}--> For ECU programm for gSat4T
	- ResetpSat4gen*.USR    {PF}--> For ECU programm for pSat4


	********* VW-Files *********************************************************
	- Eol_Help.pdf		                          {AF}--> Helpinformation for the Bandendeprog. VW-Diagostic (Acrobat-Reader-File)
	- VWEOLHelp.ini		                          {AF}--> Helpinformation for the Bandendeprog. VW-Diagostic to decode the "allpar.pa" files
        - Einheitliche_Bezeichnung_PS_in_PCDIAGNT_5.0.xls {AF}--> Helpinformation for the Bandendeprog. VW-Diagostic
        - CanL2.dll		                          {PF}--> Switch the EDICCard2 between DTS and CAN-Card usages


        ********* USBpulse100 ******************************************************
        - CP210xMan.dll            {PF}--> Library used from USBpulse100
        - USBpulse100Drvr_W32.dll  {PF}--> Library used from USBpulse100


 	********* USB-Relay-Card ***************************************************
        - USB_Relais_Karte.dll  {PF}--> Library used from USB-Relay-Card


 	********* Top16 IO module **************************************************
        - top16.dll             {PF}--> Library used from Top16 IO-Module


        ********* LPT Port access **************************************************
	- WinRing0.dll          {PF}--> Library used for LPT-Port access
	- WinRing0.sys          {PF}--> 32 bit driver used for LPT-Port access
	- WinRing0x64.sys       {PF}--> 64 bit driver used for LPT-Port access       

        
        ********* CAN device access ************************************************
	- PCAN_USB.dll		{PF}--> Library used for PeakUSB CAN-Hardware  
	- vxlapi.dll		{PF}--> Library used for CAN-Hardware (CANCardXL, CANCaseXL, VN1610, VN1611, VN1630, VN1640)


	********* AIDA(Runtime) Files **********************************************
\BIN\AIDA Runtime
        - _Start AIDA Stacker.cmd							{PF}--> Start the AIDA_Stacker.exe and set the PATH environment for the can.component file.
	- AIDA_Stacker.exe      							{PF}--> Editor for AIDA-Stack files *.aida-cfg. Please start the it with _Start AIDA Stacker.cmd file
	- BSK-AIDA-THF-Evolution-Granted-Runtime-Version_PCDiagNT_RT.lic		{PF}--> Licence file for use PCDiagNT.exe and the AIDA-Stacker.exe
	- BSK-AIDA-THF-Evolution-Granted-Runtime-Version_PCDiagCInterpreterCMD_RT.lic	{PF}--> Licence file for use PCDiagCInterpreterCMD.exe and the AIDA-Stacker.exe

	- BSK_AIDA.dll									{PF}--> AIDA-Runtime library
	- BSK_AIDA_Comp.dll								{PF}--> AIDA-Runtime library
	- BSK_ConfigFile.dll								{PF}--> AIDA-Runtime library
	- BSK_OSAL.dll									{PF}--> AIDA-Runtime library
												
	- *.component 									{PF}--> Component used from AIDA
	- *.plugin									{PF}--> Plugin used from AIDA

         
\BIN\AIDA Runtime\CAN_NeoVI
        - CAN.component		{PF}--> CAN-Component used for NeoVI CAN-Hardware
        
\BIN\AIDA Runtime\CAN_PEAK_USB
 	- CAN.component		{PF}--> CAN-Component used for PeakUSB CAN-Hardware	

\BIN\AIDA Runtime\CAN_VXL
	- CAN.component		{PF}--> CAN-Component used for Vector CAN-Hardware (CANCardXL, CANCaseXL, VN1610, VN1611, VN1630, VN1640)
	
\BIN\AIDA Runtime\CAN_Vector
	- CAN.component		{PF}--> CAN-Component used for Vector CAN-Hardware (EDICCard2) Windows XP
	- vcand32.dll		{PF}--> Library used for CAN-Hardware (EDICCard2) Windows XP


        ********* AIDA(Configuration) Files ****************************************
\BIN\AIDA
	- *.aida-cfg		{AF}--> BSK-AIDA Stack configuration files


        ********* MFSatCard Files **************************************************
\BIN\MFSatSettings
	- *.sdf			{AF}--> Files (MF-SatCard Configuration)


        ********* SAT3 Files *******************************************************
\PARAMS
	- Eolreset.pa1		{AF}--> Sat3gen files


        ********* Project Files ****************************************************
\PROJECTS
        - ******.bmp		{AF}--> User defined Bitmap must have the same name as the Project-Parameter-file: example VW5.bmp, FIAT.bmp
	- PcdUserProfile.cfg	{AF}--> Is changed at runtime includes the user-configured functions and passwords
	- user.ini		{AF}--> Is changed at runtime includes the actual login, COM-port..

	- *******.prj		{AF}--> Example VW5.prj, FIAT.prj these are the Project-Parameter-files to configure the project.
                            	        These files are must be configurated by the user.
	- MFSatCard.cfg		{AF}--> Configuration file for the MFSatCard Communication and RAM-Mapping.
				        The default file comes by the PCDiagNT Setup, and can changed by the user.



-------------------------------------------------------------------------------------
\ConfigFiles\Install IME CAT Tool Driver
	- *.*                  {PF}--> Installation program for the Single Wire CAN Driver(CAT Tool Device)

-------------------------------------------------------------------------------------
\ConfigFiles\Install USBpulse100 Driver
        - *.*                  {PF}--> Driver for USBpulse100



        ********* User Files ******************************************************
\DATA
       {AF}--> Default folder for user data

        ********* User Files ******************************************************
\EDR
       {AF}--> Folder for EDR-Decode List files
       
        ********* AudiXML Files ***************************************************
\AudiXML
       {AF}--> Default folder for Audi-XML files used from Program End of Line


        ********* VWAllpar Files ***************************************************
\VWAllpar
       {AF}--> Default folder for VW-Allpar (*.PAR) files used from Program End of Line


        ********* VWXML Files ******************************************************
\VWXML
\VWXML\ALLPAR
\VWXML\INERT
\VWXML\PROTOTYP
       {AF}--> Default folder for VW-XML files used from Program End of Line



*************************************************************************************
C-Interpreter:
************************************************************************************* 
\BIN
        - PCDiagCInterpreterCMD.exe 	{PF}--> C-Interpreter for calling direct from the command line


	- PcdCInterpreter.dll   	{PF}--> Library for the C-Interpreter
	- PModeD.dll			{PF}--> Library for the Protocol-funcions, used by the C-Interpreter
	- MFSatCard.dll			{PF}--> Library for the MFSatCard access, used by the C-Interpreter
	- CrashSimD.dll			{PF}--> Library for the CrashSim-functions, used by the C-Interpreter
	- EICBase.dll			{PF}--> Library for the IO-Port access & the Dialogs used by the C-Interpreter

        - CSPro_p*.T*			{PF}--> CrashSimPro files used from CS_pro_dll.dll
	- gpib-32.dll			{PF}--> Library for the GPIB-funcions, used by the C-Interpreter
	- niswitch_32.dll		{PF}--> Library for the SCIX-funcions, used by the C-Interpreter
	- nidaq32.dll			{PF}--> Library for the DIO-funcions, used by the C-Interpreter

        - CS_pro_dll.dll 		{PF}--> Library for the CrashSim-Pro-functions, used by the C-Interpreter
        - DBUtils.dll			{PF}--> Library used from CS_pro_dll.dll
        - CSPro_p1.T91          	{PF}--> Used from CS_pro_dll.dll
        - CSPro_p1.TA1          	{PF}--> Used from CS_pro_dll.dll
        - CSPro_p2.T92          	{PF}--> Used from CS_pro_dll.dll
        - CSPro_p2.TA2          	{PF}--> Used from CS_pro_dll.dll
        - CSPro_p3.T93          	{PF}--> Used from CS_pro_dll.dll
        - CSPro_p3.TA3          	{PF}--> Used from CS_pro_dll.dll




-------------------------------------------------------------------------------------
\WIN32                              --> Include-files for use these files direct in your C-Program
	- assert.h              {PF}
	- ctype.h               {PF}
	- errno.h               {PF}
	- float.h	        {PF}
	- limits.h              {PF}
	- math.h                {PF}
	- setjmp.h              {PF}
	- signal.h              {PF}
	- stdarg.h              {PF}
	- stddef.h              {PF}
	- stdio.h               {PF}
	- stdlib.h              {PF}
	- string.h              {PF}
	- time.h                {PF}
	- windows.h             {PF}

-------------------------------------------------------------------------------------
\WIN32\SYS
	- errno.h               {PF}
	- float.h               {PF}
	- limits.h              {PF}
	- signal.h              {PF}
	- stdio.h               {PF}
	- stdlib.h              {PF}
	- stdtypes.h            {PF}
	- time.h                {PF}

-------------------------------------------------------------------------------------
\WIN32\LIB
	- CS_pro_dll.h	        {PF}--> Header file for the CS_pro_dll.dll
	- EicIDE.h	        {PF}--> Header file for C-Functions to control the IDE
        - EICBase.h	        {PF}--> Header file for the EICBaseD.dll
	- PModeD.h	        {PF}--> Header file for the PModeD.dll
	- PMode.c	        {PF}--> Protocol-functions used C-Interpreter
	- Pmode_xtn.h	        {PF}--> Header file Protocol-functions used C-Interpreter
	- Pmode_xtn.c	        {PF}--> Protocol-functions used C-Interpreter
	- MFSataCard_dll.h	{PF}--> Header file for the MFSatCard.dll
	- CrashSimD.h	        {PF}--> Header file for the CrashSimD.dll
	- CrashSim.c	        {PF}--> CrashSim-functions used C-Interpreter
	- biADWin.h	        {PF}--> Header file for the ADWin32.dll
	- RelayCard.h	        {PF}--> Header file for USB-Relay-Card access
	- IOBoard.h	        {PF}--> Header file for Top16 IO module access
	- LPTPort.h	        {PF}--> Header file for LPT-Port access
	- IOKithara.h	        {PF}--> Header file wrapper for Top16 IO module access (only uesd in old projects)
	- GPIB.h	        {PF}--> Header file for the gpib-32.dll
	- SCXI.h	        {PF}--> Header file for the niswitch_32.dll
	- Dio.h		        {PF}--> Header file for the nidaq32.dll

	- _Kithara Readme.txt			{PF}--> Description for use the _xxxWrapper_xxx.h files
	- _LPTPortWrapper_IOKithara.h		{PF}--> Wrapper for LPTPort access
	- _RelayCardWrapper_IOKithara.h		{PF}--> Wrapper for USB-Relay-Card access
	- _Top16Wrapper_Invert_IOKithara.h	{PF}--> Wrapper for Top16Module invert access
	- _Top16Wrapper_IOKithara.h		{PF}--> Wrapper for Top16Module access
	
	
-------------------------------------------------------------------------------------
\LIBRARY
                                {AF}--> Folder for user header *.h files
	
-------------------------------------------------------------------------------------
\EXAMPLES
	- *.c	                {AF}--> Example C-Interpreter files

-------------------------------------------------------------------------------------
\SOURCE
	- *.c	                {AF}--> User C-Interpreter files

-------------------------------------------------------------------------------------
\RESULTS
	- *.c	                {AF}--> Result C-Interpreter output, log files


*************************************************************************************
Online-Help for the C-Interpreter:
*************************************************************************************
\HELP
        - PCDiagNT.chm			{PF}--> Main Online-Help for PCDiagNT
	- MainMenu.chm			{PF}--> Online-Help for the Main menue
	- Configuration.chm		{PF}--> Online-Help for the Configuration
	- DialogsGER.chm		{PF}--> Online-Help for the VW-Diagnostic describes the functions in germany
	- VWGER.chm			{PF}--> Online-Help for the VW-Diagnostic describes the dialogs in germany
	- ProjectParameter.chm		{PF}--> Online-Help for the Project-File Parameter for Continental Automotive GmbH user only

	- INTERPRETER.chm		{PF}--> Online-Help for the C-Interpreter
	- INTERPRETERIDE.chm		{PF}--> Online-Help for the C-Interpreter IDE
	- EICBase.chm			{PF}--> Online-Help for the C-Interpreter Dialogs-functions
	- PROTOCOLS.chm			{PF}--> Online-Help for the C-Interpreter Protocol-functions
	- IOPort.chm			{PF}--> Online-Help for the C-Interpreter IO-Port access-functions
	- CRASHSIM.chm			{PF}--> Online-Help for the C-Interpreter CrashSim-functions
	- CRASHSIM-SCRIPT.chm		{PF}--> Online-Help for the C-Interpreter CrashSim-Script functions

	- Gpib32.hlp			{PF}--> Online-Help for the GPIB-funcions, used by the C-Interpreter, suported by national-instruments
	- SCXI-interface.hlp		{PF}--> Online-Help for the SCIX-funcions, used by the C-Interpreter, suported by national-instruments
	- DIO-interface.hlp		{PF}--> Online-Help for DIO-funcions, used by the C-Interpreter, suported by national-instruments
	- roboex32.dll			{PF}--> used by Gpib32.hlp, suported by national-instruments
	- inetwh32.dll			{PF}--> used by SCXI-interface.hlp, suported by national-instruments



*************************************************************************************
Documentation:
*************************************************************************************
\DOC
	- PCDiag LogBook 1999.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 1999
	- PCDiag LogBook 2000.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2000
	- PCDiag LogBook 2001.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2001
	- PCDiag LogBook 2002.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2002
	- PCDiag LogBook 2003.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2003
	- PCDiag LogBook 2004.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2004
	- PCDiag LogBook 2005.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2005
	- PCDiag LogBook 2006.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2006
	- PCDiag LogBook 2007.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2007
	- PCDiag LogBook 2008.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2008
	- PCDiag LogBook 2009.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2009
	- PCDiag LogBook 2010.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2010
        - PCDiag LogBook 2011.pdf    		{PF}--> Release Notes for all changes in PCDiagNT 2011 until version 2.6.5.3

	- PCDiagNT Release Notes 2011.pdf    	{PF}--> Release Notes for all changes in PCDiagNT 2011 up version 2.6.5.4
	- PCDiagNT Release Notes 2012.pdf    	{PF}--> Release Notes for all changes in PCDiagNT 2011 up version 2.6.5.8
	- PCDiagNT Release Notes 2013.pdf    	{PF}--> Release Notes for all changes in PCDiagNT 2011 up version 2.7.0.2
	- PCDiagNT Release Notes 2014.pdf    	{PF}--> Release Notes for all changes in PCDiagNT 2011 up version 2.7.0.5
	- PCDiagNT Release Notes 2015.pdf    	{PF}--> Release Notes for all changes in PCDiagNT 2011 up version 2.7.0.8
        - PCDiagNT Release Notes PreRelease.pdf {PF}--> Release Notes for all pre release changes in PCDiagNT


-------------------------------------------------------------------------------------
\DOC\MANUALS                           --> Manuals
        - PCDiagCInterpreterCMD.pdf 		 {PF}
	- PCDiagNT Configuration Manual.pdf      {PF}
	- PCDiagNT EDR0100-dtd.pdf		 {PF}
	- PCDiagNT EDR2Word.pdf			 {PF}
        - MFSatFileConverter.pdf 		 {PF}

-------------------------------------------------------------------------------------
\DOC\INSTALL		--> Installation descriptions
	- Install CAN-Device Reference.pdf	{PF}
	- Install EdicCard2 CANcard.pdf    	{PF}




*************************************************************************************
Registry Patches
*************************************************************************************
\CONFIGFILES
        - CHM-Intranet-Fix.reg	{PF}--> Fix run CHM-Help from a network folder



*************************************************************************************
Special Programs, only for internal using by Continental Automotive GmbH:
*************************************************************************************
\CONTINENTAL ONLY
       - _Download Server.txt       	{PF}--> Download Server Information
       - *.lic				{PF}--> Licence file(s)
       - PrjPar.exe			{PF}--> Program to edit the Project-file for example VW5.prj, FIAT.prj
       - Password.exe			{PF}--> Program to change the Passwords, only for internal using by Continental Automotive GmbH
       - CryptMemoryEditor.exe		{PF}--> This editor encrypts and crypts memory files. The encrypted file CheckPM.mem is used if PModeLoginCheck is enabled.
       - CryptConfigFileEditor.exe      {PF}--> This editor encrypts and crypts *ccf files. The encrypted file is needed for OCS-Security Access.

\BIN
       - MFSatFileConverter.exe 	{PF}--> *.sdf --> *.sdf-neo file converter
       - UserProfileConverter.exe	{PF}--> Converts the old user profiles  into the new format used up to version 2.6.0.0
       - PCDIniFileConverter.exe	{PF}--> Converts the Project-Ini-Files *.ini to a newer format Project-Files *.prj to , deletes unused parameters,.. used up to version 2.7.0.0
       - PcdRefFunctions.ref		{PF}--> Is used from the UserProfileConverter.exe
       

********** End of File **************************************************************




