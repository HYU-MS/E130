#!/usr/bin/perl
use warnings;
use strict;

my $projectpath;

if ( ! defined( $projectpath = $ARGV[0] ))
{
    print "usage: perl $0 <projectpath> <projectname>\n";
    exit(1);
}   

my $OrgFile1    = "${projectpath}\\ACU_SYMCC300_MY19_S30_V4-1_InitialNVM.s37";
my $OrgFile2    = "${projectpath}\\ETSPar\\Generator\\ETSPar_complete.s37";
my $OrgFile3    = "${projectpath}\\..\\FBL_NVM_App_Valid.s37";


my $NewFile    = "${projectpath}\\NVM_FBL_all_V4-1_opt.s37";


open f_org_file1, "< $OrgFile1" or die "Can't open Input-S-file $OrgFile1!";
open f_org_file2, "< $OrgFile2" or die "Can't open Input-S-file $OrgFile2!";
open f_org_file3, "< $OrgFile3" or die "Can't open Input-S-file $OrgFile3!";

open f_newfile, "> $NewFile" or die "Can't open Output-S-file $NewFile!";

  while (<f_org_file1>)
	{
		if(/S3/)
		{
				print f_newfile $_;
		}
	}
	
  while (<f_org_file2>)
	{
		if(/S325FF207/)
		{
			print f_newfile $_;
		}
	}
 
  while (<f_org_file3>)
	{
		if(/S325FF207/)
		{
			print f_newfile $_;
		}
	}


	
close f_org_file1;
close f_org_file2;
close f_org_file3;
close f_newfile;

print "\nResult: PASS\n";